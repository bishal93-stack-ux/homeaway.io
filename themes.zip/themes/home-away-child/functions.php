<?php
/**
 * SASD functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package SASD
 */
defined('ABSPATH') || exit();

// Init
// All the function file are get from init.php 
require __DIR__ . '/inc/init.php';

add_filter('paginate_links', function ($link) {
    return preg_replace('#page\/1[^\d]#', '', $link);
},15,1);