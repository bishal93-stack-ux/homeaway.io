<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package Home_Away_Child_Care_Center
 */
get_header();
?>

<div class="blog__wrap blog__single">
	<div class="container">
		<div class="row blog__inner">
			<div class="col-lg-8 blog__post">
				<?php
				if (have_posts()) : while (have_posts()) : the_post();
						get_template_part('template-parts/content', get_post_type());
					endwhile;
				else :
					get_template_part('template-parts/content', 'none');
				endif;

				wp_reset_postdata(); ?>
			</div>
			<!-- /.blog__post -->
			<aside class="col-lg-4 blog__sidebar">
				<?php get_sidebar(); ?>
			</aside>
			<!-- /.blog__sidebar -->
		</div>
	</div>
</div>
<!-- /.blog__wrap -->

<?php
get_footer();