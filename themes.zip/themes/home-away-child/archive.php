<?php
/**
 * The template for displaying archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Home_Away_Child_Care_Center
 */
get_header();
?>
<div class="blog__wrap">
	<div class="container">
		<div class="row blog__inner">
			<div class="col-lg-8 blog__post">
                <?php
                the_archive_description( '<div class="archive-description">', '</div>' );
				if (have_posts()) : while (have_posts()) : the_post();
						get_template_part('template-parts/content', get_post_type());
					endwhile;
				else :
					get_template_part('template-parts/content', 'none');
				endif;

				wp_reset_postdata(); 
				// pagination
				$big = 999999999;
				$args = array(
					'base' => str_replace($big, '%#%', esc_url(get_pagenum_link($big))),
					'format' => '?paged=%#%',
					'total' => $wp_query->max_num_pages,
					'current' => max(1, get_query_var('paged')),
					'show_all' => false,
					'end_size' => 3,
					'mid_size' => 2,
					'prev_next' => true,
					'prev_text' => __('Prev'),
					'next_text' => __('Next'),
					'type' => 'array',
				);

				// Pagination
				$links = paginate_links($args);
				if ($links) {
					echo '<nav class="page-navigation "><ul class="pagination">';
					foreach ($links as $link) {
						echo sprintf('<li class="page-item">%s</li>', str_replace('page-numbers', 'page-numbers page-link',  $link));
					}
					echo '</ul></nav>';
				}   ?>
			</div>
			<!-- /.blog__post -->
			<aside class="col-lg-4 blog__sidebar">
				<?php get_sidebar(); ?>
			</aside>
			<!-- /.blog__sidebar -->
		</div>
	</div>
</div>
<!-- /.blog__wrap -->

<?php
get_footer();