<?php

/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Home_Away_Child_Care_Center
 */
?>
<!doctype html>
<html <?php language_attributes(); ?>>

<head>
	<meta charset="<?php bloginfo('charset'); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;600;700;800&family=Poppins:wght@100;200;300;400;500;600;700;800;900&family=Roboto:wght@100;300;400;500;700;900&family=Dancing+Script:wght@400;500;562;600;700&family=Heebo:wght@100;400;500;700;900&display=swap" rel="stylesheet">
	<?php wp_head(); ?>
</head>

<body <?php body_class(''); ?>>
	<div class="site-wrapper">
		<header class="site-header">
			<nav class="navbar navbar-expand-lg navbar-light">
				<?php the_brand(); ?>
				<button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#nav-pri" aria-controls="nav-pri" aria-expanded="false" aria-label="Toggle Navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
				<?php
				wp_nav_menu(array(
					'theme_location'  => 'nav-pri',
					'depth'	          => 2, // 1 = no dropdowns, 2 = with dropdowns.
					'container'       => 'div',
					'container_class' => 'collapse navbar-collapse offset',
					'container_id'    => 'nav-pri',
					'menu_class'      => 'nav navbar-nav justify-content-center ml-auto',
					'walker'         => new Bootstrap_NavWalker(),
					'fallback_cb'    => 'Bootstrap_NavWalker::fallback',
				));
				?>
				<a href="/contact/" class="phone-number"><span class="icon-call-bold"></span><span class="text d-none d-xl-inline-block">Contact Us</span></a>
			</nav>
		</header>
		<?php
		$bannerClass = '';

		if (!is_front_page()) {
			get_template_part('template-parts/common/hero-banner');
		} else {
			get_template_part('template-parts/common/home-banner');
		} ?>
		<main class="site-content">