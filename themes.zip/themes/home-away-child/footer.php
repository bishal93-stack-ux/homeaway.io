<?php

/**
 * The template for displaying the footer
 *
 * Contains the closing of the .flex-shrink-0 div and all after .content div.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Home_Away_Child_Care_Center
 */
// Footer Top
$top_title = get_field('ss_footertop_title', 'option');
$top_sub_title = get_field('ss_footertop_sub_title', 'option');
$top_phone = get_field('ss_footer_top_phone_number', 'option');
// Footer Left Section
$site_logo = get_field('ss_site_logo', 'option');
$site_desc = get_field('ss_site_short_description', 'option');
// Footer Middle Section
$middle_title = get_field('ss_section_top_title', 'option');
$address_title = get_field('ss_address_section_title', 'option');
// Footer Right Section
$phone_title = get_field('ss_phone_title', 'option');
$phone_number = get_field('ss_footer_phone_number', 'option');
$email_title = get_field('ss_email_title', 'option');
$email = get_field('ss_footer_email_address', 'option');
// Copyright Text
$site_name = get_bloginfo('name');
$copyright = get_field('ss_copyright_text', 'option');
?>
</main>

<footer class="site-footer">
	<?php if ($top_title || $top_sub_title || $top_phone) { ?>
		<div class="enroll-cta">
			<div class="site-footer__cta">
				<div class="holder">
					<?php if ($top_title && $top_sub_title) { ?>
						<h2><small><?php echo $top_title; ?></small><?php echo $top_sub_title; ?></h2>
					<?php } ?>
					<?php if ($top_phone) { ?>
						<div class="btn-wrap">
							<a href="tel:<?php echo preg_replace('/[^0-9]/', '', $top_phone); ?>" class="btn btn-phone"><span class="icon-telephone"></span><?php echo $top_phone; ?></a>
						</div>
					<?php } ?>
				</div>
			</div>
		</div>
		<!-- /.site-footer__cta -->
	<?php } ?>

	<div class="site-footer__top">
		<div class="container">
			<div class="site-footer__top--wrap">
				<div class="row">
					<div class="col-md-5 col-lg-4">
						<div class="leftaside">
							<?php if ($site_logo) { ?>
								<figure>
									<img src="<?php echo $site_logo['url']; ?>" alt="<?php echo $site_logo['alt']; ?>">
								</figure>
							<?php } ?>
							<?php if ($site_desc) { ?>
								<p><?php echo $site_desc; ?></p>
							<?php } ?>
							<?php if (is_active_sidebar('footer-left-section')) {
								dynamic_sidebar('footer-left-section');
							}
							?>
						</div>
						<!-- leftaside -->
					</div>
					<!-- col-md-5 col-lg-4 -->

					<div class="col-md-7 col-lg-8">
						<div class="rightaside">
							<?php if ($middle_title) { ?>
								<h4><?php echo $middle_title; ?></h4>
							<?php } ?>
							<div class="contact-block">
								<div class="contact-block__left">
									<div class="contact-block__item contact-block--address">
										<div class="icon-holder"><i class="icon-map-nav"></i></div>
										<div class="content-holder">
											<?php if ($address_title) { ?>
												<h5><?php echo $address_title; ?></h5>
											<?php } ?>
											<?php if (have_rows('ss_contact_address', 'option')) : ?>
												<ul>
													<?php while (have_rows('ss_contact_address', 'option')) : ?>
														<?php the_row();
														$location = get_sub_field('ss_location_address', 'option');
														$map_link = get_sub_field('ss_google_map_link', 'option');
														if ($location) {
														?>
															<li><a href="<?php echo $map_link; ?>" target="_blank"><?php echo $location; ?></a></li>
													<?php }
													endwhile; ?>
												</ul>
											<?php endif; ?>
										</div>
									</div>
								</div>
								<!-- .contact-block__left -->

								<?php if ($phone_title || $phone_number || $email_title || $email) { ?>
									<div class="contact-block__right">
										<?php if ($phone_title || $phone_number) { ?>
											<div class="contact-block__item contact-block--ph-number">
												<div class="icon-holder"><i class="icon-call-bold"></i></div>
												<div class="content-holder">
													<?php if ($phone_title) { ?>
														<h5><?php echo $phone_title; ?></h5>
													<?php } ?>
													<?php if ($phone_number) { ?>
														<a href="tel:<?php echo preg_replace('/[^0-9]/', '', $phone_number); ?>"><?php echo $phone_number; ?></a>
													<?php } ?>
												</div>
											</div>
										<?php } ?>
										<?php if ($email_title || $email) { ?>
											<div class="contact-block__item contact-block--email-add">
												<div class="icon-holder"><i class="icon-mail"></i></div>
												<div class="content-holder">
													<?php if ($email_title) { ?>
														<h5><?php echo $email_title; ?></h5>
													<?php } ?>
													<?php if ($email) { ?>
														<a href="mailto:<?php echo $email; ?>"><?php echo $email; ?></a>
													<?php } ?>
												</div>
											</div>
										<?php } ?>
                                        <div class="contact-block__item contact-block--social-icons">
                                            <div class="icon-holder">
                                                <a target="_blank" href="https://www.facebook.com/Home-Away-Child-Care-Center-424977817987833/">
                                                    <img src="/media/fb-icon.png" alt="Facebook Icon" width="30px">
                                                </a>
                                            </div>
                                        </div>
									</div>
									<!-- .contact-block__right -->
								<?php } ?>
							</div>
						</div>
						<!-- .rightaside -->
					</div>
					<!-- col-md-7 col-lg-8 -->
				</div>
			</div>
		</div>
		<!-- .container -->
	</div>
	<!-- .site-footer__top -->
	<?php if ($copyright) { ?>
		<div class="site-footer__bottom text-center">
			<div class="container">
			<?php echo hacc_custom_copyright_text(); ?>
			</div>
			<!-- .container -->
		</div>
		<!-- .site-footer__bottom -->
	<?php } ?>
</footer>

<?php wp_footer(); ?>
</body>

</html>