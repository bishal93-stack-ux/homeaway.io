<?php
$row = get_row( true );
if ( empty( $row ) ) return;
$title = $row['ss_title'];
$sub_title = $row['ss_sub_title'];
$content = $row['ss_content'];
$img = $row['ss_image'];
$addi_sec = $row['ss_additional_section'];
if ( $img ) {
    $col = 'col-lg-6';
}
else {
    $col = 'col-lg-12';
}
if ( $title || $content ||  $img ||  $addi_sec || $sub_title ) { ?>
    <section class="development-program">
        <div class="container">
            <?php if ( $title || $sub_title ) { ?>
                <div class="development-program__heading">
                    <div class="heading has-border has-border--center">
                        <?php if ( $title ) {
                            echo '<h4>'. $title .'</h4>';
                        }
                        if ( $sub_title ) {
                            echo '<h2>'. $sub_title .'</h2>';
                        } ?>
                    </div>
                </div>
            <?php } ?>
            <div class="development-program__content double-column">
                <div class="row">
                    <?php if ( $content || $addi_sec ) { ?>
                        <div class="<?php echo $col; ?> order-lg-1 order-2">
                            <div class="development-program__info double-column__info">
                                <?php if ( $content ) { ?>
                                    <div class="bold-text">
                                       <?php echo $content; ?>
                                    </div>
                                <?php } 
                                echo $addi_sec; ?>   
                            </div>
                            <!-- /.development-program__info-->
                        </div>
                    <?php }  
                    if ( $img ) { ?>
                        <div class="col-lg-6 order-lg-2 order-1">
                            <div class="development-program__media double-column__media">
                                <figure>
                                    <img src="<?php echo $img['url']; ?>" alt="<?php echo $img['alt']; ?>">
                                </figure>
                            </div>
                            <!-- /.development-program__media-->
                        </div>
                    <?php } ?>
                </div>
            </div>
            <!-- /.development-program__content-->
        </div>
        <!-- /.container-->
    </section>
    <!-- /.development-program--> 
    <?php } ?>