<?php 
$row = get_row( true );
if ( empty( $row ) ) return;
$title = $row['ss_title'];
$sub_title = $row['ss_sub_title'];
$content = $row['content'];
if ( $title || $sub_title || $content ) {
?>
    <section class="infant-program__content">
        <div class="container">
            <?php if ( $title || $sub_title ) { ?>
                <div class="choose-block__heading">
                    <div class="heading has-border has-border--center">
                        <?php if ( $title ) { 
                            echo '<h4>'. $title .'</h4>';
                        } if ( $sub_title ) { 
                            echo '<h2>'. $sub_title .'</h2>';
                        } ?>
                    </div>
                </div>
                <!-- /.choose-block__heading-->
            <?php }
            if ( $content  ) { ?>
                <div class="choose-block__content content-full-width">
                    <div class="row">
                        <?php echo $content; ?>
                    </div>
                </div>
            <?php } ?>    
            <!-- /.choose-block__content-->
        </div>
        <!-- /.container-->
    </section>
<?php } 