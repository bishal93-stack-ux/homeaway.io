<?php 
$row = get_row( true );
if ( empty( $row ) ) return;
$title = $row['ss_title'];
$sub_title = $row['ss_sub_title'];
$content = $row['ss_content'];
$img = $row['ss_image'];
if ( $img ) {
    $lg = 'col-lg-6';
    $xxl = 'col-xxl-5';
}
else {
    $lg = 'col-lg-12';
    $xxl = 'col-xxl-12';
}
if ( $title || $sub_title || $content || $img ) { ?>
    <section class="benefit-program">
        <div class="container">
            <div class="benefit-program__content double-column">
                <div class="row no-gutters">
                    <?php if ( $img ) { ?>
                        <div class="col-xxl-7 col-lg-6">
                            <div class="benefit-program__media double-column__media">
                                <figure>
                                    <img src="<?php echo $img['url']; ?>" alt="<?php echo $img['alt']; ?>">
                                </figure>
                            </div>
                            <!-- /.benefit-program__media-->
                        </div>
                    <?php }
                    if ( $title || $sub_title || $content  ) { ?>
                        <div class="<?php echo $xxl.' '.$lg; ?>">
                            <div class="benefit-program__info double-column__info">
                                <?php if ( $title || $sub_title ) { ?>
                                    <div class="heading has-border">
                                        <?php if ( $title ) { 
                                            echo '<h4>'. $title .'</h4>';
                                        } if ( $sub_title ) { 
                                            echo '<h2>'. $sub_title .'</h2>';
                                        } ?>
                                    </div>
                                <?php }  
                                echo $content; ?>
                            </div>
                            <!-- /.benefit-program__info-->
                        </div>
                    <?php } ?>    
                </div>
            </div>
            <!-- /.benefit-program__content-->
        </div>
        <!-- /.container-->
    </section>
<?php } 
