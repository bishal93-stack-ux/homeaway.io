<?php 
$posttype = get_post_type( get_the_ID() );
if ( get_post_type( get_the_ID() ) == $posttype ) {
	$args = array(
		'post_type' 		=> $posttype,
		'post_status'		=> 'publish',
		'posts_per_page' 	=> -1,
		'order'				=> 'ASC',
		'post__not_in' => array( get_the_ID() ),

	);
}
if ( get_post_type( get_the_ID() ) == 'haccc_programs' ) {
	$surl = home_url('/');
} elseif ( get_post_type( get_the_ID() ) == 'haccc_classes' ) {
	$surl = home_url('/');
} elseif ( get_post_type( get_the_ID() ) == 'haccc_development' ) {
	$surl = home_url('/');
}
$row = get_row( true );
if ( empty( $row ) ) return;
$title = $row['ss_title'];
$sub_title = $row['ss_sub_title'];
$desc = $row['ss_description'];
$button = $row['ss_section_button'];
if ( $button ) {
	$url = $button['url'];
	$target = $button['target'] ? $button['target'] : '_self';
	$b_title = $button['title'];
}
?>
<section class="card-block">
	<div class="container">
		<div class="card-block__heading">
			<?php if ( $title || $sub_title ) { ?>
				<div class="heading has-border has-border--center">
					<?php if ( $title ) { 
                         echo '<h4>'. $title .'</h4>';
                    } if ( $sub_title ) { 
                        echo '<h2>'. $sub_title .'</h2>';
                    } ?>
				</div>
			<?php } ?>
			<p><?php echo $desc; ?></p>
		</div>
		<!-- /.card-block__heading-->
		<?php 
		$query = new WP_Query($args);
		if ( $query->have_posts() ) : ?>
			<div class="card-block__content">
				<?php 	while( $query->have_posts() ) :
					$query->the_post();
					?>
					<div class="card-block__item">
						<div class="item-wrap">
							<a href="<?php the_permalink(); ?>" class="stretched-link"></a>
							<div class="card-block__img bg-cover">
								<?php if ( has_post_thumbnail() ) {
									the_post_thumbnail();
								} else {
									echo ' <img src="'. home_url('/media/area-card-01.jpg') .'" alt="Featured Image Not Found">';
								} ?>
							</div>
							<div class="card-block__text" data-fix="height">
								<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
							</div>
						</div>
						<!-- /.item-wrap-->
					</div>
					<!-- /cad-block__item-->
					<?php
				endwhile;
				wp_reset_postdata();
				?>
			</div>
			<!-- /cad-block__item-->
		<?php endif;
		?>
		<?php if ( $button ) { ?>
			<div class="card-block__bottom">
				<a href="<?php echo $url; ?>" class="btn" target="<?php echo $target; ?>"><?php echo $b_title; ?> <span class="icon-pointed-arrow"></span></a>
			</div>
			<!-- /.card-block__bottom-->
		<?php } ?>
	</div>
	<!-- /.container-->
</section>
    <!-- /.card-block-->