<?php 
$row = get_row( true );
if ( empty( $row ) ) return;
$title = $row['ss_title'];
$sub_title = $row['ss_sub_title'];
$content = $row['ss_content'];
$quote = $row['quote_text'];
$img = $row['ss_image'];
if ( $title || $sub_title ||$content || $img ||$quote ) { ?>
    <section class="choose-block">
        <div class="container">
            <?php if ( $title || $sub_title ) { ?>
                <div class="choose-block__heading">
                    <div class="heading has-border has-border--center">
                        <?php if ( $title ) { 
                            echo '<h4>'. $title .'</h4>';
                        } if ( $sub_title ) { 
                            echo '<h2>'. $sub_title .'</h2>';
                        } ?>
                    </div>
                </div>
                <!-- /.choose-block__heading-->
            <?php }
            if ( $content || $quote || $img ) { ?>
                <div class="choose-block__content double-column">
                    <div class="row">
                        <?php 
                        if ( $img ) {
                            $col = 'col-lg-6';
                            $size = 'column-md';
                            ?>
                            <div class="col-lg-6 column-lg">
                                <div class="choose-block__media double-column__media">
                                    <figure>
                                        <img src="<?php echo $img['url']; ?>" alt="<?php echo $img['alt']; ?>">
                                    </figure>
                                </div>
                                <!-- /.choose-block__media-->
                            </div>
                            <?php
                        }
                        else {
                            $col = 'col-lg-12';
                            $size = 'column-lg';
                        }
                        if ( $content || $quote )  { ?>
                            <div class="<?php echo $col.' '.$size; ?> align-self-center">
                                <div class="choose-block__info double-column__info">
                                    <?php echo $content; 
                                    if ( $quote ) { ?>
                                        <div class="green-bg">
                                            <?php echo $quote; ?>
                                        </div>
                                    <?php } ?>    
                                </div>
                            </div>
                        <?php } ?>
                    </div>
                </div>
            <?php } ?>    
            <!-- /.choose-block__content-->
        </div>
        <!-- /.container-->
    </section>
    <!-- /.choose-block-->
<?php } 