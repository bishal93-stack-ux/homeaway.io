<?php $rating = get_field('ss_testimonials_rating', get_the_ID()); ?>
<div class="col-sm-6 col-lg-4 card-item">
    <div class="card" data-fancybox data-src="#testimonials-popup<?php echo get_the_ID();?>" data-fix="height">
        <blockquote>
            <ul class="star-ratings">
            <?php if ( $rating == 1 ) {
                echo '<li><span class="icon-star"></span></li>';
            } else if (  $rating == 2 ){
                echo '<li><span class="icon-star"></span></li>
                <li><span class="icon-star"></span></li>';
            } else if ( $rating == 3 ) {
                echo '<li><span class="icon-star"></span></li>
                <li><span class="icon-star"></span></li>
                <li><span class="icon-star"></span></li>';
            } else if ( $rating == 4 ) {
                echo '<li><span class="icon-star"></span></li>
                <li><span class="icon-star"></span></li>
                <li><span class="icon-star"></span></li>
                <li><span class="icon-star"></span></li>';
            } else {
                echo '<li><span class="icon-star"></span></li>
                <li><span class="icon-star"></span></li>
                <li><span class="icon-star"></span></li>
                <li><span class="icon-star"></span></li>
                <li><span class="icon-star"></span></li>';
            } ?>
            </ul>
            <div class="author">
                <span><?php the_title();?></span>
            </div>
            <p><?php echo wp_trim_words(get_the_content(), 20, '...'); ?></p>
        </blockquote>
        <div id="testimonials-popup<?php echo get_the_ID();?>" class="testimonials-popup" style="display: none">
            <ul class="star-ratings">
            <?php if ( $rating == 1 ) {
                echo '<li><span class="icon-star"></span></li>';
            } else if (  $rating == 2 ){
                echo '<li><span class="icon-star"></span></li>
                <li><span class="icon-star"></span></li>';
            } else if ( $rating == 3 ) {
                echo '<li><span class="icon-star"></span></li>
                <li><span class="icon-star"></span></li>
                <li><span class="icon-star"></span></li>';
            } else if ( $rating == 4 ) {
                echo '<li><span class="icon-star"></span></li>
                <li><span class="icon-star"></span></li>
                <li><span class="icon-star"></span></li>
                <li><span class="icon-star"></span></li>';
            } else {
                echo '<li><span class="icon-star"></span></li>
                <li><span class="icon-star"></span></li>
                <li><span class="icon-star"></span></li>
                <li><span class="icon-star"></span></li>
                <li><span class="icon-star"></span></li>';
            } ?>
            </ul>
            <div class="author">
                <span><?php the_title();?></span>
            </div>
            <?php the_content();?>
        </div><!--/.testimonials-popup-->
    </div><!--/.card-->
</div><!--/.card-item-->