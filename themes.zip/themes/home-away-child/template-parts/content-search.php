<?php
/**
 * Template part for displaying results in search pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Home_Away_Child_Care_Center
 */
?>
<article id="post-<?php the_ID(); ?>" <?php post_class('blog__post-article'); ?>>
	<figure class="blog__post-img">
			<?php echo '<a href="' . esc_url(get_permalink()) . '">' ?>
			<?php if (has_post_thumbnail()) : the_post_thumbnail(); ?>
			<?php endif; ?>
			<?php echo '</a>'; ?>
		
	</figure>
	<!-- /.blog__post-img -->

	<div class="blog__post-content">
		<h2 class="blog__post-title">
<?php 
				the_title('<a href="' . esc_url(get_permalink()) . '">', '</a>'); ?>

		</h2>
		<!-- /.blog__post-title -->
		<div class="blog__post-meta">
				<div class="meta-item">
					<?php echo get_the_date('M j, Y'); ?>
				</div>
				<!-- /.meta-item -->
				<div class="meta-item">
					<?php echo 'by ' . get_the_author();; ?>
				</div>
				<!-- /.meta-item -->
			</div>
		<!-- .blog__post-meta -->
	<?php the_excerpt();?>
	<a href="<?php esc_url(the_permalink()); ?>" class="btn btn-primary">Read More <span class="icon-pointed-arrow"></span></a>
	</div>
	<!-- /.blog__post-content -->

</article>