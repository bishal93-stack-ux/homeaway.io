<?php

/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Home_Away_Child_Care_Center
 */
?>
<article id="post-<?php the_ID(); ?>" <?php post_class('blog__post-article'); ?>>
	<figure class="blog__post-img">
		<?php if (!is_singular()) : echo '<a href="' . esc_url(get_permalink()) . '">' ?>
			<?php if (has_post_thumbnail()) : the_post_thumbnail(); ?>
			<?php else : echo '<img src="' . home_url() . '/media/blog-img01.jpg" alt="Blog image">'; ?>
			<?php endif; ?>
			<?php echo '</a>'; ?>
		<?php else : ?>
			<?php if (has_post_thumbnail()) : the_post_thumbnail(); ?>
			<?php else : echo '<img src="' . home_url() . '/media/blog-img01.jpg" alt="Blog image">'; ?>
			<?php endif; ?>
		<?php endif; ?>
	</figure>
	<!-- /.blog__post-img -->

	<div class="blog__post-content">
		<h2 class="blog__post-title">
			<?php if (!is_singular()) :
				the_title('<a href="' . esc_url(get_permalink()) . '">', '</a>');
			endif; ?>
		</h2>
		<!-- /.blog__post-title -->
		<?php if (is_single()) { ?> <div class="meta-social"> <?php } ?>
			<div class="blog__post-meta">
				<div class="meta-item">
					<?php echo get_the_date('M j, Y'); ?>
				</div>
				<!-- /.meta-item -->
				<div class="meta-item">
					<?php category_name(get_the_ID()); ?>
				</div>
				<!-- /.meta-item -->
				<div class="meta-item">
					<?php echo 'by ' . get_the_author();; ?>
				</div>
				<!-- /.meta-item -->
			</div>
			<!-- .blog__post-meta -->
			<?php if (is_single()) { ?>
				<div class="list-wrap">
					<span class="share-social-text">Share on:</span>
					<ul class="list-inline share-social">
						<li class="list-inline-item"><a target="_blank" href="https://facebook.com/sharer/sharer.php?u=<?php echo get_permalink();?>"><img src="<?php echo get_template_directory_uri(); ?>/images/social-facebook.svg" alt="Facebook"></a></li>
						<li class="list-inline-item"><a target="_blank" href="https://twitter.com/intent/tweet?url=<?php echo esc_url(get_permalink());?>"><img src="<?php echo get_template_directory_uri(); ?>/images/social-twitter.svg" alt="Twitter"></a></li>
						<li class="list-inline-item"><a target="_blank" href="https://www.linkedin.com/sharing/share-offsite/?url=<?php echo esc_url(get_permalink());?>"><img src="<?php echo get_template_directory_uri(); ?>/images/social-linkedin.svg" alt="LinkedIn"></a></li>
					</ul>
				</div>
			<?php } ?>
			<?php if (is_single()) { ?></div><?php } ?>

		<?php if (is_single()) :
			the_content();
		else : ?>
			<p><?php echo wp_trim_words(wpautop(get_the_excerpt()), 82, '.'); ?></p>
			<a href="<?php esc_url(the_permalink()); ?>" class="btn btn-primary">Read More <span class="icon-pointed-arrow"></span></a>
		<?php endif; ?>
		</>
		<!-- /.blog__post-content -->

		<?php if (is_single()) { 
			$next_post = get_next_post();
			$prev_post = get_previous_post(); 
			if ( $next_post || $prev_post ) {
			?>
				<div class="post-nav">
					<?php  if ( ! empty( $next_post ) ) { 
						echo '<div class="post-nav-item post-nav-prev">
							<p>Previous Post</p>
							<a href="'. esc_url( get_permalink( $next_post->ID ) ) .'">'. get_the_title( $next_post->ID ) .'</a>
						</div>';
					} if ( ! empty( $prev_post ) ) { 
						echo '<div class="post-nav-item post-nav-next">
							<p>Next Post</p>
							<a href="'. esc_url( get_permalink( $prev_post->ID ) ) .'">'. get_the_title( $prev_post->ID ) .'</a>
						</div>';
					}  ?>
				</div>
		<?php }
		} ?>

</article>