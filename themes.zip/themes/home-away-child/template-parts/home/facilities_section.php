<?php 
$row = get_row( true );
if ( empty( $row ) ) return;
$heading = $row['ss_title'];
$sub_title = $row['ss_sub_title'];
$content = $row['ss_content'];
$cta = $row['ss_cta_button'];
 ?>
<section class="block block-facilities">
    <div class="container">
        <div class="block-facilities__wrap">
            <div class="row">
                <?php if( have_rows('ss_repearter_facilities') ) { ?>
                    <div class="col-lg-6 block-left">
                        <div class="block-left__wrap">
                            <div class="row no-gutters our-facility-slider">
                                <?php
                                $count = 1;
                                while ( have_rows('ss_repearter_facilities') ) { 
                                    the_row();
                                    $image = get_sub_field('ss_fa_image');
                                    $title = get_sub_field('ss_fa_title');
                                    /*if ( $count == 1 ) {
                                        $class = "leftaside";
                                    } else if ( $count == 3 ) {
                                        $class = "rightaside";
                                    }
                                    if ($count % 4 != 0 ) */{ ?>
                                    <div class="col-sm-6">
                                    <?php } ?>
                                        <div class="media-item">
                                            <div class="media-card">
                                                <div class="media-card__img bg-cover">
                                                    <?php if ( $image ) {
                                                        echo '<img src="'. $image['url'] .'" alt="'. $image['alt'] .'">';
                                                    }
                                                    if ( !empty( $title ) ) {
                                                        echo '<figcaption>
                                                            <div class="media-card__info">
                                                                <h6>'. $title .'</h6>
                                                            </div>
                                                        </figcaption>';
                                                    } ?>
                                                </div>
                                                <!--/.media-card__img -->
                                            </div>
                                            <!--/.media-card -->
                                        </div>
                                    <?php {
                                        echo '</div>';
                                }
                                $count++;
                                } ?>
                            </div>
                        </div>
                        <!--/.block-left__wrap -->
                    </div>
                <?php } ?>    
                <!--/.block-left -->

                <div class="col-lg-6 block-right">
                    <div class="content-holder">
                        <?php if ( $heading || $sub_title  ) { ?>
                            <div class="heading has-border">
                                <?php if ( $heading ) { 
                                    echo '<h4>'. $heading .'</h4>';
                                } 
                                if ( $sub_title ) { 
                                    echo '<h2>'. $sub_title .'</h2>';
                                } ?>
                            </div>
                        <?php }
                        echo $content;
                        if ( $cta ) {
                            echo '<a href="'. $cta['url'] .'" class="btn btn-phone"><span class="icon-telephone"></span>'. $cta['title'] .'</a>';;
                        } ?>
                    </div>
                    <!--/.content-holder -->
                </div>
                <!--/.block-right -->
            </div>
        </div>
        <!--/.block-facilities__wrap -->
    </div>
</section>
<!--/.block-facilities-->