<?php $row = get_row( true );
if ( empty( $row ) ) return;
$title = $row['ss_title']; 
$sub_title = $row['ss_sub_title'];
$content = $row['ss_content']; // Normal Content
$gallerys =get_sub_field('ss_gallery_images');
if ( $gallerys ) {
    $col_class = 'col-lg-6';
} else {
    $col_class = 'col-lg-12';
}
if ( $title || $description ||  $gallerys ) { ?>
 <section class="development-intro">
        <div class="container">
            <div class="development-intro__content double-column">
                <div class="row">
                    <?php if ( $gallerys  ){  ?>
                        <div class="col-lg-6">
                            <div class="development-intro__media double-column__media">
                                <div class="img-composition__img">
                                    <div class="img-composition__img img-composition__img-box">
                                        <?php $count = 1 ;
                                        foreach ( $gallerys as $gallery ){
                                            if ( $count == 1 ) {
                                                $c_class = 'one';
                                                $url = aq_resize( $gallery['url'], 425, 531, true, true, true );
                                            } else if(   $count == 2 ){ 
                                                $c_class = 'two';
                                                $url = aq_resize( $gallery['url'], 240, 231, true, true, true );
                                            } else if(   $count == 3 ){ 
                                                $c_class = 'three';
                                                $url = aq_resize( $gallery['url'], 130, 130, true, true, true );
                                            }
                                            else if(   $count == 4 ){ 
                                                $c_class = 'four';
                                                $url = aq_resize( $gallery['url'], 315, 202, true, true, true );
                                            }
                                            else if(   $count == 5 ){ 
                                                $c_class = 'five';
                                                $url = aq_resize( $gallery['url'], 130, 130, true, true, true );
                                            } ?>
                                            <div class="img-composition__img img-composition__img-box img-composition__img-box--<?php echo $c_class; ?>">
                                                <img src="<?php echo $url;?>" alt="<?php echo  $gallery['alt'];?>">
                                            </div>
                                        <?php  $count++;
                                        } ?>
                                    </div>
                                </div>
                                <!--/.img-composition__img -->
                            </div>
                            <!-- /.development-intro__media-->
                        </div>
                    <?php } 
                    if ( $title ||  $sub_title || $description )  { ?>
                        <div class="<?php echo $col_class; ?>  align-self-center">
                            <div class="development-intro__info double-column__info">
                                <div class="heading has-border">
                                 <?php if ( $title ) { 
                                        echo '<h4>'. $title .'</h4>';
                                    } 
                                    if ( $sub_title ) { 
                                        echo '<h2>'. $sub_title .'</h2>';
                                    } ?>
                                </div>
                                <?php if ( $content ) {
                                    echo  '<div class="paragraph-holder">';
                                        echo $content;
                                    echo '</div>';
                                } ?>
                                
                            </div>
                            <!-- /.development-introl__info-->
                        </div>
                    <?php } ?>    
                </div>
            </div>
            <!-- /.development-intro__content-->
        </div>
        <!-- /.container-->
    </section>
<?php }     