<?php 
$row = get_row( true );
if ( empty( $row ) ) return;
if ( have_rows( 'ss_home_block' ) ) { ?>
    <section class="schedule-apply">
        <div class="schedule-apply__wrap">
            <div class="schedule-apply__content">
                <?php
                $count = 1;
                while ( have_rows( 'ss_home_block' ) ) {
                    the_row();
                    if($count % 2 == 0){
                        $class = 'apply';
                     } else {
                        $class = 'schedule';
                     }
                     $title = get_sub_field('ss_title'); 
                     $cta = get_sub_field('ss_cta_button'); 
                     $description = get_sub_field('ss_sub_title');
                    if ( $title || $cta  ||  $description ) {
                        echo '<div class="'. $class .'">
                            <div class="schedule-apply__item">';
                                if ( $title ) {
                                    echo '<h3>'.$title.'</h3>';
                                }
                                echo  '<p>' .$description .'</p>';
                                if ( $cta ) {
                                    $link_target = $cta['target'] ? $cta['target'] : '_self';
                                    echo '<a href="'. $cta['url'] .'" target="'. $link_target .'" class="btn primary stretched-link">'. $cta['title'] .'</a>';
                                } 
                            echo '</div>
                        </div>';
                    }  
                    $count++;
                } ?>
                <!-- .apply -->
            </div>
            <!-- .schedule-apply__content -->
        </div>
        <!-- /.schedule-apply__wrap-->
    </section>
<?php }     