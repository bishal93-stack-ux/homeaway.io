<?php

$row = get_row(true);
if (empty($row)) return;
$title = $row['ss_title'];
$sub_title = $row['ss_sub_title'];
$posts = get_sub_field('ss_blog_choose_post');
if ($posts) { ?>
    <section class="home-blog">
        <div class="container">
            <div class="home-blog__wrap">
                <?php if ($title ||  $sub_title) {
                    echo '<div class="heading has-border has-border--center">';
                    if ($title) {
                        echo '<h4>' . $title . '</h4>';
                    }
                    if ($sub_title) {
                        echo '<h2>' . $sub_title . '</h2>';
                    }
                    echo '</div>';
                } ?>
                <div class="row">
                    <?php foreach ($posts as $post) {
                        setup_postdata($post); ?>
                        <div class="col-md-6 col-xl-4 home-blog__block">
                            <blockquote class="home-blog__item">
                                <figure>
                                    <?php if (has_post_thumbnail()) {
                                        the_post_thumbnail('home_blog');
                                    } else {
                                        echo '<img src="' . home_url('/media/blog-img1.jpg') . '" alt="Blog Image">';
                                    } ?>
                                    <div class="post-date">
                                        <span class="entry-date"><?php echo get_the_date('d M'); ?></span>

                                    </div>
                                </figure>
                                <div class="home-blog__content">
                                    <h4><a href="<?php the_permalink(); ?>" class="stretched-link"><?php the_title(); ?></a></h4>
                                    <p><?php 
                                    echo mb_strimwidth(get_the_excerpt(), 0, 110, '...');?></p>
                                    <div class="home-blog__details">
                                        <span><i class="icon-user"></i> <?php echo get_the_author(); ?></span>
                                        <!-- <span><i class="icon-comment"></i> 3</span> -->
                                        <a href="<?php the_permalink(); ?>" class="more">Read More</a>
                                    </div>
                                    <!-- /.home-blog__details-->
                                </div>
                                <!-- /.home-blog__content-->
                            </blockquote>
                            <!-- /.blockquote-->

                        </div>
                    <?php } ?>
                </div>
                <div class="btn-wrap text-center">
                    <a href="<?php echo home_url('/blog/'); ?>" class="btn btn-schedule">View All <span class="icon-pointed-arrow"></span></a>
                </div>
                <?php wp_reset_postdata(); ?>
                <!-- /.btn-wrap-->
            </div>
            <!-- /.home-blog__wrap-->
        </div>
    </section>
<?php }
