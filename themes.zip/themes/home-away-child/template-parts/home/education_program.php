<?php 
$row = get_row( true );
if ( empty( $row ) ) return;
$title = $row['ss_title'];
$sub_title = $row['ss_sub_title'];
$description = $row['ss_description'];
$program = $row['ss_choose_program'];
$cta = $row['ss_cta_button'];
?>
<div class="education-program">
    <section class="card-block areas-of-expertise">
        <div class="container">
            <?php if ( $title || $sub_title || $description ) { ?>
                <div class="card-block__heading areas-of-expertise__heading">
                    <div class="heading has-border has-border--center">
                        <?php if ( $title ) { 
                            echo '<h4>'. $title .'</h4>';
                        } 
                        if ( $sub_title ) { 
                            echo '<h2>'. $sub_title .'</h2>';
                        } ?>
                    </div>
                    <?php echo  '<p>' .$description .'</p>'; ?>
                </div>
            <?php }
            if ( $program ) {
                echo '<div class="card-block__content areas-of-expertise__content">';
                foreach ( $program as $p ) {
                    $post_id = $p->ID; ?>
                    <div class="card-block__item areas-of-expertise__item">
                        <div class="item-wrap">
                            <a href="<?php echo get_permalink( $post_id );?>" class="stretched-link"></a>
                            <div class="card-block__img bg-cover">
                                <?php $featured_img_url = get_the_post_thumbnail_url( $post_id ); 
                                $thumbnail_id = get_post_thumbnail_id( $post_id );
                                $alt = get_post_meta ( $thumbnail_id, '_wp_attachment_image_alt', true );
                                if ( $featured_img_url ) {
                                    echo '<img src="'. $featured_img_url .'" alt="'. $alt .'">';
                                } else {
                                    echo '<img src="'. site_url() .'/media/aoe-img1.png" alt="Infant Image">';
                                }?>
                                
                            </div>
                            <div class="card-block__text areas-of-expertise__text" data-fix="height">
                                <a href="<?php echo get_permalink( $post_id );?>"><?php echo get_the_title( $post_id );?></a>
                                <p><?php echo wp_trim_words(get_the_excerpt( $post_id ), 10, '...');?></p>
                            </div>
                        </div>
                        <!-- /.item-wrap-->
                    </div>
                <?php }

                echo '</div>';

            } ?>
            
            <!-- /.card-block__content-->
            <?php if ( $cta ) {
                $link_target = $cta['target'] ? $cta['target'] : '_self';
                echo '<div class="btn-wrap text-center">
                    <a class="btn" href="'. $cta['url'] .'">'. $cta['title'] .' <span class="icon-pointed-arrow"></span></a>
                </div>';
            } ?>
            <!-- /.card-block__bottom-->
        </div>
        <!-- /.container-->
    </section>
    <!-- /.card-block-->
</div>