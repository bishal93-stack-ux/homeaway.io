<?php 
$row = get_row( true );
if ( empty( $row ) ) return;
$title = $row['ss_title'];
$sub_title = $row['ss_sub_title'];
$testimonials = get_sub_field('ss_home_choose_testimonials');
if ( $testimonials ) { ?>
    <section class="home-testimonials bg-cover">
        <img src="<?php echo home_url('/media/testimonial-bgcover.jpg') ?>" alt="Two children laying down and laughing">
        <div class="home-testimonials__wrap">
            <?php if  ( $title  || $sub_title ) {
                echo '<div class="heading has-border has-border--center">';
                    if ( $title ) { 
                        echo '<h4>'. $title .'</h4>';
                    } 
                    if ( $sub_title ) { 
                        echo '<h2>'. $sub_title .'</h2>';
                    } 
                echo '</div>';
            } ?>
            <div class="home-testimonials__slider">
                <?php foreach( $testimonials as $t ) { 
                    $post_ID = $t->ID;
                    $rating = get_field('ss_testimonials_rating', $post_ID);?>
                    <div class="card-item">
                        <div class="card" data-fancybox data-src="#testimonials-popup<?php echo $post_ID;?>">
                            <blockquote>
                                <ul class="star-ratings">
                                <?php if ( $rating == 1 ) {
                                    echo '<li><span class="icon-star"></span></li>';
                                } else if (  $rating == 2 ){
                                    echo '<li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>';
                                } else if ( $rating == 3 ) {
                                    echo '<li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>';
                                } else if ( $rating == 4 ) {
                                    echo '<li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>';
                                } else {
                                    echo '<li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>';
                                } ?>
                                </ul>
                                <div class="author">
                                    <span><?php echo get_the_title($post_ID);?></span>
                                </div>
                                <?php
                                $content = get_post_field('post_content', $post_ID);
                                if ( !empty( $content ) ) {
                                    echo '<p>'.wp_trim_words($content, 25, '...').' </p>';
                                } ?>
                                 
                            </blockquote>
                            <div id="testimonials-popup<?php echo $post_ID;?>" class="testimonials-popup" style="display: none">
                                <ul class="star-ratings">
                                <?php if ( $rating == 1 ) {
                                    echo '<li><span class="icon-star"></span></li>';
                                } else if (  $rating == 2 ){
                                    echo '<li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>';
                                } else if ( $rating == 3 ) {
                                    echo '<li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>';
                                } else if ( $rating == 4 ) {
                                    echo '<li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>';
                                } else {
                                    echo '<li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>';
                                } ?>
                                </ul>
                                <div class="author">
                                    <span><?php echo get_the_title( $post_ID );?></span>
                                </div>
                                <?php if ( !empty( $content ) ) {
                                    echo '<p>'. $content .' </p>';
                                } ?>
                            </div>
                            <!--/.testimonials-popup-->
                        </div>
                        <!--/.card-->
                    </div>
                <?php } ?>
            </div>
            <!-- .home-testimonials__slider -->
        </div>
        <!-- .home-testimonials__wrap -->
    </section>
<?php } 