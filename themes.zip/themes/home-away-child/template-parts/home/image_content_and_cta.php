<?php 
$row = get_row( true );
if ( empty( $row ) ) return;
$title = $row['ss_title'];
$sub_title = $row['ss_sub_title'];
$content = $row['ss_content'];
$img = $row['ss_image'];
$cta = $row['ss_home_i_cta_button'];
if ( $img ) {
    $col = 'col-lg-6';
} else {
    $col = 'col-lg-12';
} 
if ( $title || $sub_title || $content || $img ) { ?>
    <section class="block block-about-us">
        <div class="two-col-full">
            <div class="double-column">
                <div class="row no-gutters">
                    <div class="<?php echo $col;?> double-column__info">
                        <div class="content-holder">
                            <?php if ( $title || $sub_title || $description ) { ?>
                                <div class="heading has-border">
                                    <?php if ( $title ) { 
                                        echo '<h4>'. $title .'</h4>';
                                    } 
                                    if ( $sub_title ) { 
                                        echo '<h2>'. $sub_title .'</h2>';
                                    } ?>
                                </div>
                                    <?php echo  $content; ?>
                            <?php } 
                            if ( $cta ){
                                $link_target = $cta['target'] ? $cta['target'] : '_self';
                                echo '<a href="'. $cta['url'] .'" target="'. $link_target .'" class="btn">'. $cta['title'] .' <span class="icon-pointed-arrow"></span></a>';
                            } ?>
                        </div>
                        <!--/.content-holder -->
                    </div>
                    <?php if ( $img ) { ?>
                        <div class="col-lg-6 bg-cover double-column__media">
                        <img src="<?php echo $img['url']; ?>" alt="<?php echo $img['alt']; ?>">
                        </div>
                    <?php } ?>    
                </div>
            </div>
            <!--/.double-column -->
        </div>
        <!--/.two-col-full -->
    </section>
    <!--/.block-about-us -->
<?php }     