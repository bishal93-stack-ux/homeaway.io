<?php 
$row = get_row( true );
if ( empty( $row ) ) return;
$title = $row['ss_title'];
$sub_title = $row['ss_sub_title'];
$develop = $row['ss_choose_development'];
if ( $title || $sub_title ||  $develop ){
?>
    <section class="block block-child-development">
        <div class="container">
            <?php if ( $title || $sub_title  ) { ?>
                <div class="heading has-border has-border--center">
                    <?php if ( $title ) { 
                        echo '<h4>'. $title .'</h4>';
                    } 
                    if ( $sub_title ) { 
                     echo '<h2>'. $sub_title .'</h2>';
                    } ?>
            </div>
            <?php }
            if ( $develop ) {
                echo '<div class="block-child-development__wrapper">
                    <div class="row">'; 
                        foreach ( $develop as $d ) {
                            $post_id = $d->ID;
                            $home_featured = get_field('ss_home_featured_image', $post_id);
                            ?>
                            <div class="col-lg-6 media-card__outer">
                                <div class="media-card">
                                    <div class="media-card__content">
                                        <h4><?php echo get_the_title( $post_id );?></h4>
                                        <p><?php echo wp_trim_words(get_the_excerpt( $post_id ),15 , '...' );?></p>
                                        <a href="<?php echo get_permalink( $post_id );?>" class="stretched-link">Read More</a>
                                    </div>
                                    <!--/.media-card__content-->

                                    <div class="media-card__image bg-cover">
                                        <?php $featured_img_url = get_the_post_thumbnail_url( $post_id ); 
                                        $thumbnail_id = get_post_thumbnail_id( $post_id );
                                        $alt = get_post_meta ( $thumbnail_id, '_wp_attachment_image_alt', true );
                                        if ( $home_featured ) {
                                            echo '<img src="'. $home_featured['url'] .'" alt="'. $home_featured['alt'] .'">';
                                        } else {
                                            if ( $featured_img_url ) {
                                                echo '<img src="'. $featured_img_url .'" alt="'. $alt .'">';
                                            } else {
                                                echo ' <img src="'. site_url() .'/media/child-dev1.jpg" alt="Cognitive Developme';
        ;                                   }
                                        }
                                         ?>
                                    </div>
                                    <!--/.media-card__image-->
                                </div>
                                <!--/.media-card-->
                            </div>
                        <?php  }
                    echo '</div>
                </div>'; 
            }?>
        </div>
    </section>
<?php }     