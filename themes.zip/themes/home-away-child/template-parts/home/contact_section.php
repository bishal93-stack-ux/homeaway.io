<?php 
$row = get_row( true );
if ( empty( $row ) ) return;
$title = $row['ss_title'];
$sub_title = $row['ss_sub_title'];
$description = $row['ss_description'];
$shortcode = $row['ss_home_e_form_shortcode'];
$img = $row['ss_home_c_image'];
if ( $img ) {
    $col = 'col-lg-6';
} else {
    $col = 'col-lg-12';
} 
if ( $title || $sub_title || $shortcode || $img ) { ?>
    <section class="block block-contact-form">
        <div class="row no-gutters">
            <?php if ( $img ) { ?>
                <div class="col-lg-6 bg-cover block-left">
                    <img src="<?php echo $img['url']; ?>" alt="<?php echo $img['alt']; ?>">
                </div>
            <?php }     
            if ( $title || $sub_title || $shortcode ) {  ?>
                <div class="<?php echo $col; ?> block-right">
                    <div class="content-holder">
                        <div class="heading has-border">
                            <?php if ( $title ) { 
                                echo '<h4>'. $title .'</h4>';
                            } 
                            if ( $sub_title ) { 
                                echo '<h2>'. $sub_title .'</h2>';
                            } ?>
                        </div>
                        <?php echo $description;
                    if ( $shortcode ) {
                        echo do_shortcode( $shortcode );
                    } ?>
                    </div>
                    <!--/.content-holder -->
                </div>
            <?php } ?>    
            <!--/.block-right -->
        </div>
    </section>
<?php } 