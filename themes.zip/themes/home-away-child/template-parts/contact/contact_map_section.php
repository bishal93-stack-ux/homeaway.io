<?php
$row = get_row(true);
if (empty($row)) return;
$map_img = $row['ss_map_image'];
?>
<!-- <section class="contact-map bg-cover">
	<?php
	// if ( $map_img ) { 
	?>
		<img src="<?php // echo $map_img['url']; 
					?>" alt="<?php // echo $map_img['alt']; 
								?>">
	<?php  // }
	// else { 
	?>
		<img src="<?php  //echo home_url('media/google-map.jpg'); 
					?>" alt="Map">
	<?php // } 
	?> -->
<?php if (have_rows('ss_map_address_title')) : ?>
	<!-- <div class="container"> -->
	<?php
	$location = array();
	$marker = "123";
	while (have_rows('ss_map_address_title')) : ?>
		<?php the_row();
		// $map_address = get_sub_field('ss_address');
		$map = get_sub_field('ss_map_address');
		$map_address = $map['address'];
		$lat = $map['lat'];
		$long = $map['lng'];

		if ($map_address) {
			$location[] = array($map_address, $lat, $long);
		?>
			<!-- <div class="location">
						<button>
							<span class="icon-pin"><span class="path1"></span><span class="path2"></span></span>
						</button>
						<div class="location__popup">
							<button>&times;</button>
							<p><?php echo $map_address; ?></p>
						</div>
					</div> -->
			<!-- end location -->
	<?php }
	endwhile;
	?>
	<!-- </div> -->
<?php endif; ?>
<!-- </section> -->
<div id="map" class="contact-map bg-cover" style="width: 100%; height: 700px;">
	<?php
	if ($map_img) { ?>
		<img src="<?php echo $map_img['url']; ?>" alt="<?php echo $map_img['alt']; ?>">
	<?php } else { ?>
		<img src="<?php echo home_url('media/google-map.jpg'); ?>" alt="Map">
	<?php } ?>
</div>

<style>
	.gm-style .gm-style-iw-c {
		border-radius: 0;
		padding: 0;
		max-width: 312px !important;
		width: 100%;
		text-align: center;
	}

	.gm-style-iw-d {
		max-height: 100% !important;
		overflow: hidden !important;
	}

	.gm-style .gm-style-iw-t::after {
		height: auto;
		width: auto;
		border-top: 15px solid #ef4232;
		border-left: 10px solid transparent;
		border-right: 10px solid transparent;
		transform: translateX(-50%);
	}

	.map-content {
		font-size: 15px;
		color: #fff;
		background-color: #ef4232;
		position: relative;
		z-index: 100;
		min-height: 90px;
		display: flex;
		align-items: center;
		justify-content: center;
		font-weight: 400;
		padding: 5px 10px;
	}

	.map-content:before {
		content: '';
		position: absolute;
		top: 0;
		left: 0;
		right: 0;
		bottom: 0;
		z-index: -1;
	}

	.map-content p {
		margin: 0;
	}

	.gm-ui-hover-effect {
		filter: invert(1);
		z-index: 100;
		opacity: 1;
	}
</style>

<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAayrthoAgoO5b_e_IKGdgUbpusHIaNoQc"></script>
<script type="text/javascript">
	var locations = <?php echo json_encode($location); ?>;

	var map = new google.maps.Map(document.getElementById('map'), {
		zoom: 14,
		center: new google.maps.LatLng(40.7569454, -74.034139),
		mapTypeId: google.maps.MapTypeId.ROADMAP,
		styles: [{
				"featureType": "all",
				"elementType": "geometry",
				"stylers": [{
					"color": "#202c3e"
				}]
			},
			{
				"featureType": "all",
				"elementType": "labels.text.fill",
				"stylers": [{
						"gamma": 0.01
					},
					{
						"lightness": 20
					},
					{
						"weight": "1.39"
					},
					{
						"color": "#ffffff"
					}
				]
			},
			{
				"featureType": "all",
				"elementType": "labels.text.stroke",
				"stylers": [{
						"weight": "0.96"
					},
					{
						"saturation": "9"
					},
					{
						"visibility": "on"
					},
					{
						"color": "#000000"
					}
				]
			},
			{
				"featureType": "all",
				"elementType": "labels.icon",
				"stylers": [{
					"visibility": "off"
				}]
			},
			{
				"featureType": "landscape",
				"elementType": "geometry",
				"stylers": [{
						"lightness": 30
					},
					{
						"saturation": "9"
					},
					{
						"color": "#29446b"
					}
				]
			},
			{
				"featureType": "poi",
				"elementType": "geometry",
				"stylers": [{
					"saturation": 20
				}]
			},
			{
				"featureType": "poi.park",
				"elementType": "geometry",
				"stylers": [{
						"lightness": 20
					},
					{
						"saturation": -20
					}
				]
			},
			{
				"featureType": "road",
				"elementType": "geometry",
				"stylers": [{
						"lightness": 10
					},
					{
						"saturation": -30
					}
				]
			},
			{
				"featureType": "road",
				"elementType": "geometry.fill",
				"stylers": [{
					"color": "#193a55"
				}]
			},
			{
				"featureType": "road",
				"elementType": "geometry.stroke",
				"stylers": [{
						"saturation": 25
					},
					{
						"lightness": 25
					},
					{
						"weight": "0.01"
					}
				]
			},
			{
				"featureType": "water",
				"elementType": "all",
				"stylers": [{
					"lightness": -20
				}]
			}
		]
	});

	var infowindow = new google.maps.InfoWindow();

	var marker, i;

	for (i = 0; i < locations.length; i++) {
		marker = new google.maps.Marker({
			position: new google.maps.LatLng(locations[i][1], locations[i][2]),
			map: map,
			icon: '<?php echo get_template_directory_uri(); ?>/images/marker.svg',
			// adding custom icons (Here I used a Flash logo marker)
			draggarble: false // If set to true you can drag the marker
		});

		google.maps.event.addListener(marker, 'click', (function(marker, i) {
			return function() {
				var popupString = '<div class="map-content"><p>' + locations[i][0] + '</p></div>';
				infowindow.setContent(popupString);
				infowindow.open(map, marker);
			}
		})(marker, i));
	}
</script>