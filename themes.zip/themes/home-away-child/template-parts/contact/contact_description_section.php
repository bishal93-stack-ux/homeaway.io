<?php 
$row = get_row( true );
if ( empty( $row ) ) return;
$phone_title = $row['ss_phone_title'];
$email_title = $row['ss_email_title'];
$address_title = $row['ss_address_title'];
// Form Section
$form_title = $row['ss_form_title'];
$form_sub_title = $row['ss_form_sub_title'];
$form_desc = $row['ss_form_short_description'];
$form_shortcode = $row['ss_form_shortcode'] ? $row['ss_form_shortcode'] : '[gravityform id="1" title=flase description=false ajax=true]'; 
// From Theme Setting Footer
$phone_num = get_field('ss_footer_phone_number','option');
$email = get_field('ss_footer_email_address','option');
?>
<section class="contact">
	<div class="container">
		<div class="row">
			<div class="col-lg-5">
				<div class="contact__info">
					<?php if ( $phone_title || $phone_num ) { ?>
						<div class="contact-item icon-call-bold">
							<?php if ( $phone_title ) { ?>
								<h5><?php echo $phone_title; ?></h5>
							<?php } ?>
							<?php if ( $phone_num ) { ?>
								<p><a href="tel:<?php echo preg_replace('/[^0-9]/', '', $phone_num); ?>"><?php echo $phone_num; ?></a></p>
							<?php } ?>
						</div>
						<!-- end .contact-item -->
					<?php } ?>
					<?php if ( $email_title || $email ) { ?>
						<div class="contact-item icon-envelope">
							<?php if ( $email_title ) { ?>
								<h5><?php echo $email_title; ?></h5>
							<?php } ?>
							<?php if ( $email ) { ?>
								<p><a href="mailto:<?php echo $email; ?>"><?php echo $email; ?></a></p>
							<?php } ?>
						</div>
						<!-- end .contact-item -->
					<?php } ?>
					<div class="contact-item icon-home">
						<h5><?php echo $address_title; ?></h5>
						<?php if ( have_rows('ss_locations') ) : ?>
							<ul>
								<?php while ( have_rows('ss_locations') ) : ?>
									<?php the_row();
									$heading = get_sub_field('ss_heading');
									$addresses = get_sub_field('ss_addresses');
									$addresses_link = get_sub_field('ss_addresses_link');
									?>
									<li>
										<?php if ( $heading ) { ?>
											<h6><?php echo $heading; ?></h6>
										<?php } ?>
										<?php if ( $addresses ) { ?>
											<p><a href="<?php echo $addresses_link; ?>" target="_blank"><?php echo $addresses; ?></a></p>
										<?php } ?>
									</li>
								<?php endwhile; ?>
							</ul>
						<?php endif; ?>
					</div>
					<!-- end .contact-item -->
				</div>
				<!-- end .contact__info -->
			</div>
			<div class="col-lg-7">
				<div class="contact__form">
					<?php if ( $form_sub_title || $form_title || $form_desc ) { ?>
						<div class="contact__title">
							<div class="heading has-border has-border--center">
								<?php if ( $form_title ) { ?>
									<h4><?php echo $form_title; ?></h4>
								<?php } ?>
								<?php if ( $form_sub_title ) { ?>
									<h2><?php echo $form_sub_title; ?></h2>
								<?php } ?>
							</div>
							<!-- end .heading -->
							<?php if ( $form_desc ) { ?>
								<p><?php echo $form_desc; ?></p>
							<?php } ?>
						</div>
						<!-- end .contact__title -->
					<?php } ?>
					<?php echo do_shortcode($form_shortcode); ?>
				</div>
				<!-- end .contact__form -->
			</div>
		</div>
	</div>
</section>
	<!-- end .contact -->