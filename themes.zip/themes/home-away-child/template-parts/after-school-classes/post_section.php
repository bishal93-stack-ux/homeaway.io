<?php 
$row = get_row( true );
if ( empty( $row ) ) return;
$title = $row['ss_title'];
$sub_title = $row['ss_sub_title'];
$description = $row['ss_description'];
$cta = $row['ss_cta_button'];
$args = array(
    'post_type' => 'haccc_classes',
    'status' => 'publish',
    'posts_per_page' => -1,
);
?>
<section class="card-block card-block--provide">
    <div class="container-fluid">
        <div class="card-block__heading">
            <div class="heading has-border has-border--center">
                <?php if ( $title ) { 
                    echo '<h4>'. $title .'</h4>';
                } 
                if ( $sub_title ) { 
                    echo '<h2>'. $sub_title .'</h2>';
                } ?>
            </div>
            <?php echo  $description; ?>
        </div>
        <?php $loop = new Wp_Query($args);
        if ($loop->have_posts()) { 
            echo '<div class="card-block__content">';
                while ($loop->have_posts()) {
                    $loop->the_post(); ?>
                    <div class="card-block__item">
                        <div class="item-wrap">
                                <div class="card-block__img bg-cover">
                                    <?php if ( has_post_thumbnail() ) {
                                        the_post_thumbnail();
                                    } else {
                                        echo ' <img src="'. site_url() .'/media/aoe-img1.jpg" alt="Infant Image">';
                                    } ?>
                                </div>
                            <div class="card-block__text" data-fix="height">
                                <h5>
                                <a href="<?php the_permalink();?>" class="stretched-link"><?php the_title();?></a>	</h5>
                                <?php
                                if ( !empty( get_the_excerpt() ) ) {
                                    echo '<p>'. wp_trim_words( get_the_excerpt(), 10 ) .'</p>';
                                }  ?>
                            </div>
                        </div>
                        <!-- /.item-wrap-->
                    </div>
                <?php } 
                wp_reset_postdata();    
            echo '</div>';
        }
        if ( $cta ) {
            $link_target = $cta['target'] ? $cta['target'] : '_self';
            echo '<div class="card-block__bottom">
                <a class="btn btn-primary" href="'. $cta['url'] .'">'. $cta['title'] .' <span class="icon-pointed-arrow"></span></a>
            </div>';
        } ?>      
    </div>
    <!-- /.container-->
</section>