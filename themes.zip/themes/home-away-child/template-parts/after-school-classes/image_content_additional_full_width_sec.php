<?php
$row = get_row( true );
if ( empty( $row ) ) return;
$title = $row['ss_title'];
$sub_title = $row['ss_sub_title'];
$content = $row['ss_content'];
$img = $row['ss_image'];
$addi_sec = $row['ss_additional_section'];
if ( $img ) {
    $lg = 'col-lg-6';
    $xxl = 'col-xxl-5';
}
else {
    $lg = 'col-lg-12';
    $xxl = 'col-xxl-12';
}
if ( $title || $sub_title || $content || $img || $addi_sec ) { ?>
    <section class="benefit-program">
        <?php if ( $title || $sub_title ) { ?>
            <div class="heading has-border has-border--center">
                <?php if ( $title ) { 
                        echo '<h4>'. $title .'</h4>';
                    } 
                    if ( $sub_title ) { 
                        echo '<h2>'. $sub_title .'</h2>';
                    } ?>
            </div>
            <!-- end .heading -->
        <?php } ?>
        <?php if ( $content || $addi_sec || $img ) { ?>
            <div class="container">
                <div class="benefit-program__content double-column">
                    <div class="row no-gutters">
                        <?php if ( $content || $addi_sec ) { ?>
                            <div class="<?php echo $xxl.' '.$lg; ?> order-lg-1 order-2">
                                <div class="benefit-program__info double-column__info">
                                    <?php if ( $content ) { ?>
                                        <div class="text-primary"><strong><?php echo $content; ?> </strong></div>
                                    <?php }
                                    echo $addi_sec; 
                                    ?> 
                                </div>
                                <!-- /.benefit-program__info-->
                            </div>
                        <?php } ?>
                        <?php if ( $img ) { ?>
                            <div class="col-xxl-7 col-lg-6 order-lg-2 order-1">
                                <div class="benefit-program__media double-column__media">
                                 <?php      echo '    <figure>
                                 <img src="'. $img['url'] .'" alt="'. $img['alt'] .'">
                                 </figure>'; ?>
                             </div>
                             <!-- /.benefit-program__media-->
                         </div>
                     <?php } ?>
                 </div>
             </div>
             <!-- /.benefit-program__content-->
         </div>
         <!-- /.container-->
     <?php } ?>
 </section>
 <!-- end .benefit-program -->
<?php } 
