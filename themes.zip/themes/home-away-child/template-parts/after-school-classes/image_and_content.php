<?php
$row = get_row( true );
if ( empty( $row ) ) return;
$title = $row['ss_title'];
$sub_title = $row['ss_sub_title'];
$content = $row['ss_content'];
$img = $row['ss_image'];
if ( $img ) {
    $col = 'col-lg-6';
}
else {
    $col = 'col-lg-12';
}
if ( $title || $content ||  $img  || $sub_title ) { ?>
    <section class="after-school-about">
        <div class="container">
            <div class="row double-column">
                <?php if ( $title || $sub_title || $content ) { ?>
                    <div class="<?php echo $col; ?> order-lg-1 order-2">
                        <div class="double-column__info">
                            <div class="heading has-border">
                                <?php if ( $title ) {
                                    echo '<h4>'. $title .'</h4>';
                                }
                                if ( $sub_title ) {
                                    echo '<h2>'. $sub_title .'</h2>';
                                } ?>
                            </div>
                            <?php echo $content; ?>
                        </div>
                        <!-- end .double-column__info -->
                    </div>
                <?php } ?>
                <?php if ( $img ) { ?>
                    <div class="col-lg-6 order-lg-2 order-1">
                        <div class="double-column__media">
                            <figure>
                                <img src="<?php echo $img['url']; ?>" alt="<?php echo $img['alt']; ?>">
                            </figure>
                        </div>
                        <!-- end .double-column__media -->
                    </div>
                <?php } ?>
            </div>
        </div>
    </section>
    <!-- end . after-school-about -->
<?php } 