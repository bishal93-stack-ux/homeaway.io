<?php 
$row = get_row( true );
if ( empty( $row ) ) return;
$title = $row['ss_title'];
$sub_title = $row['ss_sub_title'];
$content = $row['ss_content'];
$img = $row['ss_image'];
if ( $img ) {
    $col_block = 'col-lg-5 block-left';
}
else {
    $col_block = 'col-lg-12 block-left';
}
if ( $title || $sub_title || $content ||$img ) {
    ?>
    <section class="ls-choose">
        <div class="ls-choose__wrapper">
            <div class="container">
                <div class="row align-items-center">
                    <div class="<?php echo $col_block; ?>">
                        <div class="ls-choose__content">
                            <?php if ( $title || $sub_title ) { ?>
                                <div class="heading has-border">
                                    <h3><?php echo $title.' '.$sub_title; ?></h3>
                                </div>
                            <?php } ?>
                            <?php echo $content; ?>
                        </div>
                        <!--/.ls-intro__content-->
                    </div>
                    <!--//block-left-->
                    <?php if ( $img ) { ?>
                        <div class="col-lg-7 block-right">
                            <div class="ls-choose__media">
                                <figure>
                                    <img src="<?php echo $img['url']; ?>" alt="<?php echo $img['alt']; ?>">
                                </figure>
                            </div>
                            <!--/.ls-choose__media-->
                        </div>
                        <!--/.block-right-->
                    <?php } ?>
                </div>
            </div>
        </div>
        <!--/.ls-choose__wrapper-->
    </section>
    <!--/.ls-choose-->
    <?php } ?>