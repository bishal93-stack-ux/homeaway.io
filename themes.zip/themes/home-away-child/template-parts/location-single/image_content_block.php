<?php if ( have_rows('ss_repeated_section') ) : ?>
    <section class="ls-services">
        <div class="container">
            <div class="ls-services__wrap">
                <div class="card-deck justify-content-center">
                    <?php while ( have_rows('ss_repeated_section') ) : ?>
                        <?php the_row();
                        $title = get_sub_field('ss_title');
                        $img = get_sub_field('ss_image');
                        $content = get_sub_field('ss_content');
                        ?>
                        <div class="col-md-6 col-lg-4 card-item">
                            <div class="card" data-fix="height">
                                <?php if ( $img ) { ?>
                                    <div class="card-img">
                                        <figure>
                                            <img src="<?php echo $img['url']; ?>" alt="<?php echo $img['alt']; ?>">
                                        </figure>
                                    </div>
                                    <!--/.card-img-->
                                <?php } ?>
                                <?php if ( $title || $content ) { ?>
                                    <div class="card-body">
                                        <?php if ( $title ) { ?>
                                            <h5><?php echo $title; ?><br>
                                                <?php the_title(); ?></h5>
                                            <?php } ?>
                                            <?php if ( $content ) { ?>
                                                <p><?php echo $content; ?></p>
                                            <?php } ?>
                                        </div>
                                        <!--/.card-body-->
                                    <?php } ?>
                                </div>
                                <!--/.card-->
                            </div>
                            <!--/.card-item-->
                        <?php endwhile; ?>
                    </div>
                    <!--.card-deck-->
                </div>
            </div>
        </section>
        <!--/.ls-services-->
        <?php endif; ?>