<?php 
$row = get_row( true );
if ( empty( $row ) ) return;
$title = $row['ss_title'];
$sub_title = $row['ss_sub_title'];
$content = $row['ss_content'];
$img = $row['ss_image'];
if ( $img ) {
    $col_block = 'col-lg-6 block-right';
}
else {
    $col_block = 'col-lg-12 block-left';
}
if ( $img || $title || $sub_title || $content ) { 
    ?>    
    <section class="ls-intro">
        <div class="ls-intro__wrapper">
            <div class="container">
                <div class="row align-items-center ls-intro--row">
                    <?php if ( $img ) { ?>
                        <div class="col-lg-6 block-left">
                            <div class="ls-intro__media">
                                <figure>
                                    <img src="<?php echo $img['url']; ?>" alt="<?php echo $img['alt']; ?>">
                                </figure>
                            </div>
                            <!--/.ls-intro__media-->
                        </div>
                        <!--//block-left-->
                    <?php } ?>
                    <?php if ( $title || $sub_title || $content ) { ?>
                        <div class="<?php echo $col_block; ?>">
                            <div class="ls-intro__content">
                                <?php if ( $title || $sub_title ) { ?>
                                    <div class="heading has-border">
                                        <?php if ( $title ) { ?>
                                            <h3><?php echo $title; ?>
                                        <?php } ?>
                                        <br>
                                        <?php if ( $sub_title ) { ?>
                                            <?php echo $sub_title; ?>
                                        <?php } ?>
                                    </h3>
                                </div>
                            <?php } 
                            echo $content; ?>
                            
                        </div>
                        <!--/.ls-intro__content-->
                    </div>
                    <!--/.block-right-->
                <?php } ?>
            </div>
            <!--/.ls-intro--row-->
        </div>
    </div>
    <!--/.ls-intro__wrapper-->
</section>
<!--/.ls-intro-->
<?php } ?>