<?php 
$row = get_row( true );
if ( empty( $row ) ) return;
$title = $row['ss_title'];
$content = $row['ss_content'];
$bg_img = $row['ss_background_image'];
?>
<section class="ls-about bg-cover text-center">
    <?php if ( $bg_img ) { ?>
        <img src="<?php echo $bg_img['url']; ?>" alt="<?php echo $bg_img['alt']; ?>">
    <?php }
    else { ?>
        <img src="<?php echo site_url('/media/location-single-about-bg.jpg'); ?>" alt="Location Single About Bg">
    <?php } ?>
    <?php if ( $title || $content ) { ?>
        <div class="container">
            <div class="ls-about__wrapper">
                <div class="ls-about__content">
                    <?php if ( $title ) { ?>
                        <div class="heading">
                            <h2><?php echo $title; ?></h2>
                        </div>
                        <!--/.heading-->
                    <?php } ?>
                    <?php if ( $content ) { ?>
                        <div class="text-wrap">
                            <?php echo $content; ?>
                        </div>
                        <!--/.text-wrap-->
                    <?php } ?>
                </div>
            </div>
            <!--/.ls-about__wrapper-->
        </div>
    <?php } ?>
</section>
    <!--/.ls-about-->