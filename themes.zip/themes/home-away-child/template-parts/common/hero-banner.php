<?php 
$image =  get_field('ss_hero_banner_image');
$heading =  get_field('ss_hero_title');
if ( $heading ){
    $title = $heading;
} else {
    $title = get_the_title();
}
if ( $image ) {
    $banner_img = $image['url'];
    $banner_alt = $image['alt'];
}
else if ( is_home() ) {
    $blog_id = get_option( 'page_for_posts' );
    $imageblog =  get_field('ss_hero_banner_image', $blog_id);
        if ( $imageblog ) {
            $banner_img = $imageblog['url'];
            $banner_alt = $imageblog['alt'];
        }  else {
            $banner_img = site_url().'/media/about-banner-bg.jpg';
            $banner_alt = 'About Us Banner Image';
        }

} else {
     if ( is_singular('post') || is_404() || is_search() ) {
        $banner_img = site_url().'/media/blog-inner.png';
        $banner_alt = 'Blog Us Banner Image';
    } else if ( is_singular('haccc_development') || is_singular('haccc_classes') ||  is_singular('haccc_programs') ) {
        $banner_img = site_url().'/media/infant-banner.jpg';
        $banner_alt = 'About Us Banner Image';
    } else if ( is_singular('haccc_location')) {
        $banner_img = site_url().'/media/location-single-banner.png';
        $banner_alt = 'Location Banner Image';
    } else {
        $banner_img = site_url().'/media/about-banner-bg.jpg';
        $banner_alt = 'About Us Banner Image';
    }
}
 ?>
<div class="banner bg-cover banner__inner">
    <img src="<?php echo $banner_img; ?>" alt="<?php echo $banner_alt;?>">
    <div class="container text-center">
        <div class="banner-caption text-center">
            <?php if ( is_archive() ){
                    $current_term = single_term_title( "", false );
                    // echo '<h1>'. $current_term .'</h1>';   
                    echo '<h1>'. get_the_archive_title() .'</h1>';   
                } else if ( is_home() ) {
                    echo '<h1>';
                    single_post_title();
                    echo '</h1>';
                } else if( is_search() ) {
                    echo '<h1>Search Results for: '. get_search_query() .'</h1>';
                } else if ( is_404() ) {
                    echo '<h1>404 Error </h1>';
                } else {
                    echo '<h1>'. $title .' </h1>';
                } ?>
            <?php
            if (function_exists('yoast_breadcrumb')) {
                yoast_breadcrumb('<div class="breadcrumbs">', '</div>');
            }
            ?>
        </div>
    </div>
</div>