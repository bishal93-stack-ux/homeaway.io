<?php
// Home Banner
$heading = get_field( 'ss_hero_home_title');
$sub_title = get_field( 'ss_hero_home_sub_title');
$description = get_field( 'ss_hero_home_description');
$image = get_field( 'ss_hero_home_banner_image');
$cta1 = get_field( 'ss_hero_btn_rep');
if ( $image ) {
    $banner_img = $image['url'];
    $banner_alt = $image['alt'];
} else {
    $banner_img = site_url('/media/banner-img.jpg'); 
    $banner_alt = 'Banner Img';
}
?>
<div class="banner text-center bg-cover banner__home">
    <img src="<?php echo $banner_img; ?>" alt="<?php echo $banner_alt;?>">
    <div class="container">
        <div class="banner-contents">
            <?php if ( $heading || $sub_title || $description ) {
                echo '<div class="section-heading">';
                    if ( !empty( $heading ) )  {
                        echo '<h3>'. $heading .'</h3>';
                    }
                    if ( !empty( $description ) ) {
                        echo '<div class="main-heading">
                            '. $description .'
                        </div>';
                    }
                    echo '<span class="triangle"></span>';
                    if ( !empty( $sub_title ) ){
                        echo '<h1>'. $sub_title .'</h1>';
                    }
                echo '</div>';   
            }
            if( have_rows('ss_hero_btn_rep') ) {
                echo '<div class="banner-buttons">';
                while ( have_rows('ss_hero_btn_rep') ) {
                     the_row();
                     $link = get_sub_field('ss_hero_btn_link');
                     $color = get_sub_field('color');
                    if ( $color == 'green' ) {
                        $btn_class = 'btn-schedule';
                        $span_class = 'icon-pointed-arrow';
                    } else if ( $color == 'blue' ) {
                        $btn_class = 'btn-enroll';
                        $span_class = 'icon icon-pointed-arrow';
                    }
                    if ( $link ) {
                        $link_target = $link['target'] ? $link['target'] : '_self';
                        echo '<a href="'. $link['url'] .'" class="btn '. $btn_class .'" target="'. $link_target .'">'. $link['title'] .' <span class="'. $span_class .'"></span></a>';
                    }
                }
                echo '</div>';
            }
            ?>
            <!--/.banner-buttons -->
        </div>
        <!--/.banner-contents -->
    </div>
</div>