<?php 
$row = get_row( true );
if ( empty( $row ) ) return;
$bold = $row['ss_title'];
$description = $row['ss_description'];
$gallerys =get_sub_field('ss_gallery_images');
if ( $gallerys ) {
    $lg = 'col-lg-6';
    $xl = 'col-xl-5';
} else {
    $lg = 'col-lg-12';
    $xl = 'col-xl-12';
}
if ( $title || $description ||  $gallerys ) { ?>
    <section class="academic-development">
        <div class="container">
            <div class="academic-development__content double-column">
                <div class="row">
                    <?php if ( $gallerys ) { ?>
                        <div class="col-lg-6 col-xl-7">
                            <div class="academic-development__media double-column__media">
                                <div class="img-composition__img">
                                    <div class="img-composition__img img-composition__img-box">
                                        <?php $count = 1 ;
                                        foreach ( $gallerys as $gallery ){
                                            if ( $count == 1 ) {
                                                $c_class = 'one';
                                                $url = aq_resize( $gallery['url'], 425, 531, true, true, true );
                                            } else if(   $count == 2 ){ 
                                                $c_class = 'two';
                                                $url = aq_resize( $gallery['url'], 240, 231, true, true, true );
                                            } else if(   $count == 3 ){ 
                                                $c_class = 'three';
                                                $url = aq_resize( $gallery['url'], 130, 130, true, true, true );
                                            }
                                            else if(   $count == 4 ){ 
                                                $c_class = 'four';
                                                $url = aq_resize( $gallery['url'], 315, 202, true, true, true );
                                            }
                                            else if(   $count == 5 ){ 
                                                $c_class = 'five';
                                                $url = aq_resize( $gallery['url'], 130, 130, true, true, true );
                                            } ?>
                                            <div class="img-composition__img img-composition__img-box img-composition__img-box--<?php echo $c_class; ?>">
                                                <img src="<?php echo $url;?>" alt="<?php echo  $gallery['alt'];?>">
                                            </div>
                                            <?php  $count++;
                                        } ?>
                                    </div>
                                </div>
                            </div>
                            <!-- /.academic-development__media-->
                        </div>
                    <?php } ?>
                    <?php if ( $bold || $description ) { ?>
                        <div class="<?php echo $lg.' '.$xl; ?> align-self-center">
                            <div class="academic-development__info double-column__info">
                                <?php if ( $bold ) { ?>
                                    <div class="bold-text">
                                        <p><?php echo $bold; ?></p>
                                    </div>
                                <?php } ?>
                                <?php if ( $description ) { ?>
                                    <p><?php echo $description; ?></p>
                                </div>
                                <!-- /.academic-developmentl__info-->
                            <?php } ?>
                        </div>
                    <?php } ?>
                </div>
            </div>
            <!-- /.academic-development__content-->
        </div>
        <!-- /.container-->
    </section>
    <!-- /.academic-development-->
<?php } 
