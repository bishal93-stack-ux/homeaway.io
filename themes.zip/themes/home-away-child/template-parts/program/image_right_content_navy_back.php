<?php 
$row = get_row( true );
if ( empty( $row ) ) return;
$title = $row['ss_title'];
$sub_title = $row['ss_sub_title'];
$content = $row['ss_content'];
$img = $row['ss_image'];
if ( $img ) {
    $lg = 'col-lg-6';
}
else {
    $lg = 'col-lg-12';
}
if ( $title || $sub_title || $content || $img ) { ?>
    <section class="benefit-education">
        <div class="container">
            <div class="benefit-education__content">
                <div class="row align-items-center">
                   <?php if ( $title || $sub_title || $content ) { ?>
                    <div class="<?php echo $lg; ?> benefit-education__info">
                       <?php if ( $title || $sub_title ) { ?>
                        <div class="heading has-border">
                            <?php if ( $title ) { ?>
                                <h4><?php echo $title; ?></h4>
                            <?php } ?>
                            <?php if ( $sub_title ) { ?>
                                <h2><?php echo $sub_title; ?></h2>
                            <?php } ?>
                        </div>
                    <?php }  
                    echo $content; 
                    ?>
                </div>
                <!-- /.benefit-education__info-->
            <?php } ?>
            <?php if ( $img ) { ?>
                <div class="col-lg-6 benefit-education__media">
                    <figure>
                        <img src="<?php echo $img['url']; ?>" alt="<?php echo $img['alt']; ?>">
                    </figure>
                </div>
                <!-- /.benefit-education__media-->
            <?php } ?>
        </div>
    </div>
    <!-- /.benefit-education__content-->
</div>
<!-- /.container-->
</section>
<!-- /.benefit-education-->
<?php } ?>