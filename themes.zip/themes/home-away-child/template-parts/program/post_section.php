<?php 
$row = get_row( true );
if ( empty( $row ) ) return;
$title = $row['ss_title'];
$sub_title = $row['ss_sub_title'];
$description = $row['ss_description'];
$cta = $row['ss_cta_button'];
$ids_args = [
    'post_type' => 'haccc_programs',
    'status' => 'publish',
    'posts_per_page' => -1,
];
$all_posts_ids = get_posts( $ids_args );
$all_post = [];
foreach ( $all_posts_ids as $post ) {
    $all_post[] = get_the_ID();
}
$move_to_front   = [175];
$post_ids_merged = array_merge( $move_to_front, $all_post );
$reordered_ids   = array_unique( $post_ids_merged );
$args =  [
    'post_type' => 'haccc_programs',
    'status' => 'publish',
    'posts_per_page' => -1,
    'post__in'       => $reordered_ids,
    'orderby'        => 'post__in',
    'order'          => 'ASC',
];
?>
<section class="card-block areas-of-expertise">
    <div class="container">
        <?php if ( $title || $sub_title || $description ) { 
            echo '<div class="card-block__heading areas-of-expertise__heading">';
                if ( $title || $sub_title ) { 
                    echo '<div class="heading has-border has-border--center">';
                        if ( $title ) { 
                            echo '<h4>'. $title .'</h4>';
                        } 
                        if ( $sub_title ) { 
                            echo '<h2>'. $sub_title .'</h2>';
                        } 
                    echo '</div>';
                } if ( $description ) { 
                        echo '<p>'. $description .'</p>';
                } 
            echo '</div>';
        } 
        $loop = new Wp_Query($args);
        if ($loop->have_posts()) { 
            echo '<div class="card-block__content areas-of-expertise__content">';
            $count =1; 
            while ($loop->have_posts()) {
                $loop->the_post();
                $id = get_the_ID();
                if ( $id == 175  ) { ?>
                <div class="card-block__item areas-of-expertise__item">
                    <div class="item-wrap">
                        <a href="<?php the_permalink();?>" class="stretched-link"></a>
                        <div class="card-block__img bg-cover">
                            <?php if ( has_post_thumbnail() ) {
                                the_post_thumbnail();
                            } else {
                                echo ' <img src="'. site_url() .'/media/aoe-img1.jpg" alt="Infant Image">';
                            } ?>
                        </div>
                        <div class="card-block__text areas-of-expertise__text" data-fix="height">
                            <a href="<?php the_permalink();?>"><?php the_title();?></a>
                            <?php
                                    if ( !empty( get_the_excerpt() ) ) {
                                    echo '<p>'. wp_trim_words( get_the_excerpt(), 10 ) .'</p>';
                                }  ?>
                        </div>
                    </div>
                <!-- /.item-wrap-->
                </div>
                <?php } else { ?>
                    <div class="card-block__item areas-of-expertise__item">
                    <div class="item-wrap">
                        <a href="<?php the_permalink();?>" class="stretched-link"></a>
                        <div class="card-block__img bg-cover">
                            <?php if ( has_post_thumbnail() ) {
                                the_post_thumbnail();
                            } else {
                                echo ' <img src="'. site_url() .'/media/aoe-img1.jpg" alt="Infant Image">';
                            } ?>
                        </div>
                        <div class="card-block__text areas-of-expertise__text" data-fix="height">
                            <a href="<?php the_permalink();?>"><?php the_title();?></a>
                            <?php
                                 if ( !empty( get_the_excerpt() ) ) {
                                    echo '<p>'. wp_trim_words( get_the_excerpt(), 10 ) .'</p>';
                                }  ?>
                        </div>
                    </div>
                    <!-- /.item-wrap-->
                </div>
                
            <?php } 
            } 
            wp_reset_postdata();    
            echo '</div>';
        } ?> 
        <div class="card-block__bottom areas-of-expertise__bottom">
            <a class="btn collapsed" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" href="#"><?php echo $cta['title']; ?> <span class="icon-pointed-arrow"></span></a>
        </div>
        <!-- /.card-block__bottom-->     
    </div>
    <!-- /.container-->
</section> 
