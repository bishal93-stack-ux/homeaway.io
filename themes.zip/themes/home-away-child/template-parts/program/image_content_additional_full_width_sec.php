<?php
$row = get_row( true );
if ( empty( $row ) ) return;
$title = $row['ss_title'];
$sub_title = $row['ss_sub_title'];
$content = $row['ss_content'];
$img = $row['ss_image'];
$addi_sec = $row['ss_additional_section'];
if ( $img ) {
    $col = 'col-lg-6';
}
else {
    $col = 'col-lg-12';
}
if ( $title || $content ||  $img ||  $addi_sec || $sub_title ) { ?>
    <section class="about-education">
        <div class="container">
            <div class="row align-items-center">
                <?php if ( $title || $sub_title || $content ) { 
                    echo '<div class="'. $col .' about-education__content">';
                        if ( $title || $sub_title ) { 
                            echo '<div class="heading has-border">';
                                if ( $title ) { 
                                    echo '<h4>'. $title .'</h4>';
                                }
                                if ( $sub_title ) { 
                                    echo '<h2>'. $sub_title .'</h2>';
                                } 
                            echo '</div>';
                            
                        } 
                        echo $content;
                    echo '</div>';
                } 
                if ( $img ) { ?>
                    <div class="col-lg-6 about-education__img">
                        <img src="<?php echo $img['url']; ?>" alt="<?php echo $img['alt']; ?>">
                    </div>
                <?php } ?>
                <?php if ( $addi_sec ) { ?>
                    <div class="about-education__paragraph">
                        <?php echo $addi_sec; ?>
                    </div>
                <?php } ?>
            </div>
        </div>
    </section>
    <!--/.about-education-->
<?php } 