<?php 
$row = get_row( true );
if ( empty( $row ) ) return;
$title = $row['ss_title'];
$sub_title = $row['ss_sub_title'];
$content = $row['ss_content'];
$quote = $row['quote_text'];
$img = $row['ss_image'];
if ( $title || $sub_title || $content || $quote || $img ) { ?>
	<section class="infant-educational-program">
		<div class="container">
			<?php if ( $title || $sub_title ) { ?>
				<div class="infant-educational-program__heading">
					<div class="heading has-border has-border--center">
						<?php if ( $title ) { ?>
							<h4><?php echo $title; ?></h4>
						<?php } ?>
						<?php if ( $sub_title ) { ?>
							<h2><?php echo $sub_title; ?></h2>
						<?php } ?>
					</div>
				</div>
				<!-- /.infant-educational-program__heading-->
			<?php } ?>
			<div class="infant-educational-program__content">
				<div class="row">
					<?php 
					if ( $img ) {
						$col = 'col-lg-6';
						?>
						<div class="col-lg-6 infant-educational-program__media">
							<figure>
								<img src="<?php echo $img['url']; ?>" alt="<?php echo $img['alt']; ?>">
							</figure>
						</div>
						<!-- /.infant-educational-program__media-->
						<?php 
					}
					else {
						$col = 'col-lg-12';
					}
					if ( $content || $quote ) { ?>
						<div class="<?php echo $col; ?> infant-educational-program__info align-self-center">
							<?php echo $content; 
							if ( $quote ) {?>
								<div class="green-bg">
									<?php echo $quote; ?>
								</div>
							<?php } ?>
						</div>
						<!-- /.infant-educational-program__info-->
					<?php } ?>
				</div>
			</div>
			<!-- /.infant-educational-program__content-->
		</div>
		<!-- /.container-->
	</section>
	<!-- /.infant-educational-program-->
<?php } ?>
