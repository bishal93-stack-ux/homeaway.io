<?php
$row = get_row( true );
if ( empty( $row ) ) return;
$title = $row['ss_title'];
$sub_title = $row['ss_sub_title'];
$content = $row['ss_content'];
$img = $row['ss_image'];
$button = $row['ss_buttton'];
if ( $button ) {
	$url = $button['url'];
	$target = $button['target'] ? $button['target'] : '_self';
	$b_title = $button['title'];
}
if ( $img ) {
	$col = 'col-lg-5';
}
else {
	$col = 'col-lg-12';
}
if ( $title || $sub_title || $content || $img ) { ?> 
	<section class="about-intro">
		<div class="container">
			<div class="row align-items-center">
				<?php if ( $img ) { ?>
					<div class="col-lg-7">
						<div class="about-intro__img">
							<img src="<?php echo $img['url']; ?>" alt="<?php echo $img['alt']; ?>">
						</div>
					</div>
				<?php } ?>
				<div class="<?php echo $col; ?>">
					<?php if ( $sub_title || $content || $title || $button ) { ?>
						<div class="about-intro__content">
							<?php if ( $title || $sub_title ) {
								echo '<div class="heading has-border">';
								if ( $title ) {
									echo '<h4>'. $title .' </h4>';
								}
								if ( $sub_title ) { 
									echo '<h2>'. $sub_title .'</h2>';
								}
								echo '</div>';
							} 
							echo  $content; 
							
							if ( $button ) { ?>
								<div class="btn-wrap">
									<a class="btn btn-primary" href="<?php echo $url; ?>" class="btn" target="<?php echo $target; ?>"><?php echo $b_title; ?><span class="icon-pointed-arrow"></span></a>
								</div>
							<?php } ?>
						</div>
					<?php } ?>
				</div>
			</div>
		</div>
	</section>
	<!--/.about-intro-->
<?php } 