<?php
$row = get_row( true );
if ( empty( $row ) ) return;
$title = $row['ss_title'];
$sub_title = $row['ss_sub_title'];
?>
<section class="about-why-choose">
	<div class="container">
		<?php if ( $title || $sub_title ) {
			echo '<div class="heading has-border text-center">';
				if ( $title ) {
					echo '<h4>'. $title .' </h4>';
				}
				if ( $sub_title ) { 
					echo '<h2>'. $sub_title .'</h2>';
				}
			echo '</div>';
		} 
		if ( have_rows('ss_tab_description') ) :
			$first_counter = 1;
			?>
			<div class="tab-wrap">
				<ul class="nav nav-tabs" id="myTab" role="tablist">
					<?php while ( have_rows('ss_tab_description') ) : 
						the_row();
						if ( $first_counter == 1 ) {
							$active = 'active';
							$aria_selected = 'true';
						} else {
							$active = '';
							$aria_selected = 'false';
						}
						$tab_title = get_sub_field('ss_tab_title');
						?>
						<li class="col-md-4 about-why-choose__tab-item nav-item">
							<a class="nav-link <?php echo $active; ?>" id="our-<?php echo $first_counter; ?>-tab" data-toggle="tab" href="#mission<?php echo $first_counter; ?>" role="tab" aria-controls="<?php echo $first_counter; ?>" aria-selected="<?php echo $aria_selected; ?>"><?php echo $tab_title; ?></a>
						</li>
						<?php $first_counter++; ?>
					<?php endwhile; ?>
				</ul>
			</div>
		<?php endif; ?>

		<?php if ( have_rows('ss_tab_description') ) :
			$second_counter = 1;
			?>
			<div class="tab-content" id="myTabContent">
				<?php while ( have_rows('ss_tab_description') ) :
					the_row();
					if ( $second_counter == 1 ) {
						$s_active = 'show active';
					} else {
						$s_active = '';
					}
					
					$tab_img = get_sub_field('ss_tab_image');
					$tab_desc = get_sub_field('short_description');
					if ( $tab_img ) {
						$col = 'col-lg-6';
					}
					else {
						$col = 'col-lg-12';	
					}
					?>
					<div class="tab-pane fade <?php echo $s_active; ?>" id="mission<?php echo $second_counter; ?>" role="tabpanel" aria-labelledby="our-<?php echo $second_counter; ?>-tab">
						<div class="row align-items-center">
							<?php if ( $tab_img ) { ?>
								<div class="col-lg-6">
									<div class="about-why-choose__img">
										<img src="<?php echo $tab_img['url']; ?>" alt="<?php echo $tab_img['alt']; ?>">
									</div>
								</div>
							<?php } ?>
							<div class="<?php echo $col; ?>">
								<div class="about-why-choose__text">
									<div class="about-why-choose__text-wrap">
										<?php echo $tab_desc; ?>
									</div>
									<?php if ( have_rows('ss_list') ) : ?>
										<div class="about-why-choose__text--list">
											<ul class="list-unstyled list-check">
												<?php while ( have_rows('ss_list') ) :
													the_row();
													$points = get_sub_field('ss_point');
													?>
													<li><?php echo $points; ?></li>
												<?php endwhile; ?>
											</ul>
										</div>
									<?php endif; ?>
								</div>
							</div>
						</div>
					</div>
					<!--/.our-misson-tab-->
					<?php 
					$second_counter++;
				endwhile;
				?>
			</div>
			<!--tav-content-->
		<?php endif; ?>
	</div>
</section>
	<!--/.about-why-choose-->