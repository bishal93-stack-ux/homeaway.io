<?php

/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Home_Away_Child_Care_Center
 */

get_header();

if ( have_posts() ) {
    while ( have_posts() ) {
        the_post();
        if (have_rows('ss_flexible_section')) :
            while (have_rows('ss_flexible_section')) : 
                the_row();
                if (get_row_layout()) :
                    get_template_part('template-parts/home/' . get_row_layout()); // file name is same as get row layout
                endif;
            endwhile;
        endif;
    }
}

get_footer();
