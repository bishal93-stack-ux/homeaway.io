<?php
get_header();
$main_content = get_post()->post_content; // retrieve post content
if ( have_posts() ) {
    while ( have_posts() ) {
        the_post();
        ?>
        <div class="infant-page">
            <?php if ( $main_content ) { ?>
                <section class="intro-block">
                    <div class="container">
                        <div class="intro-block__content">
                            <p><?php echo $main_content; ?></p>
                        </div>
                    </div>
                    <!-- /.container-->
                </section>
                <!-- /.intro-block-->
            <?php } ?>
            <?php 
            if (have_rows('ss_flexible_content')) :
                while (have_rows('ss_flexible_content')) : the_row();
                    if (get_row_layout()) :
                        get_template_part('template-parts/common-post-type/' . get_row_layout());
                    endif;
                endwhile;
            endif;
            ?>
        </div>
<?php
    }
}
get_footer();