<?php
/* Template Name: Static About */

get_header();
?>
<div class="about-page">
	<section class="about-intro">
		<div class="container">
			<div class="row align-items-center">
				<div class="col-lg-7">
					<div class="about-intro__img">
						<img src="<?php echo home_url(); ?>/media/about-us-img.jpg" alt="Home Away Child Care Center Image">
					</div>
				</div>
				<div class="col-lg-5">
					<div class="about-intro__content">
						<div class="heading has-border">
							<h4>Welcome to</h4>
							<h2>Home Away Child Care Center</h2>
						</div>
						<p>Our Infant Program offers a warm, secure environment where infants receive personalized care based on his or her unique schedule. Throughout the day, you will see teachers talking and singing with your child during feeding, diaper changing, and playtime.</p>
						<p>This interaction will help your baby understand language. We will provide you with a daily report, letting you know about your infants diaper, feeding and sleep scehdule throughout the day.</p>

						<div class="btn-wrap">
							<a class="btn btn-primary" href="#">Schedule a Tour<span class="icon-pointed-arrow"></span></a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!--/.about-intro-->
	<section class="about-why-choose">
		<div class="container">
			<div class="heading has-border text-center">
				<h4>Parents Love Us</h4>
				<h2>Why Choose Us</h2>
			</div>
			<div class="tab-wrap">
				<ul class="nav nav-tabs" id="myTab" role="tablist">
					<li class="col-md-4 about-why-choose__tab-item nav-item">
						<a class="nav-link active" id="our-misson-tab" data-toggle="tab" href="#misson" role="tab" aria-controls="home" aria-selected="true">Our Mission</a>
					</li>
					<li class="col-md-4 about-why-choose__tab-item nav-item">
						<a class="nav-link" id="our-curriculum-tab" data-toggle="tab" href="#curriculum" role="tab" aria-controls="profile" aria-selected="false">Our Curriculum</a>
					</li>
					<li class="col-md-4 about-why-choose__tab-item nav-item">
						<a class="nav-link" id="our-philosophy-tab" data-toggle="tab" href="#philosophy" role="tab" aria-controls="contact" aria-selected="false">Our Philosophy</a>
					</li>
				</ul>
			</div>
			<div class="tab-content" id="myTabContent">
				<div class="tab-pane fade show active" id="misson" role="tabpanel" aria-labelledby="our-misson-tab">
					<div class="row align-items-center">
						<div class="col-lg-6">
							<div class="about-why-choose__img">
								<img src="<?php echo home_url(); ?>/media/why-choose-us-img.jpg" alt="Why Choose Us Image">
							</div>
						</div>
						<div class="col-lg-6">
							<div class="about-why-choose__text">
								<div class="about-why-choose__text-wrap">
									<p>Our mission is to assist your child in any style that he/she may learn best in while providing an environment that is safe, clean, warm, positive and responsive. Children are natural thinkers and reflective problem solvers. Children construct knowledge in a natural way. We will work with the child's natural inclination to explore and solve problems. We believe this motivates learning for success in your child's school readiness and future.</p>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!--/.our-misson-tab-->
				<div class="tab-pane fade" id="curriculum" role="tabpanel" aria-labelledby="our-curriculum-tab">
					<div class="row align-items-center">
						<div class="col-lg-6">
							<div class="about-why-choose__img">
								<img src="<?php echo home_url(); ?>/media/why-choose-us-img.jpg" alt="Why Choose Us Image">
							</div>
						</div>
						<div class="col-lg-6">
							<div class="about-why-choose__text">
								<div class="about-why-choose__text-wrap">
									<p>Our center follows the Creative Curriculum. This curriculum is designed to challenge our children, build their self confidence and, most importantly, develop a love for learning. Our multicultural based curriculum encourages learning through arts, language, music, and socialization.</p>

									<p>We believe in age-appropriate learning based on the philosophy of a structured learning environment with the ability for creative expression. This nationally known approach, built upon learning theory and scientific knowledge of child development from early infancy through preschool years, focuses on teacher-directed and child-initiated learning.</p>

									<p>The curriculum is goal-directed, based on ongoing assessments for each child’s strengths and interests. With this information, learning can be guided while the child’s social and emotional development is supported. Recognizing the important role of parents and family as partners in the young child’s education, we will keep parents informed of the goals in the classroom and of how learning can be reinforced at home.</p>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!--/.our-curriculum-tab-->
				<div class="tab-pane fade" id="philosophy" role="tabpanel" aria-labelledby="our-philosophy-tab">
					<div class="row align-items-center">
						<div class="col-lg-6">
							<div class="about-why-choose__img">
								<img src="<?php echo home_url(); ?>/media/why-choose-us-img.jpg" alt="Why Choose Us Image">
							</div>
						</div>
						<div class="col-lg-6">
							<div class="about-why-choose__text">
								<div class="about-why-choose__text-wrap">
									<p>We believe that each child is unique in his/her own development and has the right to become the very best person that he/she is capable of becoming. We also believe that he/she has the right to grow up and learn in a wholesome environment that will provide early training in the life of a child and will have the greatest impact on his/her future learning. Thus, the Director, and the Staff dedicate their time and efforts toward the following goals:</p>
								</div>
								<div class="about-why-choose__text--list">
									<ul class="list-unstyled list-check">
										<li>Provide a safe, healthy, clean and secure environment supported by nurturing, caring and enthusiastic parents and teachers.</li>
										<li>Encouraging each child's optimum potential through developmentally appropriate activities using creativity, problem solving, imagination, and experimentation.</li>
										<li>Fostering positive attitudes towards life and school which lay a foundation for experience in future years.</li>
										<li>Encouraging the development of a positive self-image.</li>
										<li>Providing comfort, convenience, and peace of mind for working parents.</li>
										<li>Encouraging the learning of responsibility at school, home, and in the community.</li>
										<li>Promoting an educational environment that fosters academic excellence and active learning.</li>
										<li>The parent, and staff will bond together to be partners for the education of their child.</li>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!--/.our-philosophy-tab-->
			</div>
			<!--tav-content-->
		</div>
	</section>
	<!--/.about-why-choose-->

</div>
<!--/.about-page-->

<?php
get_footer();
