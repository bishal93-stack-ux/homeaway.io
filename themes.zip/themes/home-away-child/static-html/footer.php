<?php

/**
 * The template for displaying the footer
 *
 * Contains the closing of the .flex-shrink-0 div and all after .content div.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Home_Away_Child_Care_Center
 */

?>
</main>

<footer class="site-footer">
	<div class="site-footer__cta">
		<div class="holder">
			<h2><small>ready to enroll now</small>Home Away Child Care Center</h2>
			<div class="btn-wrap">
				<a href="tel:2018662906" class="btn btn-phone"><span class="icon-telephone"></span>(201) 866-2906</a>
			</div>
		</div>
	</div>
	<!-- /.site-footer__cta -->

	<div class="site-footer__top">
		<div class="container">
			<div class="site-footer__top--wrap">
				<div class="row">
					<div class="col-md-5 col-lg-4">
						<div class="leftaside">
							<figure>
								<img src="<?php echo home_url('/media/haccc-logo.png') ?>" alt="Home Away Footer Logo">
							</figure>
							<p>Our mission is to assist your child in any style that he/ she may learn best in while providing an environment that is safe, clean, warm, positive and responsive.</p>
							<h5>Child Development</h5>
							<ul>
								<li><a href="#">Cognitive Development</a></li>
								<li><a href="#">Physical / Motor Skills Development</a></li>
								<li><a href="#">Confidence and Social Development</a></li>
								<li><a href="#">Communication Development</a></li>
							</ul>
						</div>
						<!-- leftaside -->
					</div>
					<!-- col-md-5 col-lg-4 -->

					<div class="col-md-7 col-lg-8">
						<div class="rightaside">
							<h4>Contact us</h4>
							<div class="contact-block">
								<div class="contact-block__left">
									<div class="contact-block__item contact-block--address">
										<div class="icon-holder"><i class="icon-map-nav"></i></div>
										<div class="content-holder">
											<h5>Address</h5>
											<ul>
												<li><a href="https://goo.gl/maps/6rP876WBXBbtiHaa6" target="_blank">100 Manhattan Avenue Union City, NJ 07087</a></li>
												<li><a href="https://goo.gl/maps/FFr5GUsADNET6Pmz9" target="_blank">2414 Bergenline Avenue Union Ciy, NJ 07087</a></li>
												<li><a href="https://goo.gl/maps/4qjuYioBTrMCaCgc7" target="_blank">508-25th Street Union City, NJ 07087</a></li>
											</ul>
										</div>
									</div>
								</div>
								<!-- .contact-block__left -->

								<div class="contact-block__right">
									<div class="contact-block__item contact-block--ph-number">
										<div class="icon-holder"><i class="icon-call-bold"></i></div>
										<div class="content-holder">
											<h5>Phone Number</h5>
											<a href="tel:2018662906">(201) 866-2906</a>
										</div>
									</div>
									<div class="contact-block__item contact-block--email-add">
										<div class="icon-holder"><i class="icon-mail"></i></div>
										<div class="content-holder">
											<h5>Email Address</h5>
											<a href="mailto:info@HomeAwayChildCareCenter.com">info@homeawaychildcarecenter.com</a>
										</div>
									</div>
								</div>
								<!-- .contact-block__right -->
							</div>
						</div>
						<!-- .rightaside -->
					</div>
					<!-- col-md-7 col-lg-8 -->
				</div>
			</div>
		</div>
		<!-- .container -->
	</div>
	<!-- .site-footer__top -->

	<div class="site-footer__bottom text-center">
		<div class="container">
			<?php printf(esc_html__('Copyright %1$s - %2$s | All Rights Reserved.', 'home-away-child'), '&copy; ' . date('Y'), get_bloginfo('name')); ?>
			<span class="sep"> | </span>
			<?php printf(esc_html__('Web Design By %1$s.', 'home-away-child'), '<a href="https://smartsites.com/" target="_blank">SmartSites</a>'); ?>
		</div>
		<!-- .container -->
	</div>
	<!-- .site-footer__bottom -->
</footer>

<?php wp_footer(); ?>
</body>

</html>