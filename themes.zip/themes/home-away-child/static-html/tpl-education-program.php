<?php
/* Template Name: Static Education Program */

get_header();
?>
<div class="education-program-page">
    <div class="education-program">
        <section class="card-block areas-of-expertise">
            <div class="container">
                <div class="card-block__heading areas-of-expertise__heading">
                    <div class="heading has-border has-border--center">
                        <h4>What We Provide</h4>
                        <h2>Areas Of Expertise</h2>
                    </div>
                    <p>At Home Away Child Care Center, we offer a wide range of infant-appropriate programs, including:</p>
                </div>
                <!-- /.card-block__heading-->
                <div class="card-block__content areas-of-expertise__content">
                    <div class="card-block__item areas-of-expertise__item">
                        <div class="item-wrap">
                            <a href="#" class="stretched-link"></a>
                            <div class="card-block__img bg-cover">
                                <img src="<?php echo site_url(); ?>/media/aoe-img1.jpg" alt="Infant Image">
                            </div>
                            <div class="card-block__text areas-of-expertise__text" data-fix="height">
                                <a href="#">Infants</a>
                                <p>Our Infant Program offers a warm, secure environment</p>
                            </div>
                        </div>
                        <!-- /.item-wrap-->
                    </div>
                    <!-- /cad-block__item-->
                    <div class="card-block__item areas-of-expertise__item">
                        <div class="item-wrap">
                            <a href="#" class="stretched-link"></a>
                            <div class="card-block__img bg-cover">
                                <img src="<?php echo site_url(); ?>/media/aoe-img2.jpg" alt="Toddlers Image">
                            </div>
                            <div class="card-block__text areas-of-expertise__text" data-fix="height">
                                <a href="#">Toddlers</a>
                                <p>Our Toddler program provides experiences that support each</p>
                            </div>
                        </div>
                        <!-- /.item-wrap-->
                    </div>
                    <!-- /cad-block__item-->
                    <div class="card-block__item areas-of-expertise__item">
                        <div class="item-wrap">
                            <a href="#" class="stretched-link"></a>
                            <div class="card-block__img bg-cover">
                                <img src="<?php echo site_url(); ?>/media/aoe-img3.jpg" alt="Preschoolers Image">
                            </div>
                            <div class="card-block__text areas-of-expertise__text" data-fix="height">
                                <a href="#">Preschoolers</a>
                                <p>Our Preschool Program allows opportunities for our</p>
                            </div>
                        </div>
                        <!-- /.item-wrap-->
                    </div>
                    <!-- /cad-block__item-->
                    <div class="card-block__item areas-of-expertise__item">
                        <div class="item-wrap">
                            <a href="#" class="stretched-link"></a>
                            <div class="card-block__img bg-cover">
                                <img src="<?php echo site_url(); ?>/media/aoe-img4.jpg" alt="Pre-Kindergarten Students Image">
                            </div>
                            <div class="card-block__text areas-of-expertise__text" data-fix="height">
                                <a href="#">Pre-Kindergarten Students</a>
                                <p>Our Aftercare Program allows school-aged children to balance</p>
                            </div>
                        </div>
                        <!-- /.item-wrap-->
                    </div>
                    <!-- /cad-block__item-->
                    <div class="card-block__item areas-of-expertise__item">
                        <div class="item-wrap">
                            <a href="#" class="stretched-link"></a>
                            <div class="card-block__img bg-cover">
                                <img src="<?php echo site_url(); ?>/media/aoe-img5.jpg" alt="After School Students Image">
                            </div>
                            <div class="card-block__text areas-of-expertise__text" data-fix="height">
                                <a href="#">After School Students</a>
                                <p>Our Aftercare Program allows school-aged children to balance</p>
                            </div>
                        </div>
                        <!-- /.item-wrap-->
                    </div>
                    <!-- /cad-block__item-->
                </div>
                <!-- /.card-block__content-->
                <div class="card-block__bottom areas-of-expertise__bottom">
                    <a class="btn" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" href="#">Learn More about Our Education Programs <span class="icon-pointed-arrow"></span></a>
                </div>
                <!-- /.card-block__bottom-->
            </div>
            <!-- /.container-->
        </section>
        <!-- /.card-block-->
        <div class="collapse" id="collapseExample">
        <section class="academic-development">
            <div class="container">
                <div class="academic-development__content double-column">
                    <div class="row">
                        <div class="col-lg-6 col-xl-7">
                            <div class="academic-development__media double-column__media">
                                <div class="img-composition__img">
                                    <div class="img-composition__img img-composition__img-box">
                                        <div class="img-composition__img img-composition__img-box img-composition__img-box--one">
                                            <img src="<?php echo site_url(); ?>/media/img-composition-img1.jpg" alt="Image composition">
                                        </div>
                                        <div class="img-composition__img img-composition__img-box img-composition__img-box--two">
                                            <img src="<?php echo site_url(); ?>/media/img-composition-img2.jpg" alt="Image composition">
                                        </div>
                                        <div class="img-composition__img img-composition__img-box img-composition__img-box--three">
                                            <img src="<?php echo site_url(); ?>/media/img-composition-img3.jpg" alt="Image composition">
                                        </div>
                                        <div class="img-composition__img img-composition__img-box img-composition__img-box--four">
                                            <img src="<?php echo site_url(); ?>/media/img-composition-img4.jpg" alt="Image composition">
                                        </div>
                                        <div class="img-composition__img img-composition__img-box img-composition__img-box--five">
                                            <img src="<?php echo site_url(); ?>/media/img-composition-img5.jpg" alt="Image composition">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- /.academic-development__media-->
                        </div>
                        <div class="col-lg-6 col-xl-5 align-self-center">
                            <div class="academic-development__info double-column__info">
                                <div class="bold-text">
                                    <p>Home Away Child Care Center is a trusted
                                        provider of education programs for infants,
                                        toddlers, and school-aged children.</p>
                                </div>
                                <p>Our qualified teachers are committed to building a support system that encourages responsibility, diversity, safety, communication, respect, and trust. You can be sure that our education programs are designed to help meet the cognitive, physical, social, communication, and academic developmental needs of your child.</p>
                            </div>
                            <!-- /.academic-developmentl__info-->
                        </div>
                    </div>
                </div>
                <!-- /.academic-development__content-->
            </div>
            <!-- /.container-->
        </section>
        <!-- /.academic-development-->

        <section class="about-education">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6 about-education__content">
                        <div class="heading has-border">
                            <h4>About Our</h4>
                            <h2>Education Programs</h2>
                        </div>
                        <p>It is important to note that children start going through the learning curve at a tender age. Individuals who are as young as three years are exposed to a wide array of stimuli. With the right education programs, they can develop positive behavioral relationships, visualize, and understand the basics of various subjects. At Home Away Child Care Center, we provide intuitive education programs for different age groups. We have an infant program that offers a warm, secure environment where infants receive personalized care. Our qualified teachers can talk and sing with your child during playtime, diaper changing, and mealtimes. What’s more, your child can develop their balance, coordination and motor skills in a safe exploration area that has an array of manipulative toys.</p>
                        <p>Our toddler programs are geared toward meeting your child’s cognitive, language, social, emotional, physical, and creative development needs. They learn to interact with our teachers and other children, as well as solve problems through a hands-on experience.</p>
                    </div>
                    <div class="col-lg-6 about-education__img">
                        <img src="<?php echo home_url(); ?>/media/about-our-education-img.jpg" alt="About Our Education Program Image">
                    </div>
                    <div class="about-education__paragraph">
                        <p>At Home Away Child Care Center, preschoolers are given plenty of independent learning opportunities to engage in age-appropriate activities. You will be pleased to know that our learning centers are well-equipped for writing, reading, science, art, math, music, and imaginary play.</p>
                        <p>Does your child need help with their homework? They no longer have to wait until you arrive home from work! Our after school classes can help them tackle challenging subjects without delay. Additionally, we offer both recreational and educational activities that allow them to explore their interests and find their passion</p>
                    </div>
                </div>
            </div>
        </section>
        <!--/.about-education-->

        <section class="benefit-education">
            <div class="container">
                <div class="benefit-education__content">
                    <div class="row align-items-center">
                        <div class="col-lg-6 benefit-education__info">
                            <div class="heading has-border">
                                <h4>What Are</h4>
                                <h2>The Benefits of Education Programs?</h2>
                            </div>
                            <p>Access to quality after school programs can help children develop a lifelong love of learning and good study habits. In addition to fostering a positive attitude to learning, they can become more independent in terms of achieving academic success. Both numeracy and literacy skills have a significant impact on a child's academic success later in life. That's why these elements make up the foundation of our education programs. </p>
                        </div>
                        <!-- /.benefit-education__info-->
                        <div class="col-lg-6 benefit-education__media">
                            <figure>
                                <img src="<?php echo site_url(); ?>/media/benefits-of-education-program" alt="The Benefits of Education Programs">
                            </figure>
                        </div>
                        <!-- /.benefit-education__media-->
                    </div>
                </div>
                <!-- /.benefit-education__content-->
            </div>
            <!-- /.container-->
        </section>
        <!-- /.benefit-education-->

        <section class="infant-educational-program">
            <div class="container">
                <div class="infant-educational-program__heading">
                    <div class="heading has-border has-border--center">
                        <h4>Choose Home Away Child Care Center For</h4>
                        <h2>Educational Programs</h2>
                    </div>
                </div>
                <!-- /.infant-educational-program__heading-->
                <div class="infant-educational-program__content">
                    <div class="row">
                        <div class="col-lg-6 infant-educational-program__media">
                            <figure>
                                <img src="<?php echo site_url(); ?>/media/education-program-img.jpg" alt="Infant Educational Programs">
                            </figure>
                        </div>
                        <!-- /.infant-educational-program__media-->
                        <div class="col-lg-6 infant-educational-program__info align-self-center">
                            <p>At Home Away Child Care Center, our qualified teachers are passionate about starting children on the path to a bright future. Our team can help your child develop at their own pace and promote academic competency.</p>
                            <div class=" green-bg">
                                <p>If you are interested in enrolling your child in our
                                    education programs, feel free to <a href="#">contact us now</a></p>
                            </div>
                        </div>
                        <!-- /.infant-educational-program__info-->
                    </div>
                </div>
                <!-- /.infant-educational-program__content-->
            </div>
            <!-- /.container-->
        </section>
        <!-- /.infant-educational-program-->

        </div>
        <!--/.collapse-->
    </div>
    <!--/.education-program-->
</div>
<!--/.education-program-page-->

<?php
get_footer();
