<?php
/* Template Name: Static After School Classes */

get_header();
?>
    <div class="after-school-page">

        <section class="development-intro">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6">
                        <div class="development-intro__media ">
                            <div class="img-composition__img img-composition__img-box">
                                <div class="img-composition__img img-composition__img-box img-composition__img-box--one">
                                    <img src="<?php echo site_url(); ?>/media/afterclass-img-02.png" alt="Image composition">
                                </div>
                                <div class="img-composition__img img-composition__img-box img-composition__img-box--two">
                                    <img src="<?php echo site_url(); ?>/media/afterclass-img-01.png" alt="Image composition">
                                </div>
                                <div class="img-composition__img img-composition__img-box img-composition__img-box--three">
                                    <img src="<?php echo site_url(); ?>/media/afterclass-img-03.png" alt="Image composition">
                                </div>
                                <div class="img-composition__img img-composition__img-box img-composition__img-box--four">
                                    <img src="<?php echo site_url(); ?>/media/afterclass-img-04.png" alt="Image composition">
                                </div>
                                <div class="img-composition__img img-composition__img-box img-composition__img-box--five">
                                    <img src="<?php echo site_url(); ?>/media/afterclass-img-05.png" alt="Image composition">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="development-intro__info">
                            <div class="bold-text">
                                <p>Today, after school classes can encompass a wide array of focus areas, including art, child development, mentoring, academic support, recreation, and much more. Activities in which young children engage while outside of school hours are important to their overall development.</p>
                            </div>
                            <p> At Home Away Child Care Center, we fully understand the importance of after school programs for elementary school age students. Our company specializes in providing age-appropriate activities in a safe and fun environment where children can be… children!</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--/.img-composition-->

        <section class="after-school-about">
            <div class="container">
                <div class="row double-column">
                    <div class="col-lg-6 order-lg-1 order-2">
                        <div class="double-column__info">
                            <div class="heading has-border">
                                <h4>About Our</h4>
                                <h2>After School Classes</h2>
                            </div>
                            <p>Our after school classes are designed to offer school-aged children both educational and recreational experiences. When your child attends our classes, our instructors will introduce a broad range of engaging child-initiated activities. This way, they can explore and develop their own skills and interests. Additionally, our staff is comprised of qualified teachers who can help with your child’s homework, relieving some of your duties at home. At Home Away Child Care Center, our after school classes are conducted in a state-of-the-art facility and a secure environment.</p>
                        </div>
                        <!-- end .double-column__info -->
                    </div>
                    <div class="col-lg-6 order-lg-2 order-1">
                        <div class="double-column__media">
                            <figure>
                                <img src="<?php echo home_url('media/after-school-classes-about-01.jpg'); ?>" alt="After School Classes">
                            </figure>
                        </div>
                        <!-- end .double-column__media -->
                    </div>
                </div>
            </div>
        </section>
        <!-- end . after-school-about -->

        <section class="card-block card-block--provide">
            <div class="container-fluid">
                <div class="card-block__heading">
                    <div class="heading has-border has-border--center">
                        <h4>What We Provide</h4>
                        <h2>Areas Of Expertise</h2>
                    </div>
                    <p>Here are the core components of Home Away Child Care Center’s after school classes:</p>
                </div>
                <!-- /.card-block__heading-->
                <div class="card-block__content">
                    <div class="card-block__item">
                        <div class="item-wrap">
                            <figure class="card-block__img bg-cover">
                                <img src="<?php echo home_url('media/we-provide-01.jpg'); ?>" alt="Infant Image">
                            </figure>
                            <div class="card-block__text" data-fix="height">
                                <h5>
                                    <a href="#" class="stretched-link">Science And Math</a>
                                </h5>
                                <p>There are many variations of passages of Lorem Ipsum.</p>
                            </div>
                        </div>
                        <!-- /.item-wrap-->
                    </div>
                    <!-- /card-block__item-->
                    <div class="card-block__item">
                        <div class="item-wrap">
                            <figure class="card-block__img bg-cover">
                                <img src="<?php echo home_url('media/we-provide-02.jpg'); ?>" alt="Toddlers Image">
                            </figure>
                            <div class="card-block__text" data-fix="height">
                                <h5>
                                    <a href="#" class="stretched-link">Literacy And Book Corner</a>
                                </h5>
                                <p>There are many variations of passages of Lorem Ipsum.</p>
                            </div>
                        </div>
                        <!-- /.item-wrap-->
                    </div>
                    <!-- /card-block__item-->
                    <div class="card-block__item">
                        <div class="item-wrap">
                            <figure class="card-block__img bg-cover">
                                <img src="<?php echo home_url('media/we-provide-03.jpg'); ?>" alt="Writing Center">
                            </figure>
                            <div class="card-block__text" data-fix="height">
                                <h5>
                                    <a href="#" class="stretched-link">Writing Center</a>
                                </h5>
                                <p>There are many variations of passages of Lorem Ipsum.</p>
                            </div>
                        </div>
                        <!-- /.item-wrap-->
                    </div>
                    <!-- /card-block__item-->
                    <div class="card-block__item">
                        <div class="item-wrap">
                            <figure class="card-block__img bg-cover">
                                <img src="<?php echo home_url('media/we-provide-04.jpg'); ?>" alt="Pre-Kindergarten Students Image">
                            </figure>
                            <div class="card-block__text" data-fix="height">
                                <h5>
                                    <a href="#" class="stretched-link">Constructive Area</a>
                                </h5>
                                <p>There are many variations of passages of Lorem Ipsum.</p>
                            </div>
                        </div>
                        <!-- /.item-wrap-->
                    </div>
                    <!-- /card-block__item-->
                    <div class="card-block__item">
                        <div class="item-wrap">
                            <figure class="card-block__img bg-cover">
                                <img src="<?php echo home_url('media/we-provide-05.jpg'); ?>" alt="Dramatic Play Image">
                            </figure>
                            <div class="card-block__text" data-fix="height">
                                <h5>
                                    <a href="#" class="stretched-link">Dramatic Play</a>
                                </h5>
                                <p>There are many variations of passages of Lorem Ipsum.</p>
                            </div>
                        </div>
                        <!-- /.item-wrap-->
                    </div>
                    <!-- /card-block__item-->
                    <div class="card-block__item">
                        <div class="item-wrap">
                            <figure class="card-block__img bg-cover">
                                <img src="<?php echo home_url('media/we-provide-05.jpg'); ?>" alt="Dramatic Play Image">
                            </figure>
                            <div class="card-block__text" data-fix="height">
                                <h5>
                                    <a href="#" class="stretched-link">Dramatic Play</a>
                                </h5>
                                <p>There are many variations of passages of Lorem Ipsum.</p>
                            </div>
                        </div>
                        <!-- /.item-wrap-->
                    </div>
                    <!-- /card-block__item-->
                </div>
                <!-- /.card-block__content-->
                <div class="card-block__bottom">
                    <a class="btn btn-primary">Schedule a Tour <span class="icon-pointed-arrow"></span></a>
                </div>
                <!-- /.card-block__bottom-->
            </div>
            <!-- /.container-->
        </section>
        <!-- end .card-block -->

        <section class="benefit-program">
            <div class="heading has-border has-border--center">
                <h4>What Are</h4>
                <h2>The Benefits Of <br> After School Classes?</h2>
            </div>
            <!-- end .heading -->
            <div class="container">
                <div class="benefit-program__content double-column">
                    <div class="row no-gutters">
                        <div class="col-xxl-5 col-lg-6 order-lg-1 order-2">
                            <div class="benefit-program__info double-column__info">
                                <p class="text-primary"><strong>If your child is struggling with an arduous subject such as math or science, our after school classes can provide much needed homework help. Our patient teachers can help your child improve their understanding of challenging subjects and train them to become more confident in their learning capabilities.</strong></p>
                                <p>Our after school program instructors can impart useful time management skills to your child as well. Each class encourages all students under our care to actively participate in activities while allowing adequate time for homework. Balancing everyday school requirements with extracurricular demands is a great way for children to develop self-restraint and discipline that will carry over to adulthood.</p>
                                <p> Because your child will have plenty of opportunities to start a conversation and join a game, our after school classes help promote respect, support, and cooperation. Picking up positive social skills at a young age can be advantageous in the long run. With proper supervision by our teachers, your child can stay clear of risky behaviors that commonly occur after normal school hours. </p>
                            </div>
                            <!-- /.benefit-program__info-->
                        </div>
                        <div class="col-xxl-7 col-lg-6 order-lg-2 order-1">
                            <div class="benefit-program__media double-column__media">
                                <figure>
                                    <img src="<?php echo home_url('media/benefits-program-img-01.jpg'); ?>" alt="The Benefits of Education Programs">
                                </figure>
                            </div>
                            <!-- /.benefit-program__media-->
                        </div>
                    </div>
                </div>
                <!-- /.benefit-program__content-->
            </div>
            <!-- /.container-->
        </section>
        <!-- end .benefit-program -->

        <section class="choose-block">
            <div class="container">
                <div class="choose-block__heading">
                    <div class="heading has-border has-border--center">
                        <h4>Choose Home Away Child Care Center For</h4>
                        <h2>After School Classes</h2>
                    </div>
                </div>
                <!-- /.choose-block__heading-->
                <div class="choose-block__content double-column">
                    <div class="row">
                        <div class="col-lg-6 column-lg">
                            <div class="choose-block__media double-column__media">
                                <figure>
                                    <img src="<?php echo home_url('media/choose-after-class.jpg'); ?>" alt="Infant Educational Programs">
                                </figure>
                            </div>
                            <!-- /.choose-block__media-->
                        </div>
                        <div class="col-lg-6 column-md align-self-center">
                            <div class="choose-block__info double-column__info">
                                <p>At Home Away Child Care Center, our after school classes allow students to explore an assortment of open-ended learning materials. We strive to help them develop a strong foundation for future academic school and life experiences. With the availability of a literacy enriched environment, your child can also enjoy reading books and appreciate the literature world more than ever. </p>
                                <p>You can enjoy complete peace of mind knowing that our teachers have passed background checks and are trustworthy individuals who care about your child’s development.</p>
                                <blockquote class="green-bg">
                                    <p>If you are interested in enrolling your child in our after school classes, feel free to <a href="#">contact us now</a>. </p>
                                </blockquote>
                            </div>
                            <!-- /.choose-block__info-->
                        </div>
                    </div>
                </div>
                <!-- /.choose-block__content-->
            </div>
            <!-- /.container-->
        </section>
        <!-- end .choose-block -->

    </div>
<?php
get_footer();
