<?php
/* Template Name: Static Gallery */

get_header();
?>
    <section class="gallery-page">
        <div class="container">
            <div class="block block-gallery">
                <div class="card-deck no-gutters card-deck--gallery">
                    <div class="col-6 col-lg-4 card-item">
                        <div class="card rounded">
                            <div class="card-img">
                                <figure>
                                    <a href="<?php echo site_url('/media/gallery-img1.jpg') ?>" data-fancybox="gallery"><img
                                                src="<?php echo site_url('/media/gallery-img1.jpg') ?>"
                                                alt="Gallery Img"></a>
                                </figure>
                            </div><!--/.card-img-->
                        </div><!--/.card rounded-->
                    </div><!--/.card-item-->
                    <div class="col-6 col-lg-4 card-item">
                        <div class="card rounded">
                            <div class="card-img">
                                <figure>
                                    <a href="<?php echo site_url('/media/gallery-img2.jpg') ?>" data-fancybox="gallery"><img
                                                src="<?php echo site_url('/media/gallery-img2.jpg') ?>"
                                                alt="Gallery Img"></a>
                                </figure>
                            </div><!--/.card-img-->
                        </div><!--/.card rounded-->
                    </div><!--/.card-item-->
                    <div class="col-6 col-lg-4 card-item">
                        <div class="card rounded">
                            <div class="card-img">
                                <figure>
                                    <a href="<?php echo site_url('/media/gallery-img3.jpg') ?>" data-fancybox="gallery"><img
                                                src="<?php echo site_url('/media/gallery-img3.jpg') ?>"
                                                alt="Gallery Img"></a>
                                </figure>
                            </div><!--/.card-img-->
                        </div><!--/.card rounded-->
                    </div><!--/.card-item-->
                    <div class="col-6 col-lg-4 card-item">
                        <div class="card rounded">
                            <div class="card-img">
                                <figure>
                                    <a href="<?php echo site_url('/media/gallery-img4.jpg') ?>" data-fancybox="gallery"><img
                                                src="<?php echo site_url('/media/gallery-img4.jpg') ?>"
                                                alt="Gallery Img"></a>
                                </figure>
                            </div><!--/.card-img-->
                        </div><!--/.card rounded-->
                    </div><!--/.card-item-->
                    <div class="col-6 col-lg-4 card-item">
                        <div class="card rounded">
                            <div class="card-img">
                                <figure>
                                    <a href="<?php echo site_url('/media/gallery-img5.jpg') ?>" data-fancybox="gallery"><img
                                                src="<?php echo site_url('/media/gallery-img5.jpg') ?>"
                                                alt="Gallery Img"></a>
                                </figure>
                            </div><!--/.card-img-->
                        </div><!--/.card rounded-->
                    </div><!--/.card-item-->
                    <div class="col-6 col-lg-4 card-item">
                        <div class="card rounded">
                            <div class="card-img">
                                <figure>
                                    <a href="<?php echo site_url('/media/gallery-img6.jpg') ?>" data-fancybox="gallery"><img
                                                src="<?php echo site_url('/media/gallery-img6.jpg') ?>"
                                                alt="Gallery Img"></a>
                                </figure>
                            </div><!--/.card-img-->
                        </div><!--/.card rounded-->
                    </div><!--/.card-item-->
                    <div class="col-6 col-lg-4 card-item">
                        <div class="card rounded">
                            <div class="card-img">
                                <figure>
                                    <a href="<?php echo site_url('/media/gallery-img7.jpg') ?>" data-fancybox="gallery"><img
                                                src="<?php echo site_url('/media/gallery-img7.jpg') ?>"
                                                alt="Gallery Img"></a>
                                </figure>
                            </div><!--/.card-img-->
                        </div><!--/.card rounded-->
                    </div><!--/.card-item-->
                    <div class="col-6 col-lg-4 card-item">
                        <div class="card rounded">
                            <div class="card-img">
                                <figure>
                                    <a href="<?php echo site_url('/media/gallery-img8.jpg') ?>" data-fancybox="gallery"><img
                                                src="<?php echo site_url('/media/gallery-img8.jpg') ?>"
                                                alt="Gallery Img"></a>
                                </figure>
                            </div><!--/.card-img-->
                        </div><!--/.card rounded-->
                    </div><!--/.card-item-->
                    <div class="col-6 col-lg-4 card-item">
                        <div class="card rounded">
                            <div class="card-img">
                                <figure>
                                    <a href="<?php echo site_url('/media/gallery-img9.jpg') ?>" data-fancybox="gallery"><img
                                                src="<?php echo site_url('/media/gallery-img9.jpg') ?>"
                                                alt="Gallery Img"></a>
                                </figure>
                            </div><!--/.card-img-->
                        </div><!--/.card rounded-->
                    </div><!--/.card-item-->
                </div><!--/.card-deck /.card-deck--gallery-->
                <div class="btn-wrap text-center">
                    <a href="#" class="btn btn-primary">Load More <span class="icon icon-refresh"></span></a>
                </div>
            </div><!--/.block-gallery-->
        </div>
    </section><!--/.gallery-page-->
<?php
get_footer();