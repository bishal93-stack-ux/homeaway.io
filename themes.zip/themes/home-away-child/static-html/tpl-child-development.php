<?php
/* Template Name: Static Child Development */

get_header();
?>
<div class="child-development-page">

    <section class="development-intro">
        <div class="container">
            <div class="development-intro__content double-column">
                <div class="row">
                    <div class="col-lg-6 col-xl-7">
                        <div class="development-intro__media double-column__media">
                            <div class="img-composition__img">
                                <div class="img-composition__img img-composition__img-box">
                                    <div class="img-composition__img img-composition__img-box img-composition__img-box--one">
                                        <img src="<?php echo site_url(); ?>/media/development-intro-01.jpg" alt="Image composition">
                                    </div>
                                    <div class="img-composition__img img-composition__img-box img-composition__img-box--two">
                                        <img src="<?php echo site_url(); ?>/media/development-intro-02.jpg" alt="Image composition">
                                    </div>
                                    <div class="img-composition__img img-composition__img-box img-composition__img-box--three">
                                        <img src="<?php echo site_url(); ?>/media/development-intro-03.jpg" alt="Image composition">
                                    </div>
                                    <div class="img-composition__img img-composition__img-box img-composition__img-box--four">
                                        <img src="<?php echo site_url(); ?>/media/development-intro-04.jpg" alt="Image composition">
                                    </div>
                                    <div class="img-composition__img img-composition__img-box img-composition__img-box--five">
                                        <img src="<?php echo site_url(); ?>/media/development-intro-05.jpg" alt="Image composition">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- /.development-intro__media-->
                    </div>
                    <div class="col-lg-6 col-xl-5 align-self-center">
                        <div class="development-intro__info double-column__info">
                            <div class="bold-text">
                                <p>A child’s early years play an extremely important
                                    role in their overall development. Babies typically
                                    begin learning about the world around them from
                                    a very early age, including the prenatal, perinatal,
                                    and postnatal phases. </p>
                            </div>
                            <p>That’s why Home Away Child Care Center has developed child development programs that are designed
                                to aid your child’s social, emotional, cognitive, and physical development. Optimizing the early years of
                                a child’s life is one of the best investments that parents can make to ensure their future success.</p>
                        </div>
                        <!-- /.development-introl__info-->
                    </div>
                </div>
            </div>
            <!-- /.development-intro__content-->
        </div>
        <!-- /.container-->
    </section>
    <!-- /.development-intro-->

    <section class="child-program">
        <div class="container">
            <div class="child-program__content double-column">
                <div class="row no-gutters">
                    <div class="col-lg-6">
                        <div class="child-program__media double-column__media">
                            <figure>
                                <img src="<?php echo site_url(); ?>/media/child-program.jpg" alt="Child Development Programs">
                            </figure>
                        </div>
                        <!-- /.child-program__media-->
                    </div>
                    <div class="col-lg-6">
                        <div class="child-program__info double-column__info">
                            <div class="heading has-border">
                                <h4>About Our</h4>
                                <h2>Child Development Programs</h2>
                            </div>
                            <p>Child development surrounds the thought, language, and physical changes that occur in a child from
                                birth to the early stages of adulthood. During these processes, children often progress from dependency
                                on parents or guardians to developing independence. Although a child’s overall development is strongly
                                influenced by genetic factors and/or events that occurred during prenatal life, they are also influenced
                                by environmental facts – what they are taught along the way. At Home Away Child Care Center, our child
                                development programs help monitor and observe your child’s growth and ensure that they meet key developmental
                                milestones at appropriate ages.</p>
                        </div>
                        <!-- /.child-program__info-->
                    </div>
                </div>
            </div>
            <!-- /.child-program__content-->
        </div>
        <!-- /.container-->
    </section>
    <!-- /.child-program-->

    <section class="card-block card-block__development">
        <div class="container">
            <div class="card-block__heading">
                <div class="heading has-border has-border--center">
                    <h4>What We Provide</h4>
                    <h2>Areas of Expertise</h2>
                </div>
                <p>Here are the core components of Home Away Child Care Center’s child development programs:</p>
            </div>
            <!-- /.card-block__heading-->
            <div class="card-block__content">
                <div class="card-block__item">
                    <div class="item-wrap">
                        <a href="#" class="stretched-link"></a>
                        <div class="card-block__img bg-cover">
                            <img src="<?php echo site_url(); ?>/media/child-area-01.jpg" alt="Cognitive Development">
                        </div>
                        <div class="card-block__text" data-fix="height">
                            <a href="#">Cognitive Development</a>
                            <p>There are many variations of passages of Lorem Ipsum.</p>
                        </div>
                    </div>
                    <!-- /.item-wrap-->
                </div>
                <!-- /cad-block__item-->
                <div class="card-block__item">
                    <div class="item-wrap">
                        <a href="#" class="stretched-link"></a>
                        <div class="card-block__img bg-cover">
                            <img src="<?php echo site_url(); ?>/media/child-area-02.jpg" alt="Physical Motor Skills Development">
                        </div>
                        <div class="card-block__text" data-fix="height">
                            <a href="#">Physical And Motor Skills Development</a>
                            <p>There are many variations of passages of Lorem Ipsum.</p>
                        </div>
                    </div>
                    <!-- /.item-wrap-->
                </div>
                <!-- /cad-block__item-->
                <div class="card-block__item">
                    <div class="item-wrap">
                        <a href="#" class="stretched-link"></a>
                        <div class="card-block__img bg-cover">
                            <img src="<?php echo site_url(); ?>/media/child-area-03.jpg" alt="Confidence and Social Development">
                        </div>
                        <div class="card-block__text" data-fix="height">
                            <a href="#">Confidence and Social Development</a>
                            <p>There are many variations of passages of Lorem Ipsum.</p>
                        </div>
                    </div>
                    <!-- /.item-wrap-->
                </div>
                <!-- /cad-block__item-->
                <div class="card-block__item">
                    <div class="item-wrap">
                        <a href="#" class="stretched-link"></a>
                        <div class="card-block__img bg-cover">
                            <img src="<?php echo site_url(); ?>/media/child-area-04.jpg" alt="Communication Development">
                        </div>
                        <div class="card-block__text" data-fix="height">
                            <a href="#">Communication Development</a>
                            <p>There are many variations of passages of Lorem Ipsum.</p>
                        </div>
                    </div>
                    <!-- /.item-wrap-->
                </div>
                <!-- /cad-block__item-->
            </div>
            <!-- /.card-block__content-->
            <div class="card-block__bottom">
                <a href="#" class="btn">Schedule a Tour <span class="icon-pointed-arrow"></span></a>
            </div>
            <!-- /.card-block__bottom-->
        </div>
        <!-- /.container-->
    </section>
    <!-- /.card-block-->

    <section class="development-program">
        <div class="container">
            <div class="development-program__heading">
                <div class="heading has-border has-border--center">
                    <h4>What Are</h4>
                    <h2>The Benefits of Child Development Programs?</h2>
                </div>
            </div>
            <div class="development-program__content double-column">
                <div class="row">
                    <div class="col-lg-6 order-lg-1 order-2">
                        <div class="development-program__info double-column__info">
                            <div class="bold-text">
                                <p>Children can develop important cognitive skills that allow them to think, explore, and
                                    figure things out on their own. These programs help improve their dispositions, problem solving
                                    skills, and general knowledge. All of these skills are needed to allow children to think about
                                    and understand the world around them. </p>
                            </div>
                            <p>Child development programs can impart proper communication skills to children so that they can
                                lead a better quality of life now and in the future. When a child begins school, oral exams, dramatizations,
                                class discussions, and presentations may become regular activities for them. A child who is good at communicating
                                typically finds it easier to produce written communications, speak in front of a crowd, and achieve better
                                performance in school. What’s more, children who engage in child development programs get along better with
                                others and are less disruptive and aggressive in school and other social situations. At Home Away Child Care
                                Center, our child development programs also help improve children’s abilities to perform crucial tasks such as
                                moving, grasping, and reaching for objects, e.g., pencils, chalk, crayons, and more. Additionally, they learn to
                                develop their hand-eye coordination, as well as drawing and handwriting skills. The goal is to help them become more
                                aware of how their bodies work.</p>
                        </div>
                        <!-- /.development-program__info-->
                    </div>
                    <div class="col-lg-6 order-lg-2 order-1">
                        <div class="development-program__media double-column__media">
                            <figure>
                                <img src="<?php echo site_url(); ?>/media/development-program.jpg" alt="Child Development Programs">
                            </figure>
                        </div>
                        <!-- /.development-program__media-->
                    </div>
                </div>
            </div>
            <!-- /.development-program__content-->
        </div>
        <!-- /.container-->
    </section>
    <!-- /.development-program-->

    <section class="choose-block choose-block__development">
        <div class="container">
            <div class="choose-block__heading">
                <div class="heading has-border has-border--center">
                    <h4>Choose Home Away Child Care Center For</h4>
                    <h2>Child Development Programs</h2>
                </div>
            </div>
            <!-- /.choose-block__heading-->
            <div class="choose-block__content double-column">
                <div class="row">
                    <div class="col-lg-6 column-lg">
                        <div class="choose-block__media double-column__media">
                            <figure>
                                <img src="<?php echo site_url(); ?>/media/child-choose.jpg" alt="Child Development Programs">
                            </figure>
                        </div>
                        <!-- /.choose-block__media-->
                    </div>
                    <div class="col-lg-6 column-md align-self-center">
                        <div class="choose-block__info double-column__info">
                            <p>Our team has years of experience in working with parents to meet the unique developmental needs of their children.
                                Our child development programs are reasonably priced and conducted in a safe, clean, cozy and positive environment.</p>
                            <div class="green-bg">
                                <p>If you are interested in enrolling your child in our
                                    infant-appropriate programs, do not hesitate to 
                                    <a href="#">contact us today</a></p>
                            </div>
                        </div>
                        <!-- /.choose-block__info-->
                    </div>
                </div>
            </div>
            <!-- /.choose-block__content-->
        </div>
        <!-- /.container-->
    </section>
    <!-- /.choose-block-->
</div>
<?php
get_footer();
