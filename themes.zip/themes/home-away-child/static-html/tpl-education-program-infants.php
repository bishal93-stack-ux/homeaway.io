<?php
/* Template Name: Static Infant */

get_header();
?>
<div class="infant-page">
    <section class="intro-block">
        <div class="container">
            <div class="intro-block__content">
                <p>Promoting a healthy lifestyle with good habits early on is important for growth and development
                    throughout your child’s life. Our infant programs at Home Away Child Care Center aim to encourage good
                    health and positive behavior in their first year of life. By enrolling in our infant educational programs,
                    our teachers will work alongside families to help their children develop their health, physical and behavior
                    skills in a family-oriented environment. Fostering these characteristics in your child at an early age is
                    the key to laying a solid foundation in life beyond childhood.</p>
            </div>
        </div>
        <!-- /.container-->
    </section>
    <!-- /.intro-block-->

    <section class="infant-program">
        <div class="container">
            <div class="infant-program__content double-column">
                <div class="row no-gutters">
                    <div class="col-lg-6 order-lg-1 order-2">
                        <div class="infant-program__info double-column__info">
                            <div class="heading has-border">
                                <h4>About Our</h4>
                                <h2>Infant Educational Programs</h2>
                            </div>
                            <p>At Home Away Child Care Center, our highly trained caregivers will execute programs catered to your
                                child’s need by introducing fun, educational and entertaining daily activities. Material-rich programs such as
                                the usage of toys and interesting items will enhance their curiosity, as well as develop their motor and coordination skills.</p>
                            <p>Our center will provide a warm and secure environment where your child gets regular sleeping, routine playtime, feeding,
                                diaper changing and storytelling. Such interactions will develop communication and language skills for your child.</p>
                        </div>
                        <!-- /.infant-program__info-->
                    </div>
                    <div class="col-lg-6 order-lg-2 order-1">
                        <div class="infant-program__media double-column__media">
                            <figure>
                                <img src="<?php echo site_url(); ?>/media/program-infant.jpg" alt="Infant Educational Programs">
                            </figure>
                        </div>
                        <!-- /.infant-program__media-->
                    </div>
                </div>
            </div>
            <!-- /.infant-program__content-->
        </div>
        <!-- /.container-->
    </section>
    <!-- /.infant-program-->

    <section class="benefit-program">
        <div class="container">
            <div class="benefit-program__content double-column">
                <div class="row no-gutters">
                    <div class="col-xxl-7 col-lg-6">
                        <div class="benefit-program__media double-column__media">
                            <figure>
                                <img src="<?php echo site_url(); ?>/media/program-benefit.jpg" alt="The Benefits of Education Programs">
                            </figure>
                        </div>
                        <!-- /.benefit-program__media-->
                    </div>
                    <div class="col-xxl-5 col-lg-6">
                        <div class="benefit-program__info double-column__info">
                            <div class="heading has-border">
                                <h4>What Are</h4>
                                <h2>The Benefits of Education Programs?</h2>
                            </div>
                            <p>When a child is exposed to an infant educational program at an early stage, chances are he or she will
                                tend to interact confidently with other infants, children or adults in later life. The program would allow the
                                infant to develop the foundation for relationships and friendships throughout their lives.</p>
                            <p>During this day, a modern family would require both parents to work throughout the day. By allowing Home Away
                                Child Care Center to provide the utmost care to your infant, you and your spouse can have peace of mind knowing
                                that your child is in good hands while developing vital skillset at an early age.</p>
                            <p>Our infant care professionals have worked with many infants and you can rest assured that we will provide the
                                best learning opportunities for your child.</p>
                        </div>
                        <!-- /.benefit-program__info-->
                    </div>
                </div>
            </div>
            <!-- /.benefit-program__content-->
        </div>
        <!-- /.container-->
    </section>
    <!-- /.benefit-program-->

    <section class="card-block">
        <div class="container">
            <div class="card-block__heading">
                <div class="heading has-border has-border--center">
                    <h4>What We Provide</h4>
                    <h2>Areas of Expertise</h2>
                </div>
                <p>At Home Away Child Care Center, we offer a wide range of infant-appropriate programs, including: </p>
            </div>
            <!-- /.card-block__heading-->
            <div class="card-block__content">
                <div class="card-block__item">
                    <div class="item-wrap">
                        <a href="#" class="stretched-link"></a>
                        <div class="card-block__img bg-cover">
                            <img src="<?php echo site_url(); ?>/media/infant-area-01.jpg" alt="Cognitive Development">
                        </div>
                        <div class="card-block__text" data-fix="height">
                            <a href="#">Cognitive Development</a>
                        </div>
                    </div>
                    <!-- /.item-wrap-->
                </div>
                <!-- /cad-block__item-->
                <div class="card-block__item">
                    <div class="item-wrap">
                        <a href="#" class="stretched-link"></a>
                        <div class="card-block__img bg-cover">
                            <img src="<?php echo site_url(); ?>/media/infant-area-02.jpg" alt="Physical Motor Skills Development">
                        </div>
                        <div class="card-block__text" data-fix="height">
                            <a href="#">Physical / Motor Skills Development</a>
                        </div>
                    </div>
                    <!-- /.item-wrap-->
                </div>
                <!-- /cad-block__item-->
                <div class="card-block__item">
                    <div class="item-wrap">
                        <a href="#" class="stretched-link"></a>
                        <div class="card-block__img bg-cover">
                            <img src="<?php echo site_url(); ?>/media/infant-area-03.jpg" alt="Confidence and Social Development">
                        </div>
                        <div class="card-block__text" data-fix="height">
                            <a href="#">Confidence and Social Development</a>
                        </div>
                    </div>
                    <!-- /.item-wrap-->
                </div>
                <!-- /cad-block__item-->
                <div class="card-block__item">
                    <div class="item-wrap">
                        <a href="#" class="stretched-link"></a>
                        <div class="card-block__img bg-cover">
                            <img src="<?php echo site_url(); ?>/media/infant-area-04.jpg" alt="Communication Development">
                        </div>
                        <div class="card-block__text" data-fix="height">
                            <a href="#">Communication Development</a>
                        </div>
                    </div>
                    <!-- /.item-wrap-->
                </div>
                <!-- /cad-block__item-->
            </div>
            <!-- /.card-block__content-->
            <div class="card-block__bottom">
                <a href="#" class="btn">Learn More about Our Education Programs <span class="icon-pointed-arrow"></span></a>
            </div>
            <!-- /.card-block__bottom-->
        </div>
        <!-- /.container-->
    </section>
    <!-- /.card-block-->

    <section class="choose-block">
        <div class="container">
            <div class="choose-block__heading">
                <div class="heading has-border has-border--center">
                    <h4>Choose Home Away Child Care Center For</h4>
                    <h2>Infant Educational Programs</h2>
                </div>
            </div>
            <!-- /.choose-block__heading-->
            <div class="choose-block__content double-column">
                <div class="row">
                    <div class="col-lg-6 column-lg">
                        <div class="choose-block__media double-column__media">
                            <figure>
                                <img src="<?php echo site_url(); ?>/media/choose-infant.jpg" alt="Infant Educational Programs">
                            </figure>
                        </div>
                        <!-- /.choose-block__media-->
                    </div>
                    <div class="col-lg-6 column-md align-self-center">
                        <div class="choose-block__info double-column__info">
                            <p>Home Away Child Care Center offers a warm, clean, fun and secure environment for your infant where your child can learn
                                and grow in their unique ways while having fun and excitement. Our caring staff will attend closely to your infants
                                regularly in a soothing environment. Our aim is to assist your child with daily necessities in a comfortable environment.
                                By developing healthy and educational skills in your child, we are confident that these programs will have the potential to
                                drive success throughout your child’s life.</p>
                            <div class="green-bg">
                                <p>If you are interested in enrolling your child in our
                                    infant-appropriate programs, do not hesitate to 
                                    <a href="#">contact us today</a></p>
                            </div>
                        </div>
                        <!-- /.choose-block__info-->
                    </div>
                </div>
            </div>
            <!-- /.choose-block__content-->
        </div>
        <!-- /.container-->
    </section>
    <!-- /.choose-block-->
</div>
<?php
get_footer();
