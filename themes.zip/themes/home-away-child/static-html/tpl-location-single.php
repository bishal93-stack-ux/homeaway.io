<?php
/* Template Name: Static Location Single */

get_header();
?>
<section class="ls-page">
    <section class="ls-intro">
        <div class="ls-intro__wrapper">
            <div class="container">
                <div class="row align-items-center ls-intro--row">
                    <div class="col-lg-6 block-left">
                        <div class="ls-intro__media">
                            <figure>
                                <img src="<?php echo site_url('/media/union-city-img.jpg'); ?>" alt="Union City Img">
                            </figure>
                        </div>
                        <!--/.ls-intro__media-->
                    </div>
                    <!--//block-left-->
                    <div class="col-lg-6 block-right">
                        <div class="ls-intro__content">
                            <div class="heading has-border">
                                <h3>Our facilities are also very<br>
                                    cozy and for the younger kids</h3>
                            </div>
                            <p>When you bring your child to Home Away Child Care Center, you can be sure that your
                                child
                                will have a great time with us. We are focused on ensuring that your child learns,
                                has a
                                lot of fun and you are kept updated on how the child is doing.</p>
                            <p>Our facilities are also very cozy and for the younger kids, we have a variety of toys
                                and play items for their use. If you are in Union City and looking for a first-class
                                childcare center, reach out to us today and let us take great care of your
                                child.</p>
                        </div>
                        <!--/.ls-intro__content-->
                    </div>
                    <!--/.block-right-->
                </div>
                <!--/.ls-intro--row-->
            </div>
        </div>
        <!--/.ls-intro__wrapper-->
    </section>
    <!--/.ls-intro-->
    <section class="ls-about bg-cover text-center">
        <img src="<?php echo site_url('/media/location-single-about-bg.jpg'); ?>" alt="Location Single About Bg">
        <div class="container">
            <div class="ls-about__wrapper">
                <div class="ls-about__content">
                    <div class="heading">
                        <h2>About Union City, New Jersey</h2>
                    </div>
                    <!--/.heading-->
                    <div class="text-wrap">
                        <p>Union City is a major town located in the County of Hudson. Union City is home to
                            approximately 70,000
                            residents and is one of the most densely populated cities in the state. Union City was
                            created through a
                            merger of two townships namely West Hoboken and Union Hill. Public education is handled
                            by the Union
                            City School District, which is one of the 31 school districts that are under the NJ
                            Schools Development
                            Authority.</p>
                        <p>The school district manages 13 schools with 14,000 students as well as 800 teachers. This
                            gives the
                            school district a ratio of about 17 students to every one teacher.</p>
                    </div>
                    <!--/.text-wrap-->
                </div>
            </div>
            <!--/.ls-about__wrapper-->
        </div>
    </section>
    <!--/.ls-about-->
    <section class="ls-services">
        <div class="container">
            <div class="ls-services__wrap">
                <div class="card-deck justify-content-center">
                    <div class="col-md-6 col-lg-4 card-item">
                        <div class="card" data-fix="height">
                            <div class="card-img">
                                <figure>
                                    <img src="<?php echo site_url('/media/educational-programs-in-union-city-nj-img.jpg'); ?>" alt="Educational Programs in Union City, NJ Img">
                                </figure>
                            </div>
                            <!--/.card-img-->
                            <div class="card-body">
                                <h5>Educational Programs in<br>
                                    Union City, NJ</h5>
                                <p>There are various educational programs available for parents in the state of New
                                    Jersey. Most of these focus on helping the children grasp what is being taught in
                                    the classroom and to learn at their own pace. These programs are tailored for
                                    children at various levels including pre-school children as well as
                                    pre-kindergarten. </p>
                            </div>
                            <!--/.card-body-->
                        </div>
                        <!--/.card-->
                    </div>
                    <!--/.card-item-->
                    <div class="col-md-6 col-lg-4 card-item">
                        <div class="card" data-fix="height">
                            <div class="card-img">
                                <figure>
                                    <img src="<?php echo site_url('/media/after-school-classes-in-union-city-nj-img.jpg'); ?>" alt="After School Classes in Union City, NJ Img">
                                </figure>
                            </div>
                            <!--/.card-img-->
                            <div class="card-body">
                                <h5>After School Classes in<br>
                                    Union City, NJ</h5>
                                <p>After school programs at Home Away Child Care Center are geared toward making it
                                    easier for your child to catch up with school work. Our highly trained staff are
                                    going to work with your child to ensure that all homework is done. We also keep you
                                    updated on the child’s progress.</p>
                            </div>
                            <!--/.card-body-->
                        </div>
                        <!--/.card-->
                    </div>
                    <!--/.card-item-->
                    <div class="col-md-6 col-lg-4 card-item">
                        <div class="card" data-fix="height">
                            <div class="card-img">
                                <figure>
                                    <img src="<?php echo site_url('/media/child-development-programs-in-union-city-nj-img.jpg'); ?>" alt="Child Development Programs in Union City, NJ Img">
                                </figure>
                            </div>
                            <!--/.card-img-->
                            <div class="card-body">
                                <h5>Child Development Programs in<br>
                                    Union City, NJ</h5>
                                <p>When you bring your pre-school child or infant to our childcare center, you can be
                                    sure that he or she will get the care and attention that they deserve. Our staff
                                    creates a warm and friendly environment, ensuring that he or she has a great time.
                                    This includes singing games and much more.</p>
                            </div>
                            <!--/.card-body-->
                        </div>
                        <!--/.card-->
                    </div>
                    <!--/.card-item-->
                </div>
                <!--.card-deck-->
            </div>
        </div>
    </section>
    <!--/.ls-services-->
    <section class="ls-choose">
        <div class="ls-choose__wrapper">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-5 block-left">
                        <div class="ls-choose__content">
                            <div class="heading has-border">
                                <h3>Choose Home Away Child Care
                                    Center for Educational Programs
                                    in Union City, NJ</h3>
                            </div>
                            <p>Our education programs at Home Away Child Care Center are geared toward helping
                                children do all this and more. We want to ensure that your child gets all the skills
                                that he or she need to achieve social and career success. With our child development
                                programs, we focus on getting the right mix between a fun-filled environment and a
                                place where children can learn. We use a variety of tried and tested approaches to
                                make learning interesting, enjoyable, and interactive.</p>
                            <p>If you are interested in enrolling your child in our educational programs in Union
                                City, do not hesitate to <a href="#">contact us today</a>.</p>
                        </div>
                        <!--/.ls-intro__content-->
                    </div>
                    <!--//block-left-->
                    <div class="col-lg-7 block-right">
                        <div class="ls-choose__media">
                            <figure>
                                <img src="<?php echo site_url('/media/choose-home-away-child-care-img.jpg'); ?>" alt="Choose Home Away Child Care Img">
                            </figure>
                        </div>
                        <!--/.ls-choose__media-->
                    </div>
                    <!--/.block-right-->
                </div>
            </div>
        </div>
        <!--/.ls-choose__wrapper-->
    </section>
    <!--/.ls-choose-->
</section>
<!--/.ls-page-->
<?php
get_footer();
