<?php
/* Template Name: Static Contact */

get_header();
?>
<div class="contact-page">
	<section class="contact">
		<div class="container">
			<div class="row">
				<div class="col-lg-5">
					<div class="contact__info">
						<div class="contact-item icon-call-bold">
							<h5>Phone Number</h5>
							<p><a href="tel:2018662906">(201) 866-2906</a></p>
						</div>
						<!-- end .contact-item -->
						<div class="contact-item icon-envelope">
							<h5>Email Address</h5>
							<p><a href="mailto:info@homeawaychildcarecenter.com">info@homeawaychildcarecenter.com</a></p>
						</div>
						<!-- end .contact-item -->
						<div class="contact-item icon-home">
							<h5>Address</h5>
							<ul>
								<li>
									<h6>HOME AWAY CHILD CARE CENTER</h6>
									<p><a href="https://goo.gl/maps/bprMqPHVYWEH6QJQ6" target="_blank">2414 Bergenline Avenue, Union City, NJ 07087</a></p>
								</li>
								<li>
									<h6>HOME AWAY III CHILD CARE CENTER</h6>
									<p><a href="https://goo.gl/maps/xKPEkmp6nRjAYdnv7" target="_blank">508-25Th Street, Union City, NJ 07087</a></p>
								</li>
								<li>
									<h6>HOME AWAY IV CHILD CARE CENTER</h6>
									<p><a href="https://goo.gl/maps/ne91TpXkdCBqZDji9" target="_blank">100 Manhattan Avenue, Union City, NJ 07087</a></p>
								</li>
							</ul>
						</div>
						<!-- end .contact-item -->
					</div>
					<!-- end .contact__info -->
				</div>
				<div class="col-lg-7">
					<div class="contact__form">
						<div class="contact__title">
							<div class="heading has-border has-border--center">
								<h4>Let Us Assist You</h4>
								<h2>Contact Us</h2>
							</div>
							<!-- end .heading -->
							<p>There's a place for your child at Home Away Child Care Center</p>
						</div>
						<!-- end .contact__title -->
						<?php echo do_shortcode('[gravityform id="1" title=flase description=false ajax=true]'); ?>
					</div>
					<!-- end .contact__form -->
				</div>
			</div>
		</div>
	</section>
	<!-- end .contact -->

	<section class="contact-map bg-cover">
		<img src="<?php echo home_url('media/google-map.jpg'); ?>" alt="Map">
		<div class="container">
			<div class="location">
				<button>
					<span class="icon-pin"><span class="path1"></span><span class="path2"></span></span>
				</button>
				<div class="location__popup">
					<button>&times;</button>
					<p>100 Manhattan Avenue Union City, NJ 07087</p>
				</div>
			</div>
			<!-- end location -->
			<div class="location">
				<button>
					<span class="icon-pin"><span class="path1"></span><span class="path2"></span></span>
				</button>
				<div class="location__popup">
					<button>&times;</button>
					<p>2414 Bergenline Avenue Union City,</p>
				</div>
			</div>
			<!-- end location -->
			<div class="location">
				<button>
					<span class="icon-pin"><span class="path1"></span><span class="path2"></span></span>
				</button>
				<div class="location__popup">
					<button>&times;</button>
					<p>508-25Th Street Union City, NJ 07087</p>
				</div>
			</div>
			<!-- end location -->
		</div>
	</section>
	<!-- end .contact-map -->
</div>
<!-- end .contact-page -->

<?php
get_footer();
