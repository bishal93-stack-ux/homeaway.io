<?php
/* Template Name: Static Testimonials */

get_header();
?>
    <section class="testimonials-page">
        <div class="testimonials">
            <div class="container">
                <div class="card-deck">
                    <div class="col-12 card-item card-item--featured">
                        <div class="card">
                            <blockquote>
                                <ul class="star-ratings">
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                </ul>
                                <div class="author">
                                    <span>Casey Scherck</span>
                                </div>
                                <p>Great facility, staff & teachers! This is our first daycare and our daughter started
                                    at 6
                                    months and has thrived in the infant room. After warming up to the teachers the
                                    first
                                    few days, she now has a smile both arriving and leaving each day. As a first time
                                    parent, I also appreciate pictures and nap/feeding updates throughout the day via
                                    the
                                    Tadpoles app.</p>
                            </blockquote>
                        </div><!--/.card /.card--alt -->
                    </div><!--/.card-item card-item--alt -->
                    <div class="col-sm-6 col-lg-4 card-item">
                        <div class="card" data-fancybox data-src="#testimonials-popup2" data-fix="height">
                            <blockquote>
                                <ul class="star-ratings">
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                </ul>
                                <div class="author">
                                    <span>Michelle Garcia</span>
                                </div>
                                <p>(Translated by Google) Having your son or daughter in this child care center I
                                    describe in two words: tranquility...</p>
                            </blockquote>
                            <div id="testimonials-popup2" class="testimonials-popup" style="display: none">
                                <ul class="star-ratings">
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                </ul>
                                <div class="author">
                                    <span>Michelle Garcia</span>
                                </div>
                                <p>(Translated by Google) Having your son or daughter in this child care center I
                                    describe in two words: tranquility...</p>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cumque delectus eligendi
                                    fugit molestiae praesentium repudiandae tempora. Accusantium atque commodi itaque
                                    labore nemo odio officiis, omnis repudiandae ullam! Accusantium, laudantium
                                    nulla?</p>
                            </div><!--/.testimonials-popup-->
                        </div><!--/.card-->
                    </div><!--/.card-item-->
                    <div class="col-sm-6 col-lg-4 card-item">
                        <div class="card" data-fancybox data-src="#testimonials-popup3" data-fix="height">
                            <blockquote>
                                <ul class="star-ratings">
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                </ul>
                                <div class="author">
                                    <span>sharlene pena</span>
                                </div>
                                <p>Great place for kids! infants and toddlers. My son loves it and the teachers are so
                                    sweet and very caring !!</p>
                            </blockquote>
                            <div id="testimonials-popup3" class="testimonials-popup" style="display: none">
                                <ul class="star-ratings">
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                </ul>
                                <div class="author">
                                    <span>sharlene pena</span>
                                </div>
                                <p>Great place for kids! infants and toddlers. My son loves it and the teachers are so
                                    sweet and very caring !!</p>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium animi aperiam
                                    corporis cumque dignissimos doloremque ea error esse, et excepturi fugiat magni
                                    mollitia nisi provident quis reprehenderit voluptate? Ex, perspiciatis?</p>
                            </div><!--/.testimonials-popup-->
                        </div><!--/.card-->
                    </div><!--/.card-item-->
                    <div class="col-sm-6 col-lg-4 card-item">
                        <div class="card" data-fancybox data-src="#testimonials-popup4" data-fix="height">
                            <blockquote>
                                <ul class="star-ratings">
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                </ul>
                                <div class="author">
                                    <span>Allie Beach</span>
                                </div>
                                <p>We love the facility; great teachers in the infant room; good communication from
                                    staff. I'm very happy with the decision to put my...</p>
                            </blockquote>
                            <div id="testimonials-popup4" class="testimonials-popup" style="display: none">
                                <ul class="star-ratings">
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                </ul>
                                <div class="author">
                                    <span>Allie Beach</span>
                                </div>
                                <p>We love the facility; great teachers in the infant room; good communication from
                                    staff. I'm very happy with the decision to put my...</p>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusamus accusantium
                                    assumenda distinctio, dolore facere fuga id incidunt ipsum libero modi neque, nisi
                                    omnis pariatur porro quasi, tenetur ullam vel voluptatum.</p>
                            </div><!--/.testimonials-popup-->
                        </div><!--/.card-->
                    </div><!--/.card-item-->
                    <div class="col-sm-6 col-lg-4 card-item">
                        <div class="card" data-fancybox data-src="#testimonials-popup5" data-fix="height">
                            <blockquote>
                                <ul class="star-ratings">
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                </ul>
                                <div class="author">
                                    <span>linda campos</span>
                                </div>
                                <p>I highly recommend Home Away III Day Care Center. My son had the most beautiful
                                    experience. He started when he was 1 1/2 years old...</p>
                            </blockquote>
                            <div id="testimonials-popup5" class="testimonials-popup" style="display: none">
                                <ul class="star-ratings">
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                </ul>
                                <div class="author">
                                    <span>linda campos</span>
                                </div>
                                <p>I highly recommend Home Away III Day Care Center. My son had the most beautiful
                                    experience. He started when he was 1 1/2 years old...</p>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusamus accusantium
                                    assumenda distinctio, dolore facere fuga id incidunt ipsum libero modi neque, nisi
                                    omnis pariatur porro quasi, tenetur ullam vel voluptatum.</p>
                            </div><!--/.testimonials-popup-->
                        </div><!--/.card-->
                    </div><!--/.card-item-->
                    <div class="col-sm-6 col-lg-4 card-item">
                        <div class="card" data-fancybox data-src="#testimonials-popup6" data-fix="height">
                            <blockquote>
                                <ul class="star-ratings">
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                </ul>
                                <div class="author">
                                    <span>Fior Lugo</span>
                                </div>
                                <p>We don't know where to start in terms of how happy we are with the loving care and
                                    education our daughter is receiving. Home Away...</p>
                            </blockquote>
                            <div id="testimonials-popup6" class="testimonials-popup" style="display: none">
                                <ul class="star-ratings">
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                </ul>
                                <div class="author">
                                    <span>Fior Lugo</span>
                                </div>
                                <p>We don't know where to start in terms of how happy we are with the loving care and
                                    education our daughter is receiving. Home Away...</p>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusamus accusantium
                                    assumenda distinctio, dolore facere fuga id incidunt ipsum libero modi neque, nisi
                                    omnis pariatur porro quasi, tenetur ullam vel voluptatum.</p>
                            </div><!--/.testimonials-popup-->
                        </div><!--/.card-->
                    </div><!--/.card-item-->
                    <div class="col-sm-6 col-lg-4 card-item">
                        <div class="card" data-fancybox data-src="#testimonials-popup7" data-fix="height">
                            <blockquote>
                                <ul class="star-ratings">
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                </ul>
                                <div class="author">
                                    <span>Priscilla Gonzalez</span>
                                </div>
                                <p>Home Away lII is a great child care center that was recommended by a few of my
                                    husband’s co-workers. We enrolled our son...</p>
                            </blockquote>
                            <div id="testimonials-popup7" class="testimonials-popup" style="display: none">
                                <ul class="star-ratings">
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                </ul>
                                <div class="author">
                                    <span>Priscilla Gonzalez</span>
                                </div>
                                <p>Home Away lII is a great child care center that was recommended by a few of my
                                    husband’s co-workers. We enrolled our son...</p>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusamus accusantium
                                    assumenda distinctio, dolore facere fuga id incidunt ipsum libero modi neque, nisi
                                    omnis pariatur porro quasi, tenetur ullam vel voluptatum.</p>
                            </div><!--/.testimonials-popup-->
                        </div><!--/.card-->
                    </div><!--/.card-item-->
                    <div class="col-sm-6 col-lg-4 card-item">
                        <div class="card" data-fancybox data-src="#testimonials-popup8" data-fix="height">
                            <blockquote>
                                <ul class="star-ratings">
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                </ul>
                                <div class="author">
                                    <span>Sairilin Parra</span>
                                </div>
                                <p>If you are looking for a clean and safe environment for your child, I highly
                                    recommend this daycare. My son attended Home Away...</p>
                            </blockquote>
                            <div id="testimonials-popup8" class="testimonials-popup" style="display: none">
                                <ul class="star-ratings">
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                </ul>
                                <div class="author">
                                    <span>Sairilin Parra</span>
                                </div>
                                <p>If you are looking for a clean and safe environment for your child, I highly
                                    recommend this daycare. My son attended Home Away...</p>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusamus accusantium
                                    assumenda distinctio, dolore facere fuga id incidunt ipsum libero modi neque, nisi
                                    omnis pariatur porro quasi, tenetur ullam vel voluptatum.</p>
                            </div><!--/.testimonials-popup-->
                        </div><!--/.card-->
                    </div><!--/.card-item-->
                    <div class="col-sm-6 col-lg-4 card-item">
                        <div class="card" data-fancybox data-src="#testimonials-popup9" data-fix="height">
                            <blockquote>
                                <ul class="star-ratings">
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                </ul>
                                <div class="author">
                                    <span>Emma Perez</span>
                                </div>
                                <p>This daycare has taught my daughter who is only 3 much more than what i knew when I
                                    was three. At this point my daughter can count...</p>
                            </blockquote>
                            <div id="testimonials-popup9" class="testimonials-popup" style="display: none">
                                <ul class="star-ratings">
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                </ul>
                                <div class="author">
                                    <span>Emma Perez</span>
                                </div>
                                <p>This daycare has taught my daughter who is only 3 much more than what i knew when I
                                    was three. At this point my daughter can count...</p>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusamus accusantium
                                    assumenda distinctio, dolore facere fuga id incidunt ipsum libero modi neque, nisi
                                    omnis pariatur porro quasi, tenetur ullam vel voluptatum.</p>
                            </div><!--/.testimonials-popup-->
                        </div><!--/.card-->
                    </div><!--/.card-item-->
                    <div class="col-sm-6 col-lg-4 card-item">
                        <div class="card" data-fancybox data-src="#testimonials-popup10" data-fix="height">
                            <blockquote>
                                <ul class="star-ratings">
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                </ul>
                                <div class="author">
                                    <span>Z B</span>
                                </div>
                                <p>Both of my sons attended this center until they turned four years old. My oldest son
                                    has ADHD and impulse control difficulties...</p>
                            </blockquote>
                            <div id="testimonials-popup10" class="testimonials-popup" style="display: none">
                                <ul class="star-ratings">
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                </ul>
                                <div class="author">
                                    <span>Z B</span>
                                </div>
                                <p>Both of my sons attended this center until they turned four years old. My oldest son
                                    has ADHD and impulse control difficulties...</p>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusamus accusantium
                                    assumenda distinctio, dolore facere fuga id incidunt ipsum libero modi neque, nisi
                                    omnis pariatur porro quasi, tenetur ullam vel voluptatum.</p>
                            </div><!--/.testimonials-popup-->
                        </div><!--/.card-->
                    </div><!--/.card-item-->
                    <div class="col-sm-6 col-lg-4 card-item">
                        <div class="card" data-fancybox data-src="#testimonials-popup11" data-fix="height">
                            <blockquote>
                                <ul class="star-ratings">
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                </ul>
                                <div class="author">
                                    <span>Guillermo Mayol</span>
                                </div>
                                <p>This is a GEM of a Daycare right in the heart of Union City!! Top-notch and with
                                    reasonable prices! Look no further, this Daycare...</p>
                            </blockquote>
                            <div id="testimonials-popup11" class="testimonials-popup" style="display: none">
                                <ul class="star-ratings">
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                </ul>
                                <div class="author">
                                    <span>Guillermo Mayol</span>
                                </div>
                                <p>This is a GEM of a Daycare right in the heart of Union City!! Top-notch and with
                                    reasonable prices! Look no further, this Daycare...</p>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusamus accusantium
                                    assumenda distinctio, dolore facere fuga id incidunt ipsum libero modi neque, nisi
                                    omnis pariatur porro quasi, tenetur ullam vel voluptatum.</p>
                            </div><!--/.testimonials-popup-->
                        </div><!--/.card-->
                    </div><!--/.card-item-->
                    <div class="col-sm-6 col-lg-4 card-item">
                        <div class="card" data-fancybox data-src="#testimonials-popup12" data-fix="height">
                            <blockquote>
                                <ul class="star-ratings">
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                </ul>
                                <div class="author">
                                    <span>Kelvin Jimenez</span>
                                </div>
                                <p>(Translated by Google) Fantastic place to leave your child in the care of a
                                    responsible and professional staff, everything is very clean...</p>
                            </blockquote>
                            <div id="testimonials-popup12" class="testimonials-popup" style="display: none">
                                <ul class="star-ratings">
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                </ul>
                                <div class="author">
                                    <span>Kelvin Jimenez</span>
                                </div>
                                <p>(Translated by Google) Fantastic place to leave your child in the care of a
                                    responsible and professional staff, everything is very clean...</p>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusamus accusantium
                                    assumenda distinctio, dolore facere fuga id incidunt ipsum libero modi neque, nisi
                                    omnis pariatur porro quasi, tenetur ullam vel voluptatum.</p>
                            </div><!--/.testimonials-popup-->
                        </div><!--/.card-->
                    </div><!--/.card-item-->
                    <div class="col-sm-6 col-lg-4 card-item">
                        <div class="card" data-fancybox data-src="#testimonials-popup13" data-fix="height">
                            <blockquote>
                                <ul class="star-ratings">
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                </ul>
                                <div class="author">
                                    <span>Melissa Olivo</span>
                                </div>
                                <p>The Infant room is absolutely incredible. The ladies there truly take care of the
                                    children. Sadly, when the child goes into...</p>
                            </blockquote>
                            <div id="testimonials-popup13" class="testimonials-popup" style="display: none">
                                <ul class="star-ratings">
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                    <li><span class="icon-star"></span></li>
                                </ul>
                                <div class="author">
                                    <span>Melissa Olivo</span>
                                </div>
                                <p>The Infant room is absolutely incredible. The ladies there truly take care of the
                                    children. Sadly, when the child goes into...</p>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusamus accusantium
                                    assumenda distinctio, dolore facere fuga id incidunt ipsum libero modi neque, nisi
                                    omnis pariatur porro quasi, tenetur ullam vel voluptatum.</p>
                            </div><!--/.testimonials-popup-->
                        </div><!--/.card-->
                    </div><!--/.card-item-->
                </div><!--/card-deck-->
                <div class="btn-wrap text-center">
                    <a href="#" class="btn btn-primary">Load More <span class="icon icon-refresh"></span></a>
                </div>
            </div>
        </div>
    </section><!--/.testimonials-page-->
<?php
get_footer();