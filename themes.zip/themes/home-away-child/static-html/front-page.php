<?php

/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Home_Away_Child_Care_Center
 */

get_header();
?>
<section class="block block-banner bg-cover">
    <img src="<?php echo home_url(); ?>/media/banner-bg.png" alt="Home Away Child Care Banner Image">
    <div class="container">
        <div class="banner-contents">
            <div class="section-heading">
                <h3>Welcome to</h3>
                <div class="main-heading">
                    <span class="red">H</span>
                    <span>O</span>
                    <span class="green">M</span>
                    <span>E</span>
                    <span class="yellow">A</span>
                    <span>W</span>
                    <span class="leaf-green">A</span>
                    <span>Y</span>
                </div>
                <span class="triangle"></span>
                <h1>Child Care Center</h1>
            </div>
            <div class="banner-buttons">
                <a href="#" class="btn btn-schedule">Schedule a Tour <span class="icon-pointed-arrow"></span></a>
                <a href="#" class="btn btn-enroll">Enroll Now <span class="icon icon-pointed-arrow"></span></a>
            </div>
        </div>
    </div>
</section>
<!--/.block-banner -->

<div class="education-program">
    <section class="card-block areas-of-expertise">
        <div class="container">
            <div class="card-block__heading areas-of-expertise__heading">
                <div class="heading has-border has-border--center">
                    <h4>Home Away Child Care Center </h4>
                    <h2>education program</h2>
                </div>
                <p>Our mission is to assist your child in any style that he/she may learn best in while providing an environment that is safe, clean, warm, positive and responsive. </p>
            </div>
            <!-- /.card-block__heading-->
            <div class="card-block__content areas-of-expertise__content">
                <div class="card-block__item areas-of-expertise__item">
                    <div class="item-wrap">
                        <a href="#" class="stretched-link"></a>
                        <div class="card-block__img bg-cover">
                            <img src="<?php echo site_url(); ?>/media/aoe-img1.png" alt="Infant Image">
                        </div>
                        <div class="card-block__text areas-of-expertise__text" data-fix="height">
                            <a href="#">Infants</a>
                            <p>Our Infant Program offers a warm, secure environment</p>
                        </div>
                    </div>
                    <!-- /.item-wrap-->
                </div>
                <!-- /cad-block__item-->
                <div class="card-block__item areas-of-expertise__item">
                    <div class="item-wrap">
                        <a href="#" class="stretched-link"></a>
                        <div class="card-block__img bg-cover">
                            <img src="<?php echo site_url(); ?>/media/aoe-img2.png" alt="Toddlers Image">
                        </div>
                        <div class="card-block__text areas-of-expertise__text" data-fix="height">
                            <a href="#">Toddlers</a>
                            <p>Our Toddler program provides experiences that support each</p>
                        </div>
                    </div>
                    <!-- /.item-wrap-->
                </div>
                <!-- /cad-block__item-->
                <div class="card-block__item areas-of-expertise__item">
                    <div class="item-wrap">
                        <a href="#" class="stretched-link"></a>
                        <div class="card-block__img bg-cover">
                            <img src="<?php echo site_url(); ?>/media/aoe-img3.png" alt="Preschoolers Image">
                        </div>
                        <div class="card-block__text areas-of-expertise__text" data-fix="height">
                            <a href="#">Preschoolers</a>
                            <p>Our Preschool Program allows opportunities for our</p>
                        </div>
                    </div>
                    <!-- /.item-wrap-->
                </div>
                <!-- /cad-block__item-->
                <div class="card-block__item areas-of-expertise__item">
                    <div class="item-wrap">
                        <a href="#" class="stretched-link"></a>
                        <div class="card-block__img bg-cover">
                            <img src="<?php echo site_url(); ?>/media/aoe-img4.png" alt="Pre-Kindergarten Students Image">
                        </div>
                        <div class="card-block__text areas-of-expertise__text" data-fix="height">
                            <a href="#">Pre-Kindergarten</a>
                            <p>Our Aftercare Program allows school-aged children to balance</p>
                        </div>
                    </div>
                    <!-- /.item-wrap-->
                </div>
                <!-- /cad-block__item-->
                <div class="card-block__item areas-of-expertise__item">
                    <div class="item-wrap">
                        <a href="#" class="stretched-link"></a>
                        <div class="card-block__img bg-cover">
                            <img src="<?php echo site_url(); ?>/media/aoe-img5.png" alt="After School Students Image">
                        </div>
                        <div class="card-block__text areas-of-expertise__text" data-fix="height">
                            <a href="#">After School</a>
                            <p>Our Aftercare Program allows school-aged children to balance</p>
                        </div>
                    </div>
                    <!-- /.item-wrap-->
                </div>
                <!-- /cad-block__item-->
            </div>
            <!-- /.card-block__content-->
            <div class="btn-wrap text-center">
                <a href="#" class="btn">Schedule a Tour <span class="icon-pointed-arrow"></span></a>
            </div>
            <!-- /.card-block__bottom-->
        </div>
        <!-- /.container-->
    </section>
    <!-- /.card-block-->
</div>
<!--/.education-program-->

<section class="block block-about-us">
    <div class="two-col-full">
        <div class="double-column">
            <div class="row no-gutters">
                <div class="col-lg-6 double-column__info">
                    <div class="content-holder">
                        <div class="heading has-border">
                            <h4>About Us</h4>
                            <h2>Home Away Child Care Center</h2>
                        </div>
                        <p>
                            Our Infant Program offers a warm, secure environment where infants receive personalized care based on his or her unique schedule. Throughout the day, you will see teachers talking and singing with your child during feeding, diaper changing, and playtime.
                        </p>

                        <p>
                            This interaction will help your baby understand language. We will provide you with a daily report, letting you know about your infants diaper, feeding and sleep scehdule throughout the day.
                        </p>
                        <a href="#" class="btn">Schedule a Tour <span class="icon-pointed-arrow"></span></a>
                    </div>
                </div>
                <div class="col-lg-6 bg-cover double-column__media">
                    <img src="<?php echo site_url(); ?>/media/about-us-bg-img.jpg" alt="About Us Image">
                </div>
            </div>
        </div>
    </div>
</section>

<section class="block block-facilities">
    <div class="container">
        <div class="block-facilities__wrap">
            <div class="row">
                <div class="col-lg-6 block-left">
                    <div class="block-left__wrap">
                        <div class="row no-gutters">
                            <div class="col-sm-6 leftaside">
                                <div class="media-item">
                                    <div class="media-card">
                                        <div class="media-card__img bg-cover">
                                            <img src="<?php echo site_url(); ?>/media/facility1.png" alt="Spanish Class">
                                            <figcaption>
                                                <div class="media-card__info">
                                                    <h6>Spanish Class</h6>
                                                </div>
                                            </figcaption>
                                        </div>
                                    </div>
                                </div>
                                <div class="media-item">
                                    <div class="media-card">
                                        <div class="media-card__img bg-cover">
                                            <img src="<?php echo site_url(); ?>/media/facility3.png" alt="Playground">
                                            <figcaption>
                                                <div class="media-card__info">
                                                    <h6>Playground</h6>
                                                </div>
                                            </figcaption>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div class="col-sm-6 rightaside">
                                <div class="media-item">
                                    <div class="media-card">
                                        <div class="media-card__img bg-cover">
                                            <img src="<?php echo site_url(); ?>/media/facility2.png" alt="Enrichment Program">
                                            <figcaption>
                                                <div class="media-card__info">
                                                    <h6>Enrichment Program</h6>
                                                </div>
                                            </figcaption>
                                        </div>
                                    </div>
                                </div>
                                <div class="media-item">
                                    <div class="media-card">
                                        <div class="media-card__img bg-cover">
                                            <img src="<?php echo site_url(); ?>/media/facility4.png" alt="Summer Camp">
                                            <figcaption>
                                                <div class="media-card__info">
                                                    <h6>Summer Camp</h6>
                                                </div>
                                            </figcaption>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6 block-right">
                    <div class="content-holder">
                        <div class="heading has-border">
                            <h4>Why Choose Us</h4>
                            <h2>Our Facilities</h2>
                        </div>
                        <p>
                            With three convenient locations in Union City, New Jersey, Home Away Child Care Center provides a safe, clean, and secure environment supported by nurturing and enthusiastic staff.
                        </p>
                        <p>
                            Our staff members dedicate their time and efforts to ensuring your child receives the highest quality care at our facilities, and provide comfort, convenience, and peace of mind to working parents in our community.
                        </p>
                        <a href="tel:2018662906" class="btn btn-phone"><span class="icon-telephone"></span>(201) 866-2906</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="block block-contact-form">
    <div class="row no-gutters">
        <div class="col-lg-6 bg-cover block-left">
            <img src="<?php echo site_url(); ?>/media/contact-img.jpg" alt="Contact Us Image">
        </div>

        <div class="col-lg-6 block-right">
            <div class="content-holder">
                <div class="heading has-border">
                    <h4>Easy To Get To</h4>
                    <h2>Contact Us</h2>
                </div>
                <p>There's a place for your child at Home Away Child Care Center</p>
                <?php echo do_shortcode('[gravityform id="1" title="false" description="false" ajax="true"]'); ?>
            </div>
        </div>
    </div>
</section>

<section class="development-intro">
    <div class="container">
        <div class="development-intro__content double-column">
            <div class="row">
                <div class="col-lg-6">
                    <div class="development-intro__media double-column__media">
                        <div class="img-composition__img">
                            <div class="img-composition__img img-composition__img-box">
                                <div class="img-composition__img img-composition__img-box img-composition__img-box--one">
                                    <img src="<?php echo site_url(); ?>/media/activity1.png" alt="Image composition">
                                </div>
                                <div class="img-composition__img img-composition__img-box img-composition__img-box--two">
                                    <img src="<?php echo site_url(); ?>/media/activity2.png" alt="Image composition">
                                </div>
                                <div class="img-composition__img img-composition__img-box img-composition__img-box--three">
                                    <img src="<?php echo site_url(); ?>/media/activity3.png" alt="Image composition">
                                </div>
                                <div class="img-composition__img img-composition__img-box img-composition__img-box--four">
                                    <img src="<?php echo site_url(); ?>/media/activity4.png" alt="Image composition">
                                </div>
                                <div class="img-composition__img img-composition__img-box img-composition__img-box--five">
                                    <img src="<?php echo site_url(); ?>/media/activity5.png" alt="Image composition">
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- /.development-intro__media-->
                </div>
                <div class="col-lg-6 align-self-center">
                    <div class="development-intro__info double-column__info">
                        <div class="heading has-border">
                            <h4>Why Choose Us</h4>
                            <h2>Our Activities</h2>
                        </div>
                        <div class="paragraph-holder">
                            <p>
                                We believe in age-appropriate learning based on the philosophy of instilling curiosity and fostering creative expression. By infusing arts, language, music, and socialization into our daily structured learning, children in our care develop a well-rounded foundation for their education in future years.
                            </p>
                            <p>
                                Our curriculum is goal-directed, based on ongoing assessments for each child’s strengths and interests. With this information, learning can be guided while the child’s social and emotional development is supported.
                            </p>
                        </div>
                    </div>
                    <!-- /.development-introl__info-->
                </div>
            </div>
        </div>
        <!-- /.development-intro__content-->
    </div>
    <!-- /.container-->
</section>
<!-- /.development-intro-->

<section class="block block-child-development">
    <div class="container">
        <div class="heading has-border has-border--center">
            <h4>Home Away Child Care Center </h4>
            <h2>Child Development</h2>
        </div>

        <div class="block-child-development__wrapper">
            <div class="row">
                <div class="col-lg-6 media-card__outer">
                    <div class="media-card">
                        <div class="media-card__content">
                            <h4>Cognitive <br> Development</h4>
                            <p>Lorem ipsum dolor sit amet, consetetur sadipscing Lorem ipsum dolor sit amet, dolor
                            </p>
                            <a href="#" class="stretched-link">Read More</a>
                        </div>

                        <div class="media-card__image bg-cover">
                            <img src="<?php echo site_url(); ?>/media/child-dev1.jpg" alt="Cognitive Development">
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 media-card__outer">
                    <div class="media-card">
                        <div class="media-card__content">
                            <h4>Physical / Motor <br>
                                Skills Development</h4>
                            <p>Lorem ipsum dolor sit amet, consetetur sadipscing Lorem ipsum dolor sit amet, dolor
                            </p>
                            <a href="#" class="stretched-link">Read More</a>
                        </div>

                        <div class="media-card__image bg-cover">
                            <img src="<?php echo site_url(); ?>/media/child-dev2.jpg" alt="Physical / Motor Skills Development">
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 media-card__outer">
                    <div class="media-card">
                        <div class="media-card__content">
                            <h4>Confidence and <br>
                                Social Development</h4>
                            <p>Lorem ipsum dolor sit amet, consetetur sadipscing Lorem ipsum dolor sit amet, dolor
                            </p>
                            <a href="#" class="stretched-link">Read More</a>
                        </div>

                        <div class="media-card__image bg-cover">
                            <img src="<?php echo site_url(); ?>/media/child-dev3.jpg" alt="Confidence and Social Development">
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 media-card__outer">
                    <div class="media-card">
                        <div class="media-card__content">
                            <h4>Communication <br> Development</h4>
                            <p>Lorem ipsum dolor sit amet, consetetur sadipscing Lorem ipsum dolor sit amet, dolor
                            </p>
                            <a href="#" class="stretched-link">Read More</a>
                        </div>

                        <div class="media-card__image bg-cover">
                            <img src="<?php echo site_url(); ?>/media/child-dev4.jpg" alt="Communication composition">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="blog-home">
    <div class="container">
        <div class="blog-home__wrap">
            <div class="heading has-border has-border--center">
                <h4>Our</h4>
                <h2>Blog</h2>
            </div>
            <div class="row">
                <div class="col-md-6 col-xl-4 blog-home__block">
                    <blockquote class="blog-home__item">
                        <figure>
                            <img src="<?php echo home_url('/media/blog-img1.jpg') ?>" alt="Blog Image">
                            <div class="post-date">
                                <span class="entry-date"><?php echo get_the_date('d M'); ?></span>

                            </div>
                        </figure>
                        <div class="blog-home__content">
                            <h4><a href="#" class="stretched-link">Lorem ipsum is a dummy text</a></h4>
                            <p>Lorem ipsum is placeholder text commonly used in the graphic, print, and publishing Lorem ipsum is placeholder text.</p>
                            <a href="#" class="more">Read More</a>
                            <div class="blog-home__details">
                                <span><i class="icon-user"></i> Admin</span>
                                <span><i class="icon-heart"></i> 160</span>
                                <span><i class="icon-comment"></i> 3</span>
                            </div>
                        </div>
                    </blockquote>
                </div>

                <div class="col-md-6 col-xl-4 blog-home__block">
                    <blockquote class="blog-home__item">
                        <figure>
                            <img src="<?php echo home_url('/media/blog-img2.jpg') ?>" alt="Blog Image">
                            <div class="post-date">
                                <span class="entry-date"><?php echo get_the_date('d M'); ?></span>

                            </div>
                        </figure>
                        <div class="blog-home__content">
                            <h4><a href="#" class="stretched-link">Lorem ipsum is a dummy text</a></h4>
                            <p>Lorem ipsum is placeholder text commonly used in the graphic, print, and publishing Lorem ipsum is placeholder text.</p>
                            <a href="#" class="more">Read More</a>
                            <div class="blog-home__details">
                                <span><i class="icon-user"></i> Admin</span>
                                <span><i class="icon-heart"></i> 160</span>
                                <span><i class="icon-comment"></i> 3</span>
                            </div>
                        </div>
                    </blockquote>
                </div>

                <div class="col-md-6 col-xl-4 blog-home__block">
                    <blockquote class="blog-home__item">
                        <figure>
                            <img src="<?php echo home_url('/media/blog-img3.jpg') ?>" alt="Blog Image">
                            <div class="post-date">
                                <span class="entry-date"><?php echo get_the_date('d M'); ?></span>

                            </div>
                        </figure>
                        <div class="blog-home__content">
                            <h4><a href="#" class="stretched-link">Lorem ipsum is a dummy text</a></h4>
                            <p>Lorem ipsum is placeholder text commonly used in the graphic, print, and publishing Lorem ipsum is placeholder text.</p>
                            <a href="#" class="more">Read More</a>
                            <div class="blog-home__details">
                                <span><i class="icon-user"></i> Admin</span>
                                <span><i class="icon-heart"></i> 160</span>
                                <span><i class="icon-comment"></i> 3</span>
                            </div>
                        </div>
                    </blockquote>
                </div>

            </div>
            <div class="btn-wrap text-center">
                <a href="#" class="btn btn-schedule">View All <span class="icon-pointed-arrow"></span></a>
            </div>
        </div>
    </div>
</section>
<!-- .blog -->

<section class="schedule-apply">
    <div class="schedule-apply__wrap">
        <div class="schedule-apply__content">
            <div class="schedule">
                <div class="schedule-apply__item">
                    <h3>Schedule a tour</h3>
                    <p>Contact us to tour any of our three locations in Union City, NJ.</p>
                    <a href="#" class="btn primary stretched-link">Schedule a tour</a>
                </div>
            </div>
            <!-- .schedule -->
            <div class="apply">
                <div class="schedule-apply__item">
                    <h3>Apply to enroll</h3>
                    <p>Contact us to enroll in any one of our childcare programs.</p>
                    <a href="#" class="btn primary stretched-link">Enroll now</a>
                </div>
            </div>
            <!-- .apply -->
        </div>
        <!-- .schedule-apply__content -->
    </div>
</section>
<!-- .schedule-apply -->

<section class="testimonials bg-cover">
    <img src="<?php echo home_url('/media/testimonial-bgcover.jpg') ?>" alt="">
    <div class="testimonials__wrap">
        <div class="heading has-border has-border--center">
            <h4>Testimonials</h4>
            <h2>What Parents Say</h2>
        </div>
        <div class="testimonials__slider">
            <div class="testimonials__item">
                <div class="testimonials__block">
                    <div class="star-list">
                        <ul>
                            <li><i class="icon-star"></i></li>
                            <li><i class="icon-star"></i></li>
                            <li><i class="icon-star"></i></li>
                            <li><i class="icon-star"></i></li>
                            <li><i class="icon-star"></i></li>
                        </ul>
                    </div>
                    <h5 class="posted-by">Casey Scherck</h5>
                    <div class="content">
                        Great facility, staff & teachers! This is our first daycare and our daughter started at 6 months and has thrived in the infant room.
                    </div>
                </div>
            </div>
            <!-- .testimonials__item -->
            <div class="testimonials__item">
                <div class="testimonials__block">
                    <div class="star-list">
                        <ul>
                            <li><i class="icon-star"></i></li>
                            <li><i class="icon-star"></i></li>
                            <li><i class="icon-star"></i></li>
                            <li><i class="icon-star"></i></li>
                            <li><i class="icon-star"></i></li>
                        </ul>
                    </div>
                    <h5 class="posted-by">Sharlene Pena</h5>
                    <div class="content">
                        Great place for kids! infants and toddlers. My son loves it and the teachers are so sweet and very caring !!
                    </div>
                </div>
            </div>
            <!-- .testimonials__item -->
            <div class="testimonials__item">
                <div class="testimonials__block">
                    <div class="star-list">
                        <ul>
                            <li><i class="icon-star"></i></li>
                            <li><i class="icon-star"></i></li>
                            <li><i class="icon-star"></i></li>
                            <li><i class="icon-star"></i></li>
                            <li><i class="icon-star"></i></li>
                        </ul>
                    </div>
                    <h5 class="posted-by">Allie Beach</h5>
                    <div class="content">
                        We love the facility; great teachers in the infant room; good communication from staff. I'm very happy with the decision to put my daughter here.
                    </div>
                </div>
            </div>
            <!-- .testimonials__item -->
            <div class="testimonials__item">
                <div class="testimonials__block">
                    <div class="star-list">
                        <ul>
                            <li><i class="icon-star"></i></li>
                            <li><i class="icon-star"></i></li>
                            <li><i class="icon-star"></i></li>
                            <li><i class="icon-star"></i></li>
                            <li><i class="icon-star"></i></li>
                        </ul>
                    </div>
                    <h5 class="posted-by">Sharlene Pena</h5>
                    <div class="content">
                        Great place for kids! infants and toddlers. My son loves it and the teachers are so sweet and very caring !!
                    </div>
                </div>
            </div>
            <!-- .testimonials__item -->
        </div>
        <!-- .testimonials__slider -->
    </div>
    <!-- .testimonials__wrap -->
</section>
<!-- .testimonials -->

<?php
get_footer();
