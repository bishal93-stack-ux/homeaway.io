<?php
/* Template Name: Education Program */

get_header();
?>
<div class="education-program-page">
    <div class="education-program">
        <?php if ( have_rows('ss_flexible_content') ) :
            while ( have_rows('ss_flexible_content') ) : 
                the_row();
                if ( get_row_layout() == 'post_section' ) {
                    $collapse = 'yes'; // to check post section
                    get_template_part('template-parts/program/' . get_row_layout());
                    // if post section found it will create a collapse section
                    echo '<div class="collapse" id="collapseExample">';
                } 
                else {
                    get_template_part('template-parts/program/' . get_row_layout());
                }
            endwhile;
        endif;?>
        <?php 
        // if collapse section found then close a div tag
        if ( $collapse ) {
            echo '</div>';
        }
        ?>
    </div>
    <!--/.education-program-->
</div>
<!--/.education-program-page-->
<?php
get_footer();
