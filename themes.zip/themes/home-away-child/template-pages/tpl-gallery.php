<?php
/* Template Name: Gallery */

get_header();
if ( have_posts() ) :
    while ( have_posts() ) :
        the_post();
        $images = get_field('ss_gallery');
        $total = count(get_field('ss_gallery'));
        $number = 9; // the number of rows to show
        $count = 0; // a counter
        if ( $images ) {
        ?>
            <section class="gallery-page">
                <div class="container">
                    <div class="block block-gallery">
                        <div class="card-deck no-gutters card-deck--gallery">
                            <?php foreach( $images as $image ){
                                $resized_url = aq_resize($image['url'], 446, 476, true, true, true); ?>
                                <div class="col-6 col-lg-4 card-item">
                                    <div class="card rounded">
                                        <div class="card-img">
                                            <figure>
                                                <a href="<?php echo $image['url']; ?>" data-fancybox="gallery"><img
                                                            src="<?php echo $resized_url; ?>"
                                                            alt="<?php echo $image['alt'];?>"></a>
                                            </figure>
                                        </div><!--/.card-img-->
                                    </div><!--/.card rounded-->
                                </div><!--/.card-item-->
                                <?php
                                $count++;
                                if ($count == $number) {
                                    // we've shown the number, break out of loop
                                    break;
                                } 
                            } ?>    

                        </div><!--/.card-deck /.card-deck--gallery-->
                        <input id="gallery-value" type="hidden" data-postid="<?php echo get_the_ID(); ?>" data-offset="<?php echo $number; ?>">
                        <?php 
                        $count_post = $count+1;
                        if ($total >= $count_post) { ?>
                            <div class="btn-wrap text-center gallery-btn">
                                <a id="gallery-loadmore-btn" href="#" class="btn btn-primary">Load More <span class="icon icon-refresh"></span></a>
                            </div>
                        <?php } ?>    
                    </div><!--/.block-gallery-->
                </div>
            </section><!--/.gallery-page-->
        <?php } ?>    
<?php
    endwhile;
endif;
get_footer();