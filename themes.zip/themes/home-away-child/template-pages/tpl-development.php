<?php
/* Template Name: Child Development Dev */

get_header();
?>
<div class="child-development-page">

<?php if (have_rows('ss_flexible_content')) :
        while (have_rows('ss_flexible_content')) : the_row();
            if (get_row_layout()) :
                get_template_part('template-parts/development/' . get_row_layout());
            endif;
        endwhile;
    endif;?>
    <!-- /.choose-block-->
</div>
<?php
get_footer();
