<?php
/* Template Name: Contact */

get_header();
?>
<div class="contact-page">
	
	<?php 
	if ( have_rows('ss_contact_flexible_content') ) :
		while ( have_rows('ss_contact_flexible_content') ) : 
			the_row();
			if ( get_row_layout() ) :
				get_template_part('template-parts/contact/' . get_row_layout()); // file name is same as get row layout
			endif;
		endwhile;
	endif;
	?>

</div>
<!-- end .contact-page -->

<?php
get_footer();
