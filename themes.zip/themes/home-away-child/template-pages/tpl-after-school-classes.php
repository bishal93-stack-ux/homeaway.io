<?php
/* Template Name: After School Classes */

get_header();
?>
<div class="after-school-page">
	<?php
	if (have_rows('ss_flexible_content')) :
		while (have_rows('ss_flexible_content')) :
			the_row();
			if (get_row_layout()) :
				get_template_part('template-parts/after-school-classes/' . get_row_layout()); // file name is same as get row layout
			endif;
		endwhile;
	endif;
	?>

</div>


<?php
get_footer();
