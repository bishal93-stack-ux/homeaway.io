<?php
/* Template Name: Testimonials */

get_header();
$page_id = get_the_ID();
$featured = get_field('ss_featured_testimonials', $page_id);
?>
    <section class="testimonials-page">
        <div class="testimonials">
            <div class="container">
                <div class="card-deck">
                    <?php if( $featured ) {
                        $featured_id = $featured->ID;
                        $post = $featured;
                        setup_postdata( $post );
                        $rating = get_field('ss_testimonials_rating', $featured_id); ?>
                        <div class="col-12 card-item card-item--featured">
                            <div class="card">
                                <blockquote>
                                    <ul class="star-ratings">
                                    <?php if ( $rating == 1 ) {
                                            echo '<li><span class="icon-star"></span></li>';
                                        } else if (  $rating == 2 ){
                                            echo '<li><span class="icon-star"></span></li>
                                            <li><span class="icon-star"></span></li>';
                                        } else if ( $rating == 3 ) {
                                            echo '<li><span class="icon-star"></span></li>
                                            <li><span class="icon-star"></span></li>
                                            <li><span class="icon-star"></span></li>';
                                        } else if ( $rating == 4 ) {
                                            echo '<li><span class="icon-star"></span></li>
                                            <li><span class="icon-star"></span></li>
                                            <li><span class="icon-star"></span></li>
                                            <li><span class="icon-star"></span></li>';
                                        } else {
                                            echo '<li><span class="icon-star"></span></li>
                                            <li><span class="icon-star"></span></li>
                                            <li><span class="icon-star"></span></li>
                                            <li><span class="icon-star"></span></li>
                                            <li><span class="icon-star"></span></li>';
                                        } ?>
                                    </ul>
                                    <div class="author">
                                        <span><?php the_title(); ?></span>
                                    </div>
                                    <?php the_content(); ?>
                                </blockquote>
                            </div><!--/.card /.card--alt -->
                        </div><!--/.card-item card-item--alt -->
                    <?php wp_reset_postdata();    
                    }
                    $paged = get_query_var( 'paged' ) ? get_query_var( 'paged' ) : 1;
                    $show_post = 9; 
                    if ( $featured ) {
                        $args = array(
                            'post_type' => 'haccc_testimonials',
                            'status' => 'publish',
                            'posts_per_page' =>$show_post,
                            'paged' => $paged,
                            'orderby' => 'date',
                            'post__not_in' => array($featured_id),
                            
                        );
                    } else {
                        $args = array(
                            'post_type' => 'haccc_testimonials',
                            'status' => 'publish',
                            'posts_per_page' =>$show_post,
                            'orderby' => 'date',
                            'paged' => $paged,
                            
                        );
                    }
                    $testimonial = new Wp_Query($args);
                    $total_post = wp_count_posts( 'haccc_testimonials' )->publish;
                    if ($testimonial->have_posts()) { 
                        while ($testimonial->have_posts()) {
                            $testimonial->the_post();
                            get_template_part('template-parts/testimonials/content');
                        } 
                        wp_reset_postdata();
                    if ( $featured  ) {
                        $featured_post =  $featured_id;
                        $total_post = $total_post - 1;
                     } else {
                        $featured_post =  '';
                        $total_post = $total_post;
                     } 
                     echo '<input id="testimonial-post" data-featured="'. $featured_post .'" type="hidden" name="testimonial-post" data-attribute="'. $total_post .'" value="'. ceil($total_post/$show_post) .'" >';     
                }                  
                     ?>    
                </div><!--/card-deck-->
                <?php if ($total_post >= $show_post ) { ?>
                    <div class="btn-wrap text-center testimonial-btn">
                        <a href="#" id="testimonial-loadmore" class="btn btn-primary">Load More <span class="icon icon-refresh"></span></a>
                    </div>
                <?php } ?>    
            </div>
        </div>
    </section><!--/.testimonials-page-->
<?php
get_footer();