<?php
get_header();
?>
<section class="ls-page">

<?php 
if ( have_posts() ) {
    while ( have_posts() ) {
        the_post();
			if ( have_rows('ss_location_single_flexible_content') ) :
				while ( have_rows('ss_location_single_flexible_content') ) : 
					the_row();
					if ( get_row_layout() ) :
						get_template_part('template-parts/location-single/' . get_row_layout()); // file name is same as get row layout
					endif;
				endwhile;
			endif;
		}
	}
?>

</section>
<?php 
get_footer();