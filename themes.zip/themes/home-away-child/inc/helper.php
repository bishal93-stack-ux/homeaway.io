<?php 
defined( 'ABSPATH' ) || exit();

// Get post sections
function hacc_lawn_care($section_id, $post_id, $layout_name = 'sections')
{
    global $post;

    // Default post and it's ID
    if (empty($post_id)) {
        $post_id = $post->ID;
    }

    if (empty($section_id)) {
        return;
    }

    // Get the layouts
    $sections = get_field($layout_name, $post_id, true);
    if (!empty($sections) && is_array($sections)) {
        foreach ($sections as $section) {
            if (isset($section['acf_fc_layout']) && $section_id === $section['acf_fc_layout']) {
                return $section;
            }
        }
    }
}

// category
function category_name($id)
{
    $category_detail = get_the_category($id);
    if ($category_detail) {
        echo '<span>Category: </span>';
        $s = '';
        if (is_array($category_detail)) {
            $count = 1;
            foreach ($category_detail as $cat) {
                $cat_id = $cat->term_id;
                $category_link = get_category_link($cat);
                if ($s) $s .= ', ';
                $s .= '<a href="' . $category_link . '">';
                $s .= $cat->name;
                $s .= '</a>';
            }
            echo $s;
        }
    }
}