<?php
// Init all the files
defined( 'ABSPATH' ) || exit();
// Load ll required files
$includes = [
    'inc/contants.php',
    'inc/setup.php',
    'inc/assets.php',
    'inc/template-tags.php',
    'inc/template-functions.php',
    'inc/acf-option.php',
    'inc/widgets.php',
    'inc/post-types.php',
    'inc/ss-breadcrumbs.php',
    'inc/ss-bootstrap-navwalker.php',
    'inc/customizer.php',
    'inc/custom-header.php',
    // 'inc/custom-login.php',
    'inc/ajax-load-more.php',
    'inc/helper.php',
    'inc/aq_resizer.php',
];

/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
	$includes[] = '/inc/jetpack.php';
}
/**
 * Load WooCommerce compatibility file.
 */
// if ( class_exists( 'WooCommerce' ) ) {
//     $includes[] = '/inc/woocommerce.php';
// }
// load templates
foreach ( $includes as $f ) {
    if ( file_exists( get_template_directory() . '/' . $f ) ) {
        locate_template( $f, true, true );
    }
}
unset( $f );