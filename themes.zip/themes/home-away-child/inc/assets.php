<?php 
defined( 'ABSPATH' ) || exit();

/**
 * Enqueue scripts and styles.
 */
function home_away_child_scripts()
{
	wp_enqueue_style('home-away-child-fancybox', get_template_directory_uri() . '/vendors/fancybox/jquery.fancybox.min.css');
	wp_enqueue_style('home-away-child-slick', get_template_directory_uri() . '/vendors/slick/slick.css');
	wp_enqueue_style('home-away-child-style', get_stylesheet_uri());
	add_action('wp_head', function () {
		echo '<script>var ss;</script>';
	}); // don't remove
	wp_enqueue_script('haccc-ajax', get_template_directory_uri() . '/js/ajax-js.js', array('jquery'), null, true);

	wp_enqueue_script('home-away-child-pollyfill', get_template_directory_uri() . '/vendors/pollyfill/pollyfill.min.js', array('jquery'), null, true);
	wp_enqueue_script('home-away-child-match-height', get_template_directory_uri() . '/vendors/match-height/jquery.matchHeight.js', array('jquery'), null, true);
	wp_enqueue_script('home-away-child-fancybox', get_template_directory_uri() . '/vendors/fancybox/jquery.fancybox.min.js', array('jquery'), null, true);
	wp_enqueue_script('home-away-child-slick', get_template_directory_uri() . '/vendors/slick/slick.js', array('jquery'), null, true);
	wp_enqueue_script('home-away-child-bundle', get_template_directory_uri() . '/js/bundle.js', array('jquery'), null, true);


	wp_localize_script( 'haccc-ajax', 'HACCobj', array( 
		'admin_ajax' => admin_url( 'admin-ajax.php' ),
		'security'  => wp_create_nonce( 'haccc-security-nonce' ),
	));
	if (is_singular() && comments_open() && get_option('thread_comments')) {
		wp_enqueue_script('comment-reply');
	}
}
add_action('wp_enqueue_scripts', 'home_away_child_scripts');