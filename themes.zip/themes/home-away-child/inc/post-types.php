<?php 
defined( 'ABSPATH' ) || exit();

// Custom Post Type
add_action('init', 'home_away_child_post_type_init');
function home_away_child_post_type_init()
{
		// Locations Post Type
	register_post_type('haccc_location', array(
		'labels'             => array(
			'name'               => _x('Locations', 'post type general name', 'haccc'),
			'singular_name'      => _x('Locations', 'post type singular name', 'haccc'),
			'menu_name'          => _x('Location', 'admin Locations', 'haccc'),
			'name_admin_bar'     => _x('Location', 'add new on admin bar', 'haccc'),
			'add_new'            => _x('Add New', 'Location', 'haccc'),
			'add_new_item'       => __('Add New Location', 'haccc'),
			'new_item'           => __('New Location', 'haccc'),
			'edit_item'          => __('Edit Location', 'haccc'),
			'view_item'          => __('View Location', 'haccc'),
			'all_items'          => __('All Location', 'haccc'),
			'search_items'       => __('Search Location', 'haccc'),
			'parent_item_colon'  => __('Parent Location:', 'haccc'),
			'not_found'          => __('No Location found.', 'haccc'),
			'not_found_in_trash' => __('No Location found in Trash.', 'haccc')
		),
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		// 'rewrite'            => array('slug' => 'locations'),
		'capability_type'    => 'post',
		'has_archive'        => false,
		'hierarchical'       => true,
		'menu_position'      => null,
		'menu_icon' 		 => 'dashicons-location-alt',
		'supports'           => array('title', 'thumbnail', 'excerpt')
	));
// Testimonials
	register_post_type('haccc_testimonials', array(
		'labels'             => array(
			'name'               => _x('Testimonials', 'post type general name', 'haccc'),
			'singular_name'      => _x('Testimonial', 'post type singular name', 'haccc'),
			'menu_name'          => _x('Testimonials', 'admin Testimonials', 'haccc'),
			'name_admin_bar'     => _x('Testimonials', 'add new on admin bar', 'haccc'),
			'add_new'            => _x('Add New', 'Testimonials', 'haccc'),
			'add_new_item'       => __('Add New Testimonials', 'haccc'),
			'new_item'           => __('New Testimonials', 'haccc'),
			'edit_item'          => __('Edit Testimonials', 'haccc'),
			'all_items'          => __('All Testimonials', 'haccc'),
			'search_items'       => __('Search Testimonials', 'haccc'),
			'parent_item_colon'  => __('Parent Testimonials:', 'haccc'),
			'not_found'          => __('No Testimonials found.', 'haccc'),
			'not_found_in_trash' => __('No Testimonials found in Trash.', 'haccc')
		),
		'public'             => false,
		'publicly_queryable' => false,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => array('slug' => 'testimonials'),
		'capability_type'    => 'post',
		'has_archive'        => false,
		'hierarchical'       => true,
		'menu_position'      => null,
		'menu_icon' 		 => 'dashicons-testimonial',
		'supports'           => array('title', 'thumbnail', 'editor', 'excerpt')
	));
	// Development
	register_post_type('haccc_development', array(
		'labels'             => array(
			'name'               => _x('Child Development', 'post type general name', 'haccc'),
			'singular_name'      => _x('Development', 'post type singular name', 'haccc'),
			'menu_name'          => _x('Development', 'admin Development', 'haccc'),
			'name_admin_bar'     => _x('Development', 'add new on admin bar', 'haccc'),
			'add_new'            => _x('Add New', 'Child Development', 'haccc'),
			'add_new_item'       => __('Add New Child Development', 'haccc'),
			'new_item'           => __('New Child Development', 'haccc'),
			'edit_item'          => __('Edit Child Development', 'haccc'),
			'all_items'          => __('All Child Development', 'haccc'),
			'search_items'       => __('Search Child Development', 'haccc'),
			'parent_item_colon'  => __('Parent Child Development:', 'haccc'),
			'not_found'          => __('No Child Development found.', 'haccc'),
			'not_found_in_trash' => __('No Child Development found in Trash.', 'haccc')
		),
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => array('slug' => 'developments'),
		'capability_type'    => 'post',
		'has_archive'        => false,
		'hierarchical'       => true,
		'menu_position'      => null,
		'menu_icon' 		 => 'dashicons-welcome-learn-more',
		'supports'           => array('title', 'thumbnail', 'editor', 'excerpt')
	));
	// Classes
	register_post_type('haccc_classes', array(
		'labels'             => array(
			'name'               => _x('School Classes', 'post type general name', 'haccc'),
			'singular_name'      => _x('Class', 'post type singular name', 'haccc'),
			'menu_name'          => _x('School Classes', 'admin Classes', 'haccc'),
			'name_admin_bar'     => _x('School Classes', 'add new on admin bar', 'haccc'),
			'add_new'            => _x('Add New', 'Child School Classes', 'haccc'),
			'add_new_item'       => __('Add New Child School Classes', 'haccc'),
			'new_item'           => __('New Child School Classes', 'haccc'),
			'edit_item'          => __('Edit Child School Classes', 'haccc'),
			'all_items'          => __('All Child School Classes', 'haccc'),
			'search_items'       => __('Search Child School Classes', 'haccc'),
			'parent_item_colon'  => __('Parent Child School Classes:', 'haccc'),
			'not_found'          => __('No Child School Classes found.', 'haccc'),
			'not_found_in_trash' => __('No Child School Classes found in Trash.', 'haccc')
		),
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => array('slug' => 'school-classes'),
		'capability_type'    => 'post',
		'has_archive'        => false,
		'hierarchical'       => true,
		'menu_position'      => null,
		'menu_icon' 		 => 'dashicons-edit',
		'supports'           => array('title', 'thumbnail', 'editor', 'excerpt')
	));
	// Programs 
	register_post_type('haccc_programs', array(
		'labels'             => array(
			'name'               => _x('Programs', 'post type general name', 'haccc'),
			'singular_name'      => _x('Program', 'post type singular name', 'haccc'),
			'menu_name'          => _x('Programs', 'admin Classes', 'haccc'),
			'name_admin_bar'     => _x('Programs', 'add new on admin bar', 'haccc'),
			'add_new'            => _x('Add New', 'Child Programs', 'haccc'),
			'add_new_item'       => __('Add New Child Programs', 'haccc'),
			'new_item'           => __('New Child Programs', 'haccc'),
			'edit_item'          => __('Edit Child Programs', 'haccc'),
			'all_items'          => __('All Child Programs', 'haccc'),
			'search_items'       => __('Search Child Programs', 'haccc'),
			'parent_item_colon'  => __('Parent Child Programs:', 'haccc'),
			'not_found'          => __('No Child Programs found.', 'haccc'),
			'not_found_in_trash' => __('No Child Programs found in Trash.', 'haccc')
		),
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => array('slug' => 'program'),
		'capability_type'    => 'post',
		'has_archive'        => false,
		'hierarchical'       => true,
		'menu_position'      => null,
		'menu_icon' 		 => 'dashicons-welcome-view-site',
		'supports'           => array('title', 'thumbnail', 'editor', 'excerpt')
	));
}