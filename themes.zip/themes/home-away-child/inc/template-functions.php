<?php

/**
 * Functions which enhance the theme by hooking into WordPress
 *
 * @package Home_Away_Child_Care_Center
 */

/**
 * Adds custom classes to the array of body classes.
 *
 * @param array $classes Classes for the body element.
 * @return array
 */
function home_away_child_body_classes($classes)
{
	// Adds a class of hfeed to non-singular pages.
	if (!is_singular()) {
		$classes[] = 'hfeed';
	}

	// Adds a class of no-sidebar when there is no sidebar present.
	if (!is_active_sidebar('sidebar')) {
		$classes[] = 'no-sidebar';
	} else {
		$classes[] = 'has-sidebar';
	}

	return $classes;
}
add_filter('body_class', 'home_away_child_body_classes');

/**
 * Add a pingback url auto-discovery header for single posts, pages, or attachments.
 */
function home_away_child_pingback_header()
{
	if (is_singular() && pings_open()) {
		printf('<link rel="pingback" href="%s">', esc_url(get_bloginfo('pingback_url')));
	}
}
add_action('wp_head', 'home_away_child_pingback_header');

//Recent posts functions
function recent_posts_func($atts, bool $latest = false)
{
	$recPosts = '';
	$atts = shortcode_atts(array(
		'no_of_posts' => 4,
	), $atts);
	$args = array(
		'numberposts' => $atts['no_of_posts'],
		'orderby' => 'post_date',
		'order' => 'DESC',
		'post_type' => 'post',
		'post_status' => 'publish',
	);
	$recent_posts = wp_get_recent_posts($args);

	foreach ($recent_posts as $recent) {
		$altText = get_post_meta(get_post_thumbnail_id($recent['ID']), '_wp_attachment_image_alt', true);
		$altText = $altText ? $altText : esc_attr($recent["post_title"]);
		$timestamp = strtotime($recent["post_date"]);
		if ($latest == true) {
			$day = date("d", $timestamp);
			$month = date("M", $timestamp);
			$imageUrl = has_post_thumbnail($recent['ID']) ? get_the_post_thumbnail_url($recent['ID']) : '' . home_url() . '/media/home-blog-img1.jpg/' . '';
			$recPosts .= '<div class="slide-item">';
			$recPosts .= '<article class="bg-cover">';
			$recPosts .= '<span class=" post-date"><strong>' . $day . '</strong> ' . $month . '</span>';
			$recPosts .= '<img src="' . $imageUrl . '" alt="' . $altText . '">';
			$recPosts .= '<h6><a href="' . get_permalink($recent["ID"]) . '" class="stretched-link">' . esc_attr($recent["post_title"]) . '</a></h6>';
			$recPosts .= '<p>' . wp_trim_words($recent["post_content"], 13, '...') . '</p>';
			$recPosts .= '</article>';
			$recPosts .= '</div>';
		} else {
			$imageUrl =  get_the_post_thumbnail_url($recent['ID'], 'medium');
			// get_the_post_thumbnail_url($recent["ID"], 'recent-thumb');
			if (empty($imageUrl)) {
				$imageUrl = 'https://placehold.it/465x243/000000/000000';
			}
			$recPosts .= '<div class="blog__mini-post">';
			$recPosts .= '<div class="blog__mini-img">';
			$recPosts .= '<a href="' . get_the_permalink($recent['ID']) . '"><img src="' . $imageUrl . '" alt="' . $altText . '"></a>';
			$recPosts .= '</div>';
			$recPosts .= '<div class="blog__mini-content">';
			$recPosts .= '<h4><a href="' . get_permalink($recent["ID"]) . '">' . esc_attr($recent["post_title"]) . '</a></h4>';
			$recPosts .= '<span>' . human_time_diff($timestamp, current_time('timestamp')) . ' ago' . '</span>';
			$recPosts .= '</div>';
			$recPosts .= '</div>';
		}
	}
	if ($latest == false) {
		$recPosts .= '<a href="'. home_url('/blog/') .'">View all</a>';
	}
	wp_reset_postdata();
	return $recPosts;
}
add_shortcode('latest_posts', 'recent_posts_func');

add_filter( 'get_the_archive_title', function ($title) {    
	if ( is_category() ) {    
			$title = single_cat_title( '', false );    
		} elseif ( is_tag() ) {    
			$title = single_tag_title( '', false );    
		} elseif ( is_author() ) {    
			$title = '<span class="vcard">' . get_the_author() . '</span>' ;    
		} elseif ( is_tax() ) { //for custom post types
			$title = sprintf( __( '%1$s' ), single_term_title( '', false ) );
		} elseif (is_post_type_archive()) {
			$title = post_type_archive_title( '', false );
		}
	return $title;    
});

//disable scrolling on gform
add_filter('gform_confirmation_anchor', '__return_false');

/*
 * Brand functionality.
*/
add_filter('get_custom_logo', 'ss_logo_class_name');
function ss_logo_class_name($html)
{
	$html = str_replace('custom-logo', 'navbar-brand', $html);
	$html = str_replace('custom-logo-link', 'navbar-brand', $html);

	return $html;
}
function get_brand()
{
	if (get_custom_logo()) :
		the_custom_logo();
	else :
		$img = array('logo.svg', 'logo.png', 'logo.jpg');
		$brand = '<span>' . get_bloginfo('name') . '</span>';
		foreach ($img as $logo) {
			if (file_exists(get_template_directory() . '/img/' . $logo)) {
				$brand = '<img src="' . get_template_directory_uri() . '/img/' . $logo . '" alt="' . get_bloginfo('name') . '">';
			} elseif (file_exists(get_template_directory() . '/images/' . $logo)) {
				$brand = '<img src="' . get_template_directory_uri() . '/images/' . $logo . '" alt="' . get_bloginfo('name') . '">';
			}
		}
		return '<a class="navbar-brand" href="' . esc_url(home_url('/')) . '">' . $brand . '</a>';
	endif;
	return false;
}
function the_brand()
{
	echo get_brand();
}

// Remove the loaction  postype type link cpt slug form the url
/**
 * Remove the slug from published post permalinks. Only affect our CPT though.
 */
function home_remove_cpt_slug( $post_link, $post, $leavename ) {
	if ( 'haccc_location' != $post->post_type || 'publish' != $post->post_status ) {
		return $post_link;
	}
	$post_link = str_replace( '/' . $post->post_type . '/', '/', $post_link );
	return $post_link;
}
add_filter( 'post_type_link', 'home_remove_cpt_slug', 10, 3 );


/**
 * Some hackery to have WordPress match postname to any of our public post types
 * All of our public post types can have /post-name/ as the slug, so they better be unique across all posts
 * Typically core only accounts for posts and pages where the slug is /post-name/
 */
function home_parse_request_tricksy( $query ) {
	// Only noop the main query
	if ( ! $query->is_main_query() )
		return;
	// Only noop our very specific rewrite rule match
	if ( 2 != count( $query->query ) || ! isset( $query->query['page'] ) ) {
		return;
	}
	// 'name' will be set if post permalinks are just post_name, otherwise the page rule will match
	if ( ! empty( $query->query['name'] ) ) {
		$query->set( 'post_type', array( 'post', 'haccc_location', 'page' ) );
	}
}
add_action( 'pre_get_posts', 'home_parse_request_tricksy' );