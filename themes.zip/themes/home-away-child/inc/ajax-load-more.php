<?php 
defined( 'ABSPATH' ) || exit();

// Gallery Load more
// add action for logged in users
add_action('wp_ajax_gallery_loadmore', 'gallery_loadmore');
// add action for non logged in users
add_action('wp_ajax_nopriv_gallery_loadmore', 'gallery_loadmore');

function gallery_loadmore() {

    check_ajax_referer( 'haccc-security-nonce', 'security' );
	// make sure we have the other values
	if (!isset($_POST['post_id']) || !isset($_POST['offset'])) {
		return;
	}
	$show = 9; // how many more to show
	$start = $_POST['offset'];
	$end = $start+$show;
	$post_id = $_POST['post_id'];
	ob_start();
	$count = 0;
	$total = count(get_field('ss_gallery', $post_id));
	$images = get_field('ss_gallery', $post_id);
	foreach( $images as $image ){ 
		the_row();
		if ($count < $start) {
			// we have not gotten to where
			// we need to start showing
			// increment count and continue
			$count++;
			continue;
		}
		$resized_url = aq_resize($image['url'], 408, 300, true, true, true); ?>
		<div class="col-6 col-lg-4 card-item">
			<div class="card rounded">
				<div class="card-img">
					<figure>
						<a href="<?php echo $image['url']; ?>" data-fancybox="gallery"><img
									src="<?php echo $resized_url; ?>"
									alt="<?php echo $image['alt'];?>"></a>
					</figure>
				</div><!--/.card-img-->
			</div><!--/.card rounded-->
		</div><!--/.card-item-->
		<?php 
		$count++;
			if ($count == $end) {
				// we've shown the number, break out of loop
				break;
			}
	} // end while have rows

	$content = ob_get_clean();
	// check to see if we've shown the last item
	$more = false;
	if ($total > $count) {
		$more = true;
	}
	// output our 3 values as a json encoded array
	echo json_encode(array('content' => $content, 'more' => $more, 'offset' => $end));
	// echo $content;
	wp_die();
} // end function gallery_loadmore

// Load More Testimonials

add_action('wp_ajax_testimonial_loadmore', 'testimonial_loadmore_callback');
add_action('wp_ajax_nopriv_testimonial_loadmore', 'testimonial_loadmore_callback');
function testimonial_loadmore_callback()
{ 
    check_ajax_referer( 'haccc-security-nonce', 'security' );
    $paged = $_POST['paged'];
    $featured = $_POST['featured'];
	$show_post = 9;
	if ( $featured ){
		$args = array(
			'post_type' => 'haccc_testimonials',
			'status' => 'publish',
			'posts_per_page' =>$show_post,
			'paged' => $paged,
			'orderby' => 'date',
			'post__not_in' => array($featured),
		);
	} else {
		$args = array(
			'post_type' => 'haccc_testimonials',
			'status' => 'publish',
			'posts_per_page' =>$show_post,
			'orderby' => 'date',
			'paged' => $paged,
		);
	}
    $loop = new WP_Query($args);
    if ($loop->have_posts()) {

		while ($loop->have_posts()):$loop->the_post();
			get_template_part('template-parts/testimonials/content');
		endwhile;
        wp_reset_postdata();
    }
    wp_die();
}