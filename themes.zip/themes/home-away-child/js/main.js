/**
 * File main.js.
 *
 * Theme main script.
 *
 * Contains all theme custom features.
 */
var ss;
(function ($) {
    ss = {
        init: function () {
            this.img();
            this.nav();
            this.form();
            this.stick();
            this.misc();
            this.refreshOnResize();
            this.slider();
            this.ourFacilitySlider();
            this.gallery();


        },
        ie: function () {
            try {
                if (/MSIE (\d+\.\d+);/.test(navigator.userAgent) || !!navigator.userAgent.match(/Trident.*rv\:11\./)) {
                    $('body').addClass('ie-user');
                    return true;
                }
            } catch (err) {
                console.log(err);
            }
            return false;
        },
        img: function (context) {
            if (!context) context = $('body');
            context.find('.bg-cover,[data-fix="image"]').each(function () {
                var wrap = $(this),
                    image = wrap.find('>img');
                if (image.attr('src')) {
                    if (wrap.data('fix') != 'image') {
                        image.hide();
                        wrap.css({
                            'background-image': 'url(\'' + image.attr('src') + '\')'
                        });
                    } else {
                        wrap.find('.svg.img-fluid').css({
                            'background-image': 'url(\'' + image.attr('src') + '\')'
                        });
                    }
                }
                if (ss.ie()) {
                    wrap.find('.svg').removeClass('img-fluid');
                }
            });
        },
        nav: function () {
            $('.navbar .dropdown > a').click(function () {
                location.href = this.href;
            });
        },
        stick: function () {

            // var win = $(window);

            // var mainHeader = $('.site-header');
            // var headerHeight = mainHeader.height();

            // var mainWrap = $('.site-content');

            // mainWrap.css('margin-top', headerHeight);

            // win.scroll(function () {
            // 	var winScroll = win.scrollTop();

            // 	if (winScroll > headerHeight) {
            // 		mainHeader.addClass('stick');
            // 	} else {
            // 		mainHeader.removeClass('stick');
            // 	}
            // });

            // win.resize(function () {
            // 	var winScroll = win.scrollTop();
            // 	var headerHeight = mainHeader.height();

            // 	mainWrap.css('margin-top', headerHeight);

            // 	var winScroll = win.scrollTop();

            // 	if (winScroll > headerHeight) {
            // 		mainHeader.addClass('stick');
            // 	} else {
            // 		mainHeader.removeClass('stick');
            // 	}
            // });
        },
        form: function () {
            try {
                $('.input-text.qty').each(function () {
                    var elm = $(this);
                    $('<span class="qty-des"><i class="icon-angle-left"></i></span>').insertBefore($(this));
                    $('<span class="qty-ins"><i class="icon-angle-right"></i></span>').insertAfter($(this));
                    elm.prev('.qty-des').on('click', function () {
                        var val = parseInt(elm.val());
                        if (val > 1) {
                            elm.val(val - 1);
                        }
                    });
                    elm.next('.qty-ins').on('click', function () {
                        var val = parseInt(elm.val());
                        elm.val(val + 1);
                    });
                });
            } catch (err) {
                console.log(err);
            }
        },
        misc: function () {
            try {
                $('[data-fix="height"]').matchHeight();

                objectFitImages();

            } catch (err) {
                console.log(err);
            }

        },
        slider: function () {

            $('.home-testimonials__slider').slick({
                arrows: false,
                slidesToShow: 3,
                slidesToScroll: 1,
                autoplay: true,
                dots: true,
                responsive: [{
                    breakpoint: 1200,
                    settings: {
                        slidesToShow: 2
                    }
                },
                    {
                        breakpoint: 768,
                        settings: {
                            slidesToShow: 1,
                            adaptiveHeight: true,
                        }
                    },
                    {
                        breakpoint: 575,
                        settings: {
                            slidesToShow: 1,
                            adaptiveHeight: true,
                        }
                    }
                ]
            });

            $('.home-testimonials__slider').on('setPosition', function () {
                $(this).find('.card').height('auto');
                var slickTrack = $(this).find('.slick-track');
                var slickTrackHeight = $(slickTrack).height();
                $(this).find('.card').css('height', slickTrackHeight + 'px');
            });

            var weProvideSlider = '.card-block--provide .card-block__content';

            $(weProvideSlider).on('breakpoint beforeChange', function () {
                $('[data-fix="height"]').matchHeight();
            });

            $(weProvideSlider).slick({
                slidesToShow: 5,
                adaptiveHeight: true,
                prevArrow: '<button type="button" class="slick-prev icon-arrows-right"></button>',
                nextArrow: '<button type="button" class="slick-next icon-arrows-right"></button>',
                responsive: [{
                    breakpoint: 1300,
                    settings: {
                        slidesToShow: 4
                    }
                },
                    {
                        breakpoint: 1000,
                        settings: {
                            slidesToShow: 3
                        }
                    },
                    {
                        breakpoint: 800,
                        settings: {
                            slidesToShow: 2
                        }
                    },
                    {
                        breakpoint: 575,
                        settings: {
                            slidesToShow: 1
                        }
                    }
                ]
            });

            // var eductionCardSlider = '.areas-of-expertise__content';

            // $('.areas-of-expertise__content').on('init', function(event, slick){
            //     console.log("initialized");
            // });

            $('.areas-of-expertise__content').slick({
                slidesToShow: 5,
                slidesToScroll: 1,
                prevArrow: '<button type="button" class="slick-prev icon-arrows-right"></button>',
                nextArrow: '<button type="button" class="slick-next icon-arrows-right"></button>',
                responsive: [{
                    breakpoint: 1300,
                    settings: {
                        slidesToShow: 4
                    }
                },
                    {
                    breakpoint: 1200,
                    settings: {
                        slidesToShow: 3
                    }
                },
                    {
                    breakpoint: 992,
                    settings: {
                        slidesToShow: 2
                    }
                },
                {
                    breakpoint: 768,
                    settings: {
                        slidesToShow: 1
                    }
                }
                ]
            });

            var screenwidth = $(window).width();
            if (screenwidth < 576) {
                $('.our-facility-slider').slick({
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    prevArrow: '<button type="button" class="slick-prev icon-arrows-right"></button>',
                    nextArrow: '<button type="button" class="slick-next icon-arrows-right"></button>',
                });
            }

            // card-block__slider

            $('.card-block__content').slick({
                slidesToShow: 4,
                slidesToScroll: 1,
                prevArrow: '<button type="button" class="slick-prev icon-arrows-right"></button>',
                nextArrow: '<button type="button" class="slick-next icon-arrows-right"></button>',
                responsive: [{
                    breakpoint: 1300,
                    settings: {
                        slidesToShow: 3
                    }
                },
                    {
                        breakpoint: 1000,
                        settings: {
                            slidesToShow: 2
                        }
                    },
                    {
                        breakpoint: 767,
                        settings: {
                            slidesToShow: 1
                        }
                    }
                ]
            });

            // home-testimonials__slider

            // var homeTestimonialSlider = '.home-testimonials__slider';


            //slick same-height
            jQuery('.areas-of-expertise__content').on('setPosition', function () {
                jQuery(this).find('.slick-slide').height('auto');
                var slickTrack = jQuery(this).find('.slick-track');
                var slickTrackHeight = jQuery(slickTrack).height();
                jQuery(this).find('.slick-slide').css('height', slickTrackHeight + 'px');
                // console.log(slickTrackHeight);
            });
        },
        gallery: function () {
            try {
                $('.fancybox').fancybox({
                    openEffect: 'none',
                    closeEffect: 'none'
                });
            } catch (err) {
                console.log(err);
            }
            try {
                var fix = function () {
                    var t = $('.woocommerce-product-gallery__trigger'),
                        h = t.next('.flex-viewport').outerHeight() - 16;
                    t.height(h);
                }
                $(window).bind('load resize', fix);
                $('.woocommerce-product-gallery .flex-control-nav li').on('click', function () {
                    setTimeout(fix, 500);
                });
            } catch (err) {
                console.log(err);
            }
        },
        refreshOnResize: function () {

            $(window).resize(function () {
                 var screenwidth = $(this).width();
                if (screenwidth < 576) {
                    $('.our-facility-slider').slick({
                        slidesToShow: 1,
                        slidesToScroll: 1,
                        prevArrow: '<button type="button" class="slick-prev icon-arrows-right"></button>',
                        nextArrow: '<button type="button" class="slick-next icon-arrows-right"></button>',
                    });
                }else{
                    $('.our-facility-slider').slick('unslick');
                }

            });

        }
    };
    $(function () {
        ss.init();
    });
})(jQuery);

jQuery('.readmore-btn').click(function () {
    var btn = jQuery(this);
    var btnText = btn.text();
    var btnText = btnText.toUpperCase();

    if (btnText === 'READ LESS') {
        jQuery(this).text('Read More');
        btn.prev('.card-content').find('.dot').show();
        btn.prev('.card-content').find('.more').removeClass('show');

        setTimeout(function () {
            btn.prev('.card-content').find('.more').hide();
        }, 100);
    } else {
        jQuery(this).text('Read Less');
        btn.prev('.card-content').find('.dot').hide();
        btn.prev('.card-content').find('.more').show();

        setTimeout(function () {
            btn.prev('.card-content').find('.more').addClass('show');
        }, 100);
    }
});