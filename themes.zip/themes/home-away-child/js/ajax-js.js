var paged = 2;
jQuery(document).ready(function($) {
    var post_id = jQuery("#gallery-value").attr("data-postid");
    var offset = jQuery("#gallery-value").attr("data-offset");
    var ajax_url = HACCobj.admin_ajax;
    var my_repeater_more = true;
    var my_repeater_field_nonce = HACCobj.security;

    function gallery_loadmore() {

        // make ajax request
        jQuery.post(
            ajax_url, {
                // this is the AJAX action we set up in PHP
                'action': 'gallery_loadmore',
                'post_id': post_id,
                'offset': offset,
                security: HACCobj.security,
            },
            function(json) {
                // add content to container
                // this ID must match the containter 
                // you want to append content to
                jQuery('.gallery-page .block-gallery .card-deck--gallery').append(json['content']);
                // update offset
                offset = json['offset'];
                // see if there is more, if not then hide the more link
                if (!json['more']) {
                    // this ID must match the id of the show more link
                    jQuery('.gallery-btn').css('display', 'none');
                }
            },
            'json'
        );
    }
    jQuery('.gallery-page .gallery-btn a#gallery-loadmore-btn').on('click', function(e) {
        e.preventDefault();
		gallery_loadmore();
    });
    jQuery('.testimonials .testimonial-btn a#testimonial-loadmore').on('click', function(e) {
        e.preventDefault();
        var click_limit = jQuery(".testimonials #testimonial-post").attr("value");
        var featured = jQuery(".testimonials #testimonial-post").attr("data-featured");

        jQuery.ajax({
                url: HACCobj.admin_ajax,
                type: 'POST',
                data: {
                    'action': 'testimonial_loadmore',
                    'paged': paged,
                    'featured': featured,
                    security: HACCobj.security,
                    beforeSend: function(xhr) {
                        jQuery('.testimonials .testimonial-btn').hide();
                    },
                },
            })
            .success(function(response) {
                if (response.success != false) {
                    jQuery('.testimonials .card-deck').append(response);
                    if (paged >= click_limit) {
                        console.log('hide');
                        jQuery('.testimonials .testimonial-btn').hide();
                    } else {
                        jQuery('.testimonials .testimonial-btn').show();
                        console.log('show');
                    }
                    paged++;
                }
            })
            // Failed
            .fail(function() {
                console.log("error");

            })
            .always(function() {
                console.log("complete");
            })

    });
});